# Environment variables

Where they go: **API host** (Render/Railway/VPS…) = everything under "Server". **Web host** (Vercel…) = only the two `NEXT_PUBLIC_*` variables.
Anything not prefixed `NEXT_PUBLIC_` must never be set on the web host.

## Web (public by design)
| Variable | Required | Value |
|---|---|---|
| `NEXT_PUBLIC_API_URL` | **yes (build time)** | `https://api.yourdomain.com` (no trailing slash, no `/api`). Production build **fails** if missing, not https, or localhost. Changing it needs a rebuild. |
| `NEXT_PUBLIC_BOT_USERNAME` | recommended | bot username without `@` |

## Server
| Variable | Required | Notes |
|---|---|---|
| `NODE_ENV` | yes | `production` |
| `PORT` | no | default 4000 |
| `DATABASE_URL` | yes (while Prisma is the runtime) | PostgreSQL URL. Removed after the Firestore cut-over. |
| `BOT_TOKEN` | yes | from @BotFather. If it was ever pasted anywhere public: `/revoke` |
| `BOT_USERNAME`, `MINI_APP_URL`, `APP_NAME` | yes / yes / no | `MINI_APP_URL` = public https web URL |
| `JWT_SECRET`, `ADMIN_JWT_SECRET` | yes | ≥32 random chars each, different. `openssl rand -base64 48` |
| `SECRETS_ENCRYPTION_KEY` | for saving integration credentials in the panel | `openssl rand -base64 32` |
| `ADMIN_TELEGRAM_IDS` | yes | first owner(s), comma separated numeric IDs |
| `ADMIN_ALERT_CHAT_ID` | recommended | chat that gets admin alerts |
| `WEB_ORIGIN` | yes | exact web origin for CORS, e.g. `https://app.yourdomain.com` |
| `PAYMENT_ENV` | yes | `production` only with production credentials |
| `PAYMENT_WEBHOOK_SECRET` | if using the signed webhook | long random string |
| `INIT_DATA_MAX_AGE`, `ADMIN_INIT_DATA_MAX_AGE`, `ADMIN_FRESH_SECONDS`, `MAX_WALLET_ADJUSTMENT`, `DEPOSIT_*` | no | defaults in `.env.example` |
| `STORAGE_DRIVER` | yes | `b2` in production (`local` is refused) |
| `B2_S3_ENDPOINT`, `B2_REGION`, `B2_KEY_ID`, `B2_APPLICATION_KEY`, `B2_PUBLIC_BUCKET`, `B2_PUBLIC_BASE_URL` | yes with `b2` | start-up fails with the list of missing names |
| `B2_PRIVATE_BUCKET` | for paid file downloads | private bucket |
| `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY` | after Firestore cut-over | service account, server only; or `GOOGLE_APPLICATION_CREDENTIALS` |
| `FIRESTORE_EMULATOR_HOST` | dev/tests | `127.0.0.1:8080` |
| `<PROVIDER>_*` (e.g. `BKASH_APP_KEY`) | only when an adapter is implemented | none are implemented today |

## Secret hygiene checklist (GitHub)
- `.gitignore` now blocks `.env`, `.env.*` (except `*.example`), `*.pem`, `*.key`, Firebase service-account JSON and emulator data.
- Before the first push: `git status --ignored`, then `git grep -nEI "BOT_TOKEN=.+|PRIVATE_KEY|AKIA|AIza|-----BEGIN"` must show only `.env.example` placeholders.
- Turn on GitHub **Secret scanning** and **Push protection** (Settings → Code security).
- If a secret was ever committed: **rotate it** (BotFather `/revoke`, delete the B2 application key, delete the Firebase service-account key, regenerate JWT secrets). Deleting the file or the commit is not enough.
- The Firebase **web** config (apiKey, authDomain…) is public by design and protected by the deny-all rules; the **service account** is not.
