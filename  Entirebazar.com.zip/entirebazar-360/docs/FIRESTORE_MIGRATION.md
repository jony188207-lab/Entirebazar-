# Firestore migration plan and status

**Status: PLANNED + FOUNDATION DELIVERED. Prisma/PostgreSQL is still the running database.**
`firebase-admin` could not be installed and no Firestore emulator was available when this was written, so nothing here has run against real Firestore (**NOT TESTED**).
Prisma code is removed only after a phase's emulator tests pass (rule: replace first, verify, then delete).

## Delivered (and what verifies it)
| Item | File | Verified by |
|---|---|---|
| Deny-all client rules (all access via API/Admin SDK) | `firestore.rules` | **NOT TESTED** (needs emulator) |
| Composite indexes for the queries in the current code | `firestore.indexes.json` | JSON valid; **NOT TESTED** (Firestore reports a missing index on first run with a console link) |
| Emulator config | `firebase.json` | NOT TESTED |
| Paths and deterministic IDs (idempotency keys) | `apps/api/src/firestore/paths.ts` | unit tests |
| Integer-minor-unit money | `firestore/money.ts` | unit tests |
| Wallet ledger `postEntry` (idempotent, no overdraft) | `firestore/ledger.ts` | 8 tests on an in-memory store that enforces reads-before-writes, create-if-absent and optimistic retry, **including two concurrent credits and two concurrent debits** |
| `finalizeDeposit` (exact amount, receiver, unique TrxID, idempotent credit) | `firestore/deposits.ts` | same tests |
| Licence-key claiming (replaces `SKIP LOCKED`) | `firestore/keys.ts` | same tests |
| firebase-admin transaction adapter, custom-token minting | `firestore/adminAdapter.ts`, `firebaseAuth.ts` | **NOT TESTED, NOT WIRED** (never compiled against the SDK) |

**Not wired:** no route or service calls these modules yet. They exist beside Prisma so that the cut-over can be done phase by phase.

## Collections
IDs are deterministic wherever a SQL unique constraint existed, so uniqueness is enforced by `create()`.

| Collection / path | Document id | Replaces | Key fields |
|---|---|---|---|
| `users/{telegramId}` | Telegram id (string) | User | username, firstName, status, blocked flags, createdAt |
| `wallets/{userId}` | userId | Wallet | `balanceMinor` (int), `version`, updatedAt |
| `wallets/{userId}/ledger/{refType__refId__DIRECTION}` | **idempotency key** | LedgerEntry `@@unique(refType,refId,direction)` | type, amountMinor, balanceAfterMinor, note, createdAt |
| `walletAdjustments/{id}` | auto | WalletAdjustment | userId, amountMinor, reason(≥8), adminId |
| `paymentProviders/{code}` | code | PaymentProvider | displayName, receiverNumber, verificationMode, enabled, min/maxMinor |
| `deposits/{id}` | auto | Deposit | userId, providerCode, amountMinor, status, needsReview, providerTrxId, expiresAt, invoiceNo |
| `deposits/{id}/events/{auto}` | auto | PaymentEvent | source, kind, payload, createdAt |
| `trxKeys/{provider__trxId}` | **idempotency key** | Transaction `@@unique(providerCode,providerTrxId)` | depositId, amountMinor, sender/receiver |
| `categories/{id}` | auto | Category | parentId, slug, status, publishAt/unpublishAt, featured, sortOrder, settings (map) |
| `categorySections/{id}`, `actionButtons/{id}` | auto | CategorySection, ActionButton | owner id fields (exactly one), sortOrder, config/target (validated by zod before write) |
| `products/{id}` (+ `variants/{id}`, `keys/{id}`) | auto | Product, ProductVariant, ProductKey | `categoryIds[]` (replaces ProductCategory join), priceMinor, stock counters; key secret encrypted |
| `orders/{id}` (+ `items/{id}`), `orderIdem/{uid__clientRef}` | auto / **idempotency key** | Order, OrderItem, `@@unique(userId,clientRef)` | status, totalMinor, snapshots |
| `notifications`, `announcements`, `noticeDismissals`, `supportTickets`, `broadcastJobs`, `notificationTemplates` | auto | same names | |
| `adminUsers/{telegramId}`, `roles/{id}` | id | AdminUser, Role | permissions[] |
| `integrationConfigs/{code}`, `integrationSecrets/{code__mode__NAME}`, `integrationLogs/{id}` | | Integration* | secrets stay AES-GCM encrypted |
| `auditLogs/{id}` | auto | AuditLog | actor, action, target, createdAt |
| `settings/{key}` | key | AppSetting | value (map) |
| `dailyStats/{YYYY-MM-DD}` | date | raw SQL reports | counters incremented in the same transaction as the event |

## Query translation notes
- Joins/`include` → denormalise the few fields a list needs (product `categoryIds`, order item snapshots) or issue a second read.
- Category "liveness" over ancestors → store `ancestorIds[]` and a precomputed `live` flag updated by the publish/schedule worker, or evaluate ancestors with one `getAll`.
- Text search (`contains`) is not available: use prefix queries on a lower-cased `nameLower` field, or add Algolia/Typesense later.
- Reports → `dailyStats` counters (and Firestore `count()/sum()` aggregation queries for ranges).
- Hot documents: wallet and daily counters are limited to ~1 sustained write/second; fine for this workload, sharded counters if it grows.
- Money is stored in **minor units**; conversion happens only at the API boundary (`toMinor/fromMinor`).

## Phases (do not delete Prisma code of a phase until its tests pass on the emulator)
1. **Foundation** — this delivery.
2. Install `firebase-admin`, run `firebase emulators:start --only firestore`, add emulator integration tests for `adminAdapter`, rules and indexes.
3. **Money core**: users, wallets, ledger, deposits, trxKeys, paymentProviders → switch `services/ledger.ts` + `deposits.ts` + `routes/webhooks.ts` + wallet routes.
4. **Orders**: products, variants, keys, orders, orderIdem.
5. **CMS**: categories, sections, buttons, notices, settings (largest, mostly mechanical).
6. **Operations**: admin users/roles, audit, notifications, tickets, broadcasts, reports (`dailyStats`).
7. **Data migration script** (Postgres → Firestore, idempotent, dry-run first, verifies per-wallet `sum(ledger) == balance`), then drop Prisma, `DATABASE_URL`, `docker-compose.yml`.

## Authentication
Telegram remains the identity provider. The API validates Telegram `initData` (signature, age) and issues its own short JWTs; `firebaseAuth.mintFirebaseToken` can additionally issue a Firebase custom token (`uid = tg_<id>`) once client-side Firebase is needed. Admin permissions are **never** read from a token claim: they are re-read from the database on each request, and money/credential/role actions require a fresh login.
Email/phone Firebase sign-in is not used.
