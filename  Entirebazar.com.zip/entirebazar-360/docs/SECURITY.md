# EntireBazar 360 — Security & error-handling notes

## Authentication
- Mini App sends Telegram `initData`; the API validates the HMAC with the bot token, checks `auth_date`
  freshness (`INIT_DATA_MAX_AGE`), and uses constant-time comparison. `initDataUnsafe` is never trusted.
- Separate JWT secrets/audiences for users (6h) and admins (2h). Tokens are held in browser memory only.
- Admin access requires the Telegram ID to be allow-listed (`ADMIN_TELEGRAM_IDS`) or present in `AdminUser`.
- Banned users are rejected on every request; restricted users cannot deposit or buy.

## Money
- **Ledger is the source of truth.** Every credit/debit is a `LedgerEntry`; `Wallet.balance` is a cache updated in the
  same DB transaction. The wallet row is locked (`SELECT … FOR UPDATE`) so concurrent operations serialise.
- **Idempotency:** unique `(refType, refId, direction)` on the ledger → a deposit, order or refund can affect the wallet once.
- **Only `finalizeDeposit()` credits deposits.** It locks the deposit row, requires `PENDING`, requires the verified
  amount to equal the invoice amount exactly, checks receiver number when known, enforces unique transaction references,
  and credits in one transaction.
- A user-submitted transaction ID never credits anything. It must be matched to a trusted record: a signed webhook,
  an approved provider API response, or an audited admin approval in manual-review mode.
- Duplicate references are blocked by DB uniqueness on `Deposit(providerId, providerTrxId)` and
  `Transaction(providerCode, providerTrxId)`.
- Amount mismatches and receiver mismatches are never credited; they set `needsReview` and alert admins.
- Checkout debits and allocates inventory (`FOR UPDATE SKIP LOCKED`) in a single transaction; insufficient funds or stock roll everything back.
- Frontend status is display-only; the receipt page polls the backend.

## Webhooks
HMAC-SHA256 over `timestamp.rawBody`, 5-minute replay window, constant-time compare, raw-body parsing,
environment check (a sandbox payload is rejected in production), idempotent on `(provider, trxId)`.

## Sandbox vs production
`PAYMENT_ENV` is stamped on every `Transaction` and checked on webhooks. Use separate databases, bot tokens,
secrets and provider credentials per environment.

## Secrets
All secrets are read server-side from env. `.env` is git-ignored. Only `NEXT_PUBLIC_API_URL` and
`NEXT_PUBLIC_BOT_USERNAME` are exposed to the browser. No provider credentials exist in frontend code.

## Hardening in place
helmet, CORS limited to `WEB_ORIGIN`, rate limits (global, auth, money endpoints), zod validation on bodies,
upload allow-list (png/jpg/webp, 2MB, random filenames), `frame-ancestors` limited to Telegram, generic 500 messages,
audit log for admin actions, delivery content only returned to the order owner.

## Error handling
- Telegram failures never break business flows: notifications are stored in-app first, then pushed; 403/blocked sets
  `botBlocked`, other errors are recorded on the notification (`telegramError`) and visible in Admin → Notify.
  429 responses are retried once for short `retry_after`.
- Broadcasts are claimed atomically (no double send), throttled (~25 msg/s), and record sent/failed/blocked counts.
- Expired invoices are closed by the worker; pending API verifications are retried every minute until expiry.

## Before going live
- Replace Terms/Privacy templates; confirm legal/regulatory requirements for holding customer balances in your country.
- Add automated tests, error monitoring, DB backups, and move uploads to object storage.
- Consider 2-person approval for large manual deposit approvals and refunds.

## CMS, builders and admin panel (v2)
- **Admin sign-in:** Telegram `initData` must be younger than `ADMIN_INIT_DATA_MAX_AGE` (default 10 min), the ID must be an
  active `AdminUser` (or bootstrap-listed), tokens last 2h. Sensitive permissions (`wallet.adjust`, `orders.refund`,
  `deposits.review`, `integrations.*`, `roles.manage`) additionally require a token issued within `ADMIN_FRESH_SECONDS`;
  otherwise the API answers `REAUTH_REQUIRED` and the admin reopens the Mini App. Permissions are re-read from the database on every request.
- **Authorisation:** every admin route declares `requirePerm(...)`; denied attempts are written to the audit log. Admins cannot grant
  permissions they do not hold, cannot change their own role, and the last active owner cannot be removed.
- **Layout content is data, not code.** Section configs, buttons, notices, FAQ and settings are validated by zod schemas
  (`lib/layoutSchema.ts`): closed set of section types, unknown keys stripped, HTML/`javascript:` rejected in text, images limited to
  uploaded files or https raster images (no SVG), no free-form scripts or styles. The Mini App renders everything as React text nodes
  (no `dangerouslySetInnerHTML`). The frontend `assetUrl` re-checks image URLs.
- **Buttons only navigate.** Destinations are validated when saved and **again on every read**: categories/products must exist and be visible,
  external links must be https and on the host allow-list, Telegram links are built from a validated username. "Start purchase" opens the
  product page; payment still goes through authenticated checkout with server-side price, stock, balance and idempotency checks.
- **Pricing is server-authoritative** (`lib/pricing.ts`): integer minor units, single best discount, never stacked; the client's price is ignored.
- **Uploads:** memory storage, 2 MB cap, type decided from magic bytes (PNG/JPEG/WebP), random 32-hex names, SVG refused.
- **Integration secrets:** AES-256-GCM with the key from `SECRETS_ENCRYPTION_KEY` (never stored), each secret bound to its provider/mode/name;
  the API only returns "saved or not"; errors are scrubbed of secret values before being stored or shown; sandbox and production are separate slots.
- **Public responses** never include admin notes, delivery data of other users, secrets, or private user fields. Notices are public content:
  do not put personal data in them.
