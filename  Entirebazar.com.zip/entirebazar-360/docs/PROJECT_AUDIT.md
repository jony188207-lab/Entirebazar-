# PROJECT AUDIT — EntireBazar 360 (before the Firebase / Firestore / Backblaze B2 move)

Audited: the project ZIP as uploaded (`entirebazar-360-cms.zip` tree). Method: reading the code, grep over every source file,
running the existing tests. Status words: **OK** = verified by reading/tests, **NOT TESTED** = could not be run in the audit environment,
**PROBLEM** = needs a change.

Environment limits during this audit: npm registry blocked (no `npm install`, so no `firebase-admin`, no Prisma engine, no `next build`),
no PostgreSQL, no Firestore emulator, no Telegram, no Backblaze account. Everything below respects that.

## 1. What the code does today

| Area | Today | Notes |
|---|---|---|
| Database | PostgreSQL + Prisma 5, **32 models**, 9 `@@unique` constraints that carry correctness (idempotency, duplicate TrxID) | `apps/api/prisma/schema.prisma` |
| Prisma usage | **~380 calls in 22 files** (routes 4,000 lines of query code, services ~1,900) | see table in §2 |
| Auth (customers) | Telegram `initData` validated server-side (HMAC, 1h) → 2h JWT held **in memory** by the web client | `lib/telegramAuth.ts`, `routes/user.ts` |
| Auth (admins) | Same, but 10 min initData window, `AdminUser` lookup, permissions re-read from DB per request, fresh token (30 min) for money/credential/role actions | `middleware/auth.ts` |
| Firebase | **Not connected.** No Firebase package, config, rules or indexes exist | |
| Uploads | Backblaze B2 (S3-compatible, own SigV4 presign in `lib/s3sign.ts`); public bucket for images, private bucket for paid files with 15-min presigned downloads; local disk only when `STORAGE_DRIVER=local` and **refused in production** | OK (unit-tested signing; **NOT TESTED** against real B2) |
| Old image URLs | `/uploads/<32hex>.ext` redirect (301) to B2; `scripts/migrate-uploads-to-b2.ts` uploads and rewrites DB references | OK by reading; **NOT TESTED** (needs DB + B2) |

## 2. Where Prisma is used (this is the migration surface)

| File | Calls | Why it is hard to move |
|---|---|---|
| routes/admin/ops.ts | 66 | dashboard/report aggregates via raw SQL `date_trunc`/`SUM`/`GROUP BY`; user, role, audit queries |
| routes/admin/catalog.ts | 64 | category tree, sections, buttons, ordering |
| routes/admin/products.ts | 48 | product + variants + keys + category sync |
| routes/user.ts | 38 | public reads with joins and `include` |
| services/deposits.ts | 32 | **money**: `finalizeDeposit` with `SELECT … FOR UPDATE` |
| routes/admin/money.ts | 25 | approvals, refunds, adjustments |
| services/pages.ts | 20 | category page builder (liveness over ancestors, joins) |
| services/orders.ts | 19 | **money + stock**: `FOR UPDATE SKIP LOCKED` key claiming, idempotent checkout |
| prisma/seed.ts, bot/index.ts, cms.ts, integrations.ts, broadcast.ts, secrets.ts, notify.ts, ledger.ts, settings.ts, catalog.ts, admin/index.ts, auth.ts, webhooks.ts | 3–16 each | |

Raw SQL / row locks that have **no Firestore equivalent** and need a redesign:
`ledger.ts` (wallet row `FOR UPDATE`), `deposits.ts` (deposit `FOR UPDATE`), `orders.ts` (`FOR UPDATE SKIP LOCKED` ×2 for licence keys, order `FOR UPDATE`),
`ops.ts` (four reporting queries with `date_trunc`, `SUM`, `GROUP BY`).

## 3. Problems found

### P1 — Blocking for the Firebase move
1. **Relational model, relational queries.** Joins/`include`, `groupBy`, `_count`, nested `where` over relations, `OR`/`NOT` filters and `contains` text search are used throughout. Firestore has none of these; each needs a denormalised field, a second read, or an index.
2. **Row locking is the concurrency model for money and stock.** Firestore has optimistic transactions only (reads before writes, automatic retry, 500 writes). Idempotency must be re-expressed as **document IDs** (e.g. ledger entry id = `${refType}_${refId}_${direction}`), which turns the current `@@unique` constraints into `create()` that fails if the document exists.
3. **Licence-key claiming** (`SKIP LOCKED`) must become a transaction that reads N unused keys of a product/variant and marks them used; it needs a composite index and bounded batch size. Contention on one hot product is possible (≈1 sustained write/sec per document is the Firestore guideline).
4. **Reports** (revenue/deposits/signups per day, top products) cannot be computed by SQL. Needs Firestore aggregation queries (`count`, `sum`) with date range + composite indexes, or pre-aggregated daily counter documents written in the same transaction as the event.
5. **Money type.** Prisma `Decimal(12,2)/(14,2)`. Firestore numbers are IEEE doubles → must store **integer minor units (paisa)** or strings; never floats.
6. **Telegram IDs are `BigInt`.** Firestore has no 64-bit integer type for JS clients safely beyond 2^53. Telegram IDs fit today (< 2^52) but should be stored as **strings** and used as the user document ID.
7. **Admin "who am I" depends on SQL joins** (`AdminUser` + custom `Role`). Easy to move (small collections) but the permission check runs on every request: needs caching with short TTL to avoid a Firestore read per request.

### P2 — Security / secrets
1. `.gitignore` only listed `.env`: **`.env.local`, `.env.production`, `.env.*`, `*.pem`, Firebase service-account JSON were NOT ignored.** A normal `firebase` or Next.js setup would have committed them. **Fixed in this change** (see `.gitignore`).
2. No real secret is present in the tree (pattern scan for Telegram tokens, `AKIA…`, `AIza…`, PEM blocks, `sk_live`: only the AWS *documentation example key* inside `test/storage.test.ts`, which is the public example from the AWS docs).
3. `docker-compose.yml` contains `POSTGRES_PASSWORD: market` — dev-only default; must not be used in production (README now says so).
4. `.env.example` placeholders `JWT_SECRET=change-me-…`: production start-up already refuses secrets shorter than 32 chars. OK.
5. `NEXT_PUBLIC_*` only carries `API_URL` and `BOT_USERNAME`. Firebase **web** config (apiKey etc.) is public by design, but Firebase **Admin** credentials and B2 keys must stay server-only. OK so far; documented in `docs/ENV.md`.
6. If the repo was ever pushed with a secret: deleting the file is not enough — **rotate the secret** (Telegram `/revoke`, B2 key delete, Firebase key delete). A scan of git history is **NOT TESTED** here (the ZIP contains no `.git`).

### P3 — Correctness / completeness
1. Payment provider adapters (bKash, Nagad, Rocket, Upay, Bitcoin, digital-service) are **not implemented** (`implemented:false`). They display as *Not implemented*. Correct and unchanged.
2. `PAYMENT_ENV` default `sandbox`; production start warns when mismatched. OK.
3. Local upload code path still exists for development (`STORAGE_DRIVER=local`); production refuses it. OK. `multer` memory storage, 2 MB images / 25 MB files, magic-byte checks. OK.
4. Telegram: initData validation, constant-time HMAC compare, age limits. OK. Bot notifications respect blocked users (`TelegramDelivery.BLOCKED`). OK (**NOT TESTED** against real Telegram).
5. Wallet ledger: unique `(refType, refId, direction)` + wallet row lock → idempotent credits/debits; `WalletAdjustment` + audit. OK by tests of pure logic; **DB-level behaviour NOT TESTED** (no PostgreSQL available).
6. Tests present: 45 API unit tests + 5 web render tests, all pure-logic. **No test touches a database.**

## 4. Decision for the Firebase migration

Replacing ~380 relational calls and 8 locking queries in money-critical code **without being able to install `firebase-admin`, typecheck against it, or run any Firestore emulator** would mean shipping unverified financial code. The instruction for this task is also not to remove Prisma until Firestore is shown to replace it. Therefore:

- Prisma **stays the active runtime** until each phase in `docs/FIRESTORE_MIGRATION.md` passes its emulator tests.
- Firebase artefacts that can be done and checked now are delivered: collection design, security rules, indexes, `firebase.json`, env contract, secret hygiene, B2 verification.
- Whatever is added but not yet used by running code is labelled **NOT WIRED** in the README feature table.

(Superseded/extended by the progress report at the end of the delivery message.)
