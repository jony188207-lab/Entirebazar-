# API integrations: what is real, and how to add one

The **API Integrations** page (Admin → API integrations) reads its data from the adapters in `apps/api/src/payments/providers.ts`.
A provider is shown as **Connected** only when *all* of these are true:

1. its adapter is **implemented** (`meta.implemented = true`, real calls in `verifyTransaction` / `testConnection`),
2. credentials exist for the active mode (encrypted in the database, or environment variables),
3. it is **enabled**, in a mode that matches the server's `PAYMENT_ENV`,
4. a **server-side connection test** has succeeded (within 24 h).

Saving a form, or having a URL and a key, proves nothing. States: `NOT_IMPLEMENTED`, `MISSING_CREDENTIALS`, `DISABLED`, `MODE_MISMATCH`,
`UNTESTED`, `TEST_FAILED`, `CONNECTED`.

## Current status

| Integration | Adapter | Notes |
|---|---|---|
| bKash | slot only (`implemented: false`) | Needs merchant approval, credentials and an adapter written from bKash's official docs |
| Nagad | slot only | Same |
| Rocket | slot only | No public API assumed: use manual review or an approved aggregator |
| Upay | slot only | Same |
| Bitcoin (future) | slot only | Needs an invoice + confirmations adapter |
| Digital service API (future) | slot only | For supplier APIs (top-ups, key vendors) |
| Manual review | built in | Admin compares the transaction in the merchant app and approves (audited, amount re-typed) |
| Signed webhook (`POST /webhooks/payments`) | built in | For a verification source you operate or contract; HMAC + replay window + idempotency |

No endpoint, signature scheme or payload of bKash/Nagad/Rocket/Upay is invented in this codebase.

## Adding a provider that has no adapter (requires development)

Entering a URL and API key in the panel is **not** enough: a developer must write the adapter.

1. **Get approval and docs** from the provider (merchant agreement, sandbox credentials, official API reference).
2. In `payments/providers.ts` add (or edit) an adapter implementing `PaymentProviderAdapter` (`payments/types.ts`):
   - `meta`: `code`, `name`, `kind`, `summary`, `requiresApproval`, `secrets` (credential field names), `settings` (non-secret fields), `instructions`.
   - `isConfigured()`: use `getSecret(code, NAME)` / `getSetting(code, NAME)` from `services/secrets.ts`. Never read secrets any other way.
   - `testConnection()`: a **read-only** call (e.g. obtain a token). Never move money. Throw or return `{ ok: false, message }` on failure.
   - `verifyTransaction({ trxId, amount, receiver })`: ask the provider whether that exact transaction exists, was received, in that amount, to that receiver.
     Return `found` / `not_found` / `unsupported` / `error`. Only `found` can credit.
   - Set `implemented: true` and `capabilities().apiVerification = true` **only after** testing against the provider's sandbox.
3. Add a row for the code in `prisma/seed.ts` (a `PaymentProvider`), then run the seed.
4. Write tests with recorded provider responses (success, wrong amount, wrong receiver, duplicate, timeout).
5. In the panel: save sandbox credentials → run the connection test → enable → set the payment method's verification to *Automatic*.
   Switch to production by deploying with `PAYMENT_ENV=production`, saving production credentials, and repeating the test.

All crediting goes through `finalizeDeposit()`, which enforces: pending status, exact amount, receiver, unique transaction reference per provider,
and a single idempotent ledger credit inside one DB transaction.

## Secrets

- Preferred: environment variables `<CODE>_<NAME>` (e.g. `BKASH_APP_KEY`), which apply to the server's active `PAYMENT_ENV` only.
- Or save them in the panel: requires `SECRETS_ENCRYPTION_KEY` (32 bytes). They are encrypted at rest (AES-256-GCM), never returned by the API
  (only "saved / not saved"), never logged, and replaced, not revealed.
- Never put credentials in `NEXT_PUBLIC_*` variables, frontend code, JSON files, or commit them.
