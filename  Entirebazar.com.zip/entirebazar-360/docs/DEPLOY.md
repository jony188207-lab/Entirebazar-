# Deploy, step by step

Current runtime = Express API + **PostgreSQL (Prisma)** + Next.js web + Telegram bot. Firestore is a prepared, not-yet-wired migration (`docs/FIRESTORE_MIGRATION.md`).
Nothing below was executed by the author (no network/DB/Telegram in the build environment): follow it on a staging copy first.

## 1. Accounts and secrets
1. **Telegram**: @BotFather → create/keep your bot → copy the token (`BOT_TOKEN`). Never paste it in chat, GitHub or the browser.
2. **PostgreSQL**: any managed Postgres 14+ (Neon, Supabase, Render, Railway). Copy `DATABASE_URL`. Do not use the docker-compose password in production.
3. **Backblaze B2**: create two buckets.
   - `…-public` (**Public**): product/category images. Public base URL = `https://f00X.backblazeb2.com/file/<bucket>` (or your CDN domain).
   - `…-private` (**Private**): paid downloads, served only through 15-minute presigned URLs.
   - App Keys → create one key restricted to these two buckets (read, write, delete). Note `keyID`, `applicationKey`, the bucket S3 endpoint (e.g. `s3.us-west-004.backblazeb2.com`) and region (`us-west-004`).
4. **Random secrets**: `openssl rand -base64 48` ×2 (JWT, admin JWT), `openssl rand -base64 32` (`SECRETS_ENCRYPTION_KEY`).
5. (Later) **Firebase** project, Firestore in production mode (keeps the deny-all rules), service account key → env only.

## 2. API (Render / Railway / VPS)
1. Root: `apps/api`. Build: `npm ci && npx prisma generate && npm run build`. Release/pre-start: `npx prisma migrate deploy`. Start: `npm start`.
2. Set every **Server** variable from `docs/ENV.md` (`NODE_ENV=production`, `STORAGE_DRIVER=b2`, `B2_*`, `WEB_ORIGIN`, `PAYMENT_ENV` …). Start-up refuses weak JWT secrets, `STORAGE_DRIVER=local`, and missing B2 settings.
3. Run **two more processes** from the same build: bot (`npm run bot`) and worker (`npm run worker`), one instance each.
4. First time only: generate the migration locally (`npx prisma migrate dev --name init`, commit `prisma/migrations`) and run `npm run seed`.
5. Check `https://api.yourdomain.com/health`.

## 3. Web (Vercel)
1. Root: `apps/web`. Environment: `NEXT_PUBLIC_API_URL=https://api.yourdomain.com`, `NEXT_PUBLIC_BOT_USERNAME=…`. **Redeploy after changing them** (build-time values).
2. The build fails on purpose if `NEXT_PUBLIC_API_URL` is missing, not https, or localhost.

## 4. Telegram
@BotFather → `/mybots` → Bot Settings → Menu Button (or `/newapp`) → set the web URL (`MINI_APP_URL`). Put your numeric Telegram ID in `ADMIN_TELEGRAM_IDS`, open the Mini App, then `/admin`.

## 5. Move old images to B2
```
cd apps/api
npx tsx scripts/migrate-uploads-to-b2.ts                    # dry run
npx tsx scripts/migrate-uploads-to-b2.ts --apply            # upload
# back up the database, then:
npx tsx scripts/migrate-uploads-to-b2.ts --apply --rewrite  # rewrite "/uploads/<hex>.ext" to the B2 URL
```
Old references keep working before and after: `GET /uploads/<hex>.ext` on the API redirects (301) to B2.

## 6. Verify (all NOT TESTED by the author)
Open the Mini App from Telegram; sign in; create a category in `/admin`, upload an image (URL must be your B2 base URL), add a section/button/notice and see it in the app; run a manual deposit end to end; approve it with the typed amount; buy a product; check the audit log.

## 7. GitHub hygiene
Check `docs/ENV.md` ("Secret hygiene checklist"), enable secret scanning + push protection, never commit `.env*`.
