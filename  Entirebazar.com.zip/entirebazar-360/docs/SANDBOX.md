# EntireBazar 360 — Sandbox testing

Use `PAYMENT_ENV=sandbox`, a separate test bot, and a throw-away database.

## 1. Manual-review flow (no provider credentials needed)
1. Admin → Providers: pick a provider, set **Manual review**, set a receiving number and instructions, **Enable**.
2. In the Mini App: Wallet → Add money → choose provider → amount → Continue → enter any trx ID (6–24 chars A-Z/0-9) → Submit.
3. Receipt shows **PENDING**; the user gets a "Deposit pending" notification; admins get an alert.
4. Admin → Deposits (Needs review) → **Approve (manual)**. Balance is credited once; a second click is a no-op.
5. Try **Reject** on another deposit and confirm the user is notified and nothing is credited.

## 2. Signed-webhook flow (simulates an authorised verification source)
Set `PAYMENT_WEBHOOK_SECRET` in `.env`, restart the API, enable a provider in manual-review or API-capable mode, create an invoice, submit trx ID `TESTTRX001`, then:
```
PAYMENT_WEBHOOK_SECRET=... node scripts/sign-webhook.mjs bkash TESTTRX001 <exact amount> <receiver number>
```
Expected: deposit → SUCCESSFUL, wallet credited, "Deposit verified" notification.
The webhook may also arrive *before* the user submits the ID; it is stored and matched on submission.

## 3. Negative tests (all must NOT credit)
- Webhook with wrong amount → deposit stays pending, flagged for review, admin alerted.
- Wrong receiver number → flagged for review.
- Bad signature / stale timestamp → 401.
- `environment: "production"` payload while `PAYMENT_ENV=sandbox` → 409.
- Replaying the same webhook → `{duplicate:true}`, no second credit.
- Submitting a trx ID already used by another deposit → "already been used".
- Invoice past `expiresAt` → worker marks EXPIRED.

## 4. Orders
Seed creates "Demo License Key" (3 keys, price 100). Fund the wallet, buy it, confirm: debit entry, key delivered
once, notifications sent, stock drops, concurrent buys never hand out the same key. Request a refund, then refund
from Admin → Refunds and confirm a single credit entry.

## 5. Suggested automated tests
- `postEntry`: duplicate `(refType, refId, direction)` returns the existing entry; overdraft throws.
- `finalizeDeposit`: called twice concurrently → exactly one ledger credit.
- Webhook signature: valid, tampered body, stale timestamp.
- `validateInitData`: valid, tampered, expired.
