# EntireBazar 360 — Telegram Mini App for Digital Products

Next.js Mini App + Express/Prisma API + Telegram bot, with a ledger-based wallet,
verified-only deposit crediting, notifications, announcements and an admin panel.

```
apps/api   Express + Prisma + Telegraf  (API, bot process, worker process)
apps/web   Next.js 14 + Tailwind        (Mini App at /, admin panel at /admin; brand assets in public/, name in lib/brand.ts)
docs/      PROJECT_AUDIT, FIRESTORE_MIGRATION, ENV, DEPLOY, SECURITY, INTEGRATIONS, SANDBOX
scripts/   sign-webhook.mjs (sandbox helper)
```

## What this is

A dynamic marketplace managed from an admin panel. Categories, sub-categories, page sections, buttons, notices, banners,
products and homepage layout are **database content**: change them in `/admin` and the Mini App reflects it without a deploy.

- **Category builder** (11 tabs: General, Layout & Sections, Products, Buttons, Notices, Filters & Sorting, Pricing, FAQ & Support, SEO & Display, Visibility & Scheduling, Preview).
- **Section builder**: 14 validated section types (product grid, featured, banner, notice, rich text, image, button group, category grid, FAQ, how it works, support, terms, countdown, empty state). No custom HTML or JavaScript is accepted or executed.
- **Button builder**: 10 actions that only *navigate* (validated on save and on every read). A button can never bypass login, payment, stock or permission checks.
- **Notices/banners**: scoped to everyone / categories / products / pages, scheduled, prioritised, dismissible, optional Telegram broadcast.
- **Products**: variants, multi-category, FAQ, notices, types (digital, subscription, licence key, service, download, manual). Manual products go to a *processing* queue for staff fulfilment.
- **Admin modules**: Dashboard, Categories, Products, Sections, Buttons, Notices, Payments, API Integrations, Users, Orders, Wallet & Deposits, Support, Telegram notifications, Reports, Settings, Roles & Permissions, Audit log.
- **Wallet**: ledger-based, idempotent credits, auditable admin adjustments, refunds.

## Feature status

**Completed (code written, unit-tested or typechecked):** everything listed above, RBAC with custom roles, fresh-login for sensitive actions,
encrypted integration secrets, secure image upload, server-side pricing, audit log, maintenance mode.

**Partial / needs your action:**
- Payment adapters for bKash, Nagad, Rocket, Upay, Bitcoin and digital-service APIs are **slots only** (`implemented:false`). They show as *Not implemented* in
  Admin → API Integrations and cannot be enabled in API mode. Use manual review or the signed webhook until an adapter is written
  (see `docs/INTEGRATIONS.md`). They need merchant approval and credentials from each provider.
- Telegram bot messages only reach users who have started the bot and not blocked it; failures are recorded under delivery errors.
- Terms/Privacy are templates: have them reviewed before launch.

**Firebase / Firestore / Backblaze B2 (this update):**
- Backblaze B2 uploads: implemented and wired (images → public bucket, paid files → private bucket with presigned downloads; local disk refused in production; `/uploads/<hex>` redirects to B2; migration script). Signing is unit-tested; **NOT TESTED against a real B2 bucket**.
- Firestore: **NOT WIRED.** Prisma/PostgreSQL is still the running database. Delivered and unit-tested on an in-memory model: collection design, deny-all `firestore.rules`, `firestore.indexes.json`, wallet ledger, deposit finalisation and key-claiming logic (`apps/api/src/firestore/`). **NOT TESTED** on a real Firestore or emulator. Plan and phases: `docs/FIRESTORE_MIGRATION.md`.
- Firebase Authentication: only a custom-token helper exists (**NOT WIRED, NOT TESTED**); login is still Telegram `initData` → API JWT.
- Fixed: production web build now fails when `NEXT_PUBLIC_API_URL` is missing/localhost; `.gitignore` now blocks `.env.*`, service-account JSON and keys.
- Audit of the previous state: `docs/PROJECT_AUDIT.md`. Environment variables: `docs/ENV.md`. Deploy steps: `docs/DEPLOY.md`.

**Not verified in the environment that produced this code** (no npm registry / Prisma engines / database / Firebase / B2 / Telegram access):
`prisma migrate`/`generate`, `next build`, `firebase-admin`, any database-backed end-to-end test, and tests against a real bot, bucket or payment provider.
Passing: 53 API unit tests (`npm test -w apps/api`), 5 web render-safety tests (`npm test -w apps/web`, needs esbuild installed), and stub-based typechecks.
Expect to fix a few type errors on the first `npm run typecheck`/build.

## Setup

Requirements: Node 20+, Docker (for Postgres), a Telegram bot from @BotFather.

1. `cp .env.example .env` and fill in `BOT_TOKEN`, `BOT_USERNAME`, `JWT_SECRET`, `ADMIN_JWT_SECRET`
   (32+ random chars each), `ADMIN_TELEGRAM_IDS` (your numeric Telegram ID), `MINI_APP_URL`.
   Also set `SECRETS_ENCRYPTION_KEY` (`openssl rand -base64 32`) if you want to save integration credentials in the panel.
   Optional: `ADMIN_INIT_DATA_MAX_AGE`, `ADMIN_FRESH_SECONDS`, `MAX_WALLET_ADJUSTMENT`, `UPLOAD_DIR` (see `.env.example`).
   Put the web vars in `apps/web/.env.local` (`NEXT_PUBLIC_API_URL`).
2. `docker compose up -d` then `npm install` (repo root).
3. Create the schema and the first migration (commit the generated `prisma/migrations`):
   ```
   cd apps/api
   npx prisma migrate dev --name init     # dev
   npx prisma migrate deploy              # production
   npm run seed                           # providers (all DISABLED), demo category + product
   ```
4. Run (separate terminals): `npm run dev:api`, `npm run dev:bot`, `npm run worker -w apps/api`, `npm run dev:web`.
5. Telegram needs an HTTPS URL for the Mini App. Expose the web app (and API) with a tunnel or deploy,
   then in @BotFather: `/newapp` (or set the menu button) to your `MINI_APP_URL`.
   Set `WEB_ORIGIN` on the API to the web origin and `NEXT_PUBLIC_API_URL` to the API's public URL.
6. Open the bot → Mini App. Admin panel: `<MINI_APP_URL>/admin` (your Telegram ID must be in
   `ADMIN_TELEGRAM_IDS` or in the `AdminUser` table).

There is deliberately no "dev login" bypass: auth always validates signed Telegram `initData`.

## Payments: what works and what needs approval

| Provider | Out of the box | Needs |
|---|---|---|
| bKash, Nagad | **Manual review** or **signed webhook** | Merchant approval + credentials, then implement `verifyTransaction` in `apps/api/src/payments/providers.ts` from the provider's *official* docs |
| Rocket, Upay | **Manual review** or **signed webhook** | No public API is assumed. Use an approved aggregator / verification service |
| Bitcoin | Shown as "coming soon", cannot be enabled | Implement an adapter (invoice + confirmations) later; the wallet/ledger need no changes |

All providers are seeded **disabled**. In Admin → Providers choose a mode:

- **Manual review**: user submits trx ID → deposit flagged `needsReview` → admin alert → an admin confirms in their
  merchant account, then clicks *Approve* (audited). Nothing is auto-credited.
- **API**: only selectable when the adapter is configured *and* implemented. Otherwise the admin API refuses it.
- **Signed webhook** (`POST /webhooks/payments`): for an authorised verification source you operate or contract with.
  The request format is this app's own contract (documented in `routes/webhooks.ts`), not any provider's API.

## Deployment

- API: `npm run build -w apps/api && npm run prisma:deploy -w apps/api && npm start -w apps/api`.
  Run `bot` and `worker` as separate long-running processes (one instance each).
  Set `NODE_ENV=production` and `PAYMENT_ENV=production` only when using production credentials.
- Web: `npm run build -w apps/web && npm start -w apps/web` (or Vercel). Only `NEXT_PUBLIC_*` vars reach the browser.
- Put the API behind HTTPS and a reverse proxy; `trust proxy` is set to 1.
- Images and files are stored in Backblaze B2 (`STORAGE_DRIVER=b2`); local disk is development-only. See `docs/DEPLOY.md`.
- Back up Postgres. The ledger is your financial record.

## Known gaps / next steps

- Provider API adapters are slots by design, pending merchant approval (docs/INTEGRATIONS.md).
- "Selected users" broadcast takes internal user IDs; there is no multi-select picker yet.
- Add database-backed integration tests (ledger idempotency, `finalizeDeposit`, category CRUD) once a Postgres is available.
- Docs: `docs/SECURITY.md`, `docs/INTEGRATIONS.md`, `docs/SANDBOX.md`.

## Branding

The app is branded **EntireBazar 360**.

- Visible name: `apps/web/lib/brand.ts` (`APP_NAME`); bot/server name: `APP_NAME` env var (default "EntireBazar 360").
- Logo: `apps/web/public/logo.svg` (light backgrounds), `logo-light.svg` (dark backgrounds), `logo-mark.svg`, `logo.png`;
  rendered by `components/Logo.tsx`, which follows Telegram's light/dark theme.
- Icons/manifest: `app/icon.svg`, `app/favicon.ico`, `public/icons/*`, `public/apple-touch-icon.png`, `public/manifest.webmanifest`.
- The Telegram bot **username** is unchanged. To rename the bot's display name, use @BotFather (`/setname`) or set
  `SYNC_BOT_PROFILE=true` for one startup. Set the Mini App's title/icon in @BotFather (`/mybots` → Bot Settings → Menu Button / `/editapp`).
