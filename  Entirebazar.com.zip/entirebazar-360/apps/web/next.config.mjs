// Fail the production build instead of shipping an app that calls localhost.
if (process.env.NODE_ENV === "production") {
  const api = process.env.NEXT_PUBLIC_API_URL ?? "";
  if (!/^https:\/\/[^/\s]+/i.test(api) || /localhost|127\.0\.0\.1/.test(api)) {
    throw new Error("NEXT_PUBLIC_API_URL must be the public https URL of the API (e.g. https://api.example.com) for production builds.");
  }
}

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          // Mini Apps are embedded by Telegram clients; only allow framing by Telegram web origins.
          { key: "Content-Security-Policy", value: "frame-ancestors https://web.telegram.org https://*.telegram.org;" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "no-referrer" },
        ],
      },
    ];
  },
};
export default nextConfig;
