"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Fragment, useEffect, useState } from "react";
import { api, assetUrl, money, tg } from "@/lib/api";

/* =====================================================================
 * Safe renderers for admin-configured content.
 * Everything here renders as React text nodes. There is NO dangerouslySetInnerHTML, no eval, and
 * no admin-supplied URL is ever used unless the server has already validated and resolved it.
 * ===================================================================== */

export type Nav = { kind: "route"; path: string } | { kind: "external"; url: string } | { kind: "telegram"; url: string };
export interface ResolvedButton {
  id: string; label: string; icon: string | null; style: string; size: string; placement: string; nav: Nav;
  confirm: { title: string; message: string } | null;
}

export function SafeImg({ src, alt = "", className }: { src?: string | null; alt?: string; className?: string }) {
  const u = assetUrl(src);
  if (!u || !/^https?:\/\//.test(u)) return null; // only absolute http(s) URLs (uploads are made absolute by assetUrl)
  // eslint-disable-next-line @next/next/no-img-element
  return <img src={u} alt={alt} className={className} loading="lazy" referrerPolicy="no-referrer" />;
}

/** Minimal markdown subset rendered as React elements: paragraphs, "- " lists and **bold**. Nothing else is interpreted. */
export function Md({ text, className = "" }: { text: string; className?: string }) {
  const inline = (s: string) =>
    s.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
      part.startsWith("**") && part.endsWith("**") && part.length > 4 ? <strong key={i}>{part.slice(2, -2)}</strong> : <Fragment key={i}>{part}</Fragment>
    );
  const blocks = text.replace(/\r/g, "").split(/\n{2,}/);
  return (
    <div className={`space-y-2 ${className}`}>
      {blocks.map((b, i) => {
        const lines = b.split("\n");
        if (lines.every((l) => /^\s*[-•]\s+/.test(l))) {
          return <ul key={i} className="list-disc space-y-1 pl-5">{lines.map((l, j) => <li key={j}>{inline(l.replace(/^\s*[-•]\s+/, ""))}</li>)}</ul>;
        }
        return <p key={i} className="whitespace-pre-line">{inline(b)}</p>;
      })}
    </div>
  );
}

export function confirmAsk(text: string): Promise<boolean> {
  return new Promise((res) => {
    const w = tg();
    if (w?.showConfirm) w.showConfirm(text, (ok: boolean) => res(!!ok));
    else res(typeof window !== "undefined" ? window.confirm(text) : false);
  });
}

export function useGo() {
  const router = useRouter();
  return async (b: Pick<ResolvedButton, "nav" | "confirm">) => {
    if (b.confirm && !(await confirmAsk(`${b.confirm.title}\n\n${b.confirm.message}`))) return;
    const n = b.nav;
    if (n.kind === "route") router.push(n.path);
    else if (n.kind === "telegram") {
      const w = tg();
      if (w?.openTelegramLink) w.openTelegramLink(n.url);
      else window.open(n.url, "_blank", "noopener,noreferrer");
    } else {
      const w = tg();
      if (w?.openLink) w.openLink(n.url);
      else window.open(n.url, "_blank", "noopener,noreferrer");
    }
  };
}

const BTN_STYLE: Record<string, string> = {
  PRIMARY: "bg-brand text-brandfg",
  SECONDARY: "bg-card text-fg border border-line",
  OUTLINE: "border border-brand text-brand",
  DANGER: "bg-red-600 text-white",
  LINK: "text-brand underline",
};
const BTN_SIZE: Record<string, string> = { SM: "px-3 py-1.5 text-sm", MD: "px-4 py-3", LG: "px-5 py-4 text-lg" };

export function ActionButtons({ buttons, layout = "ROW", disabled = false }: { buttons?: ResolvedButton[]; layout?: "ROW" | "STACK" | "GRID"; disabled?: boolean }) {
  const go = useGo();
  if (!buttons?.length) return null;
  const wrap = layout === "STACK" ? "flex flex-col gap-2" : layout === "GRID" ? "grid grid-cols-2 gap-2" : "flex flex-wrap gap-2";
  return (
    <div className={wrap}>
      {buttons.map((b) => (
        <button
          key={b.id}
          type="button"
          disabled={disabled}
          onClick={() => void go(b)}
          className={`rounded-xl font-semibold active:opacity-80 ${BTN_STYLE[b.style] ?? BTN_STYLE.PRIMARY} ${BTN_SIZE[b.size] ?? BTN_SIZE.MD} ${layout === "STACK" ? "w-full" : ""}`}
        >
          {b.icon ? `${b.icon} ` : ""}{b.label}
        </button>
      ))}
    </div>
  );
}

/* ---------------- Notices ---------------- */
const TONE: Record<string, string> = {
  INFO: "bg-blue-500/10 text-blue-700 dark:text-blue-300",
  PROMO: "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300",
  WARNING: "bg-amber-500/15 text-amber-700 dark:text-amber-300",
  MAINTENANCE: "bg-red-500/10 text-red-700 dark:text-red-300",
  PAYMENT: "bg-indigo-500/10 text-indigo-700 dark:text-indigo-300",
  ORDER: "bg-sky-500/10 text-sky-700 dark:text-sky-300",
  UPDATE: "bg-violet-500/10 text-violet-700 dark:text-violet-300",
};

export function Notices({ items, readOnly = false }: { items?: any[]; readOnly?: boolean }) {
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  if (!items?.length) return null;
  const shown = items.filter((n) => !hidden.has(n.id));
  if (!shown.length) return null;
  async function dismiss(id: string) {
    setHidden((h) => new Set(h).add(id));
    if (!readOnly) await api(`/notices/${id}/dismiss`, { method: "POST", body: {} }).catch(() => undefined);
  }
  return (
    <div className="space-y-2">
      {shown.map((n) => (
        <div key={n.id} className={`relative rounded-xl p-3 ${TONE[n.type] ?? TONE.INFO}`}>
          {n.dismissible && !readOnly && (
            <button aria-label="Dismiss" onClick={() => void dismiss(n.id)} className="absolute right-2 top-2 text-lg leading-none opacity-60">×</button>
          )}
          <SafeImg src={n.imageUrl} className="mb-2 max-h-40 w-full rounded-lg object-cover" />
          <div className="pr-6 font-semibold">{n.pinned ? "📌 " : ""}{n.icon ? `${n.icon} ` : ""}{n.title}</div>
          <Md text={n.body} className="text-sm opacity-90" />
          {n.buttons?.length > 0 && <div className="mt-2"><ActionButtons buttons={n.buttons} disabled={readOnly} /></div>}
        </div>
      ))}
    </div>
  );
}
/** Backwards-compatible name used by older screens. */
export const Announcements = Notices;

export function Banners({ items }: { items?: any[] }) {
  const go = useGo();
  if (!items?.length) return null;
  return (
    <div className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-1">
      {items.map((a) => (
        <div key={a.id} className="min-w-[85%] snap-center overflow-hidden rounded-2xl bg-brand text-brandfg">
          <SafeImg src={a.imageUrl} className="h-28 w-full object-cover" />
          <div className="p-3">
            <div className="font-bold">{a.icon ? `${a.icon} ` : ""}{a.title}</div>
            <div className="line-clamp-2 text-sm opacity-90">{a.body}</div>
            {a.buttons?.length > 0 && (
              <div className="mt-2 flex flex-wrap gap-2">
                {a.buttons.map((b: ResolvedButton) => (
                  <button key={b.id} onClick={() => void go(b)} className="rounded-lg bg-white/90 px-3 py-1.5 text-sm font-semibold text-black">{b.icon ? `${b.icon} ` : ""}{b.label}</button>
                ))}
              </div>
            )}
          </div>
        </div>
      ))}
    </div>
  );
}

/* ---------------- Products ---------------- */
export function Price({ p, big = false }: { p: any; big?: boolean }) {
  return (
    <span className="inline-flex flex-wrap items-baseline gap-1.5">
      {p.hasVariants && <span className="text-xs text-hint">From</span>}
      <span className={`font-bold text-brand ${big ? "text-2xl font-extrabold" : ""}`}>{money(p.price)}</span>
      {p.discounted && <span className="text-xs text-hint line-through">{money(p.originalPrice)}</span>}
      {p.discounted && p.percentOff ? <span className="rounded bg-red-500/15 px-1.5 text-xs font-semibold text-red-600">-{p.percentOff}%</span> : null}
    </span>
  );
}

export function ProductCard({ p, layout }: { p: any; layout?: string }) {
  const mode = layout ?? p.cardLayout ?? "DEFAULT";
  const stock = p.inStock ? (p.stock === null ? "Available" : `${p.stock} left`) : "Out of stock";
  if (mode === "WIDE") {
    return (
      <Link href={`/product/${p.id}`} className="card flex gap-3 !p-2">
        <div className="h-20 w-24 shrink-0 overflow-hidden rounded-lg bg-line"><SafeImg src={p.imageUrl} alt={p.name} className="h-full w-full object-cover" /></div>
        <div className="min-w-0 flex-1">
          <div className="line-clamp-1 font-semibold">{p.name}</div>
          <div className="text-sm"><Price p={p} /></div>
          <div className={`text-xs ${p.inStock ? "text-hint" : "text-red-500"}`}>{stock}</div>
        </div>
      </Link>
    );
  }
  return (
    <Link href={`/product/${p.id}`} className="card block overflow-hidden !p-0">
      {mode !== "COMPACT" && <div className="aspect-[4/3] bg-line"><SafeImg src={p.imageUrl} alt={p.name} className="h-full w-full object-cover" /></div>}
      <div className="p-3">
        <div className="line-clamp-1 font-semibold">{p.name}</div>
        <div className="mt-0.5 text-sm"><Price p={p} /></div>
        <div className={`text-xs ${p.inStock ? "text-hint" : "text-red-500"}`}>{stock}</div>
        {p.reviewCount > 0 && <div className="text-xs text-hint">★ {Number(p.rating).toFixed(1)} ({p.reviewCount})</div>}
      </div>
    </Link>
  );
}

export function ProductGrid({ items, layout = "GRID_2" }: { items: any[]; layout?: string }) {
  if (layout === "LIST") return <div className="space-y-2">{items.map((p) => <ProductCard key={p.id} p={p} layout="WIDE" />)}</div>;
  if (layout === "CAROUSEL") return <div className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-1">{items.map((p) => <div key={p.id} className="w-44 shrink-0 snap-start"><ProductCard p={p} /></div>)}</div>;
  return <div className={`grid gap-3 ${layout === "GRID_3" ? "grid-cols-3" : "grid-cols-2"}`}>{items.map((p) => <ProductCard key={p.id} p={p} layout={layout === "GRID_3" ? "COMPACT" : undefined} />)}</div>;
}

export function CategoryCards({ items, columns = 2, showImages = true }: { items: any[]; columns?: number; showImages?: boolean }) {
  return (
    <div className={`grid gap-3 ${columns === 3 ? "grid-cols-3" : "grid-cols-2"}`}>
      {items.map((c) => (
        <Link key={c.id} href={`/category/${c.slug}`} className="card block overflow-hidden !p-0 text-center">
          {showImages && (
            <div className="flex aspect-[4/3] items-center justify-center bg-line text-4xl">
              {c.imageUrl ? <SafeImg src={c.imageUrl} alt={c.name} className="h-full w-full object-cover" /> : c.icon ?? "🗂️"}
            </div>
          )}
          <div className="p-2">
            <div className="line-clamp-1 text-sm font-semibold">{!showImages && c.icon ? `${c.icon} ` : ""}{c.name}</div>
            {typeof c.productCount === "number" && <div className="text-xs text-hint">{c.productCount} items</div>}
          </div>
        </Link>
      ))}
    </div>
  );
}

/* ---------------- Section renderer (14 validated types) ---------------- */
const BANNER_TONE: Record<string, string> = {
  BRAND: "bg-brand text-brandfg", SUCCESS: "bg-emerald-600 text-white", WARNING: "bg-amber-500 text-black", DARK: "bg-gray-900 text-white",
};

function Countdown({ endsAt, serverNow, label, expiredMessage, hideWhenExpired }: any) {
  // Offset by the server clock so a wrong device clock cannot extend or shorten a promotion.
  const [offset] = useState(() => new Date(serverNow).getTime() - Date.now());
  const [now, setNow] = useState(() => Date.now() + offset);
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now() + offset), 1000);
    return () => clearInterval(t);
  }, [offset]);
  const left = new Date(endsAt).getTime() - now;
  if (left <= 0) return hideWhenExpired ? null : <div className="card text-center text-hint">{expiredMessage || "This offer has ended."}</div>;
  const d = Math.floor(left / 864e5), h = Math.floor((left % 864e5) / 36e5), m = Math.floor((left % 36e5) / 6e4), s = Math.floor((left % 6e4) / 1e3);
  const cell = (n: number, u: string) => <div className="rounded-lg bg-line px-3 py-2"><div className="text-xl font-extrabold tabular-nums">{String(n).padStart(2, "0")}</div><div className="text-[10px] uppercase text-hint">{u}</div></div>;
  return (
    <div className="card text-center">
      <div className="mb-2 font-semibold">{label}</div>
      <div className="flex justify-center gap-2">{cell(d, "days")}{cell(h, "hrs")}{cell(m, "min")}{cell(s, "sec")}</div>
    </div>
  );
}

export function SectionView({ s, serverNow, readOnly }: { s: any; serverNow: string; readOnly?: boolean }) {
  const c = s.config ?? {};
  const title = s.title ? <h2 className="mb-2 text-lg font-bold">{s.title}</h2> : null;
  const wrap = (body: React.ReactNode) => (
    <section className={`mt-5 ${s.scheduledOut ? "opacity-50" : ""}`}>
      {s.scheduledOut && <div className="mb-1 text-xs font-semibold text-amber-600">Outside its schedule: hidden from customers right now</div>}
      {body}
    </section>
  );
  switch (s.type) {
    case "PRODUCT_GRID":
    case "FEATURED_PRODUCTS":
      if (!s.data?.length) return null;
      return wrap(<>{title}<ProductGrid items={s.data} layout={c.layout} /></>);
    case "PROMO_BANNER":
      return wrap(
        <div className={`overflow-hidden rounded-2xl ${BANNER_TONE[c.tone] ?? BANNER_TONE.BRAND}`}>
          <SafeImg src={c.imageUrl} className="h-32 w-full object-cover" />
          <div className="p-4"><div className="text-lg font-bold">{c.heading}</div>{c.text && <p className="mt-1 opacity-90">{c.text}</p>}</div>
          {s.buttons?.length > 0 && <div className="px-4 pb-4"><ActionButtons buttons={s.buttons} disabled={readOnly} /></div>}
        </div>
      );
    case "NOTICE":
      return wrap(
        <div className={`rounded-xl p-3 ${TONE[c.tone] ?? TONE.INFO}`}>
          <div className="font-semibold">{c.icon ? `${c.icon} ` : ""}{c.heading}</div>
          <Md text={c.text} className="text-sm opacity-90" />
          {s.buttons?.length > 0 && <div className="mt-2"><ActionButtons buttons={s.buttons} disabled={readOnly} /></div>}
        </div>
      );
    case "RICH_TEXT":
      return wrap(<>{title}<Md text={c.text} className={c.align === "CENTER" ? "text-center" : ""} /></>);
    case "IMAGE":
      return wrap(
        <figure>
          {title}
          <div className={`overflow-hidden rounded-2xl bg-line ${c.aspect === "1_1" ? "aspect-square" : c.aspect === "4_3" ? "aspect-[4/3]" : "aspect-video"}`}>
            <SafeImg src={c.imageUrl} alt={c.alt} className={`h-full w-full ${c.fit === "CONTAIN" ? "object-contain" : "object-cover"}`} />
          </div>
          {c.caption && <figcaption className="mt-1 text-center text-sm text-hint">{c.caption}</figcaption>}
        </figure>
      );
    case "BUTTON_GROUP":
      return s.buttons?.length ? wrap(<>{title}<ActionButtons buttons={s.buttons} layout={c.layout} disabled={readOnly} /></>) : null;
    case "CATEGORY_GRID":
      return s.data?.length ? wrap(<>{title}<CategoryCards items={s.data} columns={c.columns} showImages={c.showImages} /></>) : null;
    case "FAQ":
      return s.data?.length ? wrap(<div id="faq">{title ?? <h2 className="mb-2 text-lg font-bold">FAQ</h2>}<FaqList items={s.data} /></div>) : null;
    case "HOW_IT_WORKS":
      return wrap(
        <>{title ?? <h2 className="mb-2 text-lg font-bold">How it works</h2>}
          <ol className="space-y-2">
            {c.steps.map((st: any, i: number) => (
              <li key={i} className="card flex gap-3 !p-3">
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-brand font-bold text-brandfg">{st.icon ?? i + 1}</span>
                <div><div className="font-semibold">{st.title}</div>{st.text && <div className="text-sm text-hint">{st.text}</div>}</div>
              </li>
            ))}
          </ol>
        </>
      );
    case "SUPPORT_INFO":
      return wrap(<SupportInfo title={title} text={c.text} contact={s.data} />);
    case "TERMS":
      return wrap(
        <details open={!c.collapsed} className="card">
          <summary className="cursor-pointer font-semibold">{s.title ?? "Terms and conditions"}</summary>
          <Md text={c.text} className="mt-2 text-sm text-hint" />
        </details>
      );
    case "COUNTDOWN":
      return wrap(<Countdown {...c} serverNow={s.data?.serverNow ?? serverNow} />);
    case "EMPTY_STATE":
      return wrap(<div className="card py-8 text-center"><div className="text-4xl">{c.icon ?? "📭"}</div><div className="mt-1 font-semibold">{c.heading}</div>{c.text && <p className="text-sm text-hint">{c.text}</p>}</div>);
    default:
      return null;
  }
}

export function FaqList({ items }: { items: { q: string; a: string }[] }) {
  return (
    <div className="space-y-2">
      {items.map((f, i) => (
        <details key={i} className="card !p-3">
          <summary className="cursor-pointer font-semibold">{f.q}</summary>
          <Md text={f.a} className="mt-2 text-sm text-hint" />
        </details>
      ))}
    </div>
  );
}

export function SupportInfo({ title, text, contact }: { title?: React.ReactNode; text?: string | null; contact?: any }) {
  const go = useGo();
  if (!text && !contact) return null;
  return (
    <div className="card">
      {title ?? <h2 className="mb-2 text-lg font-bold">Support</h2>}
      {text && <Md text={text} className="text-sm" />}
      {contact && (
        <div className="mt-2 space-y-1 text-sm">
          {contact.telegramUsername && (
            <button className="font-semibold text-brand" onClick={() => void go({ nav: { kind: "telegram", url: `https://t.me/${contact.telegramUsername}` }, confirm: null })}>
              💬 Message @{contact.telegramUsername}
            </button>
          )}
          {contact.email && <div>✉️ {contact.email}</div>}
          {contact.phone && <div>📞 {contact.phone}</div>}
          {contact.supportHours && <div className="text-hint">🕒 {contact.supportHours}</div>}
        </div>
      )}
    </div>
  );
}
