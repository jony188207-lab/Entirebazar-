"use client";
import { useEffect, useState } from "react";
import { APP_NAME } from "@/lib/brand";

/** Returns true when Telegram (or, outside Telegram, the OS) is using a dark theme. */
function useDark() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    const w = window.Telegram?.WebApp;
    const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
    const read = () => setDark(w?.colorScheme ? w.colorScheme === "dark" : !!mq?.matches);
    read();
    w?.onEvent?.("themeChanged", read);
    mq?.addEventListener?.("change", read);
    return () => {
      w?.offEvent?.("themeChanged", read);
      mq?.removeEventListener?.("change", read);
    };
  }, []);
  return dark;
}

/**
 * Full wordmark ("EntireBazar" + orbit-ringed "360"). Uses the light-text variant on dark themes.
 * Height controls size; width follows the SVG aspect ratio (≈4.4:1).
 */
export function Logo({ height = 32, className = "" }: { height?: number; className?: string }) {
  const dark = useDark();
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img
      src={dark ? "/logo-light.svg" : "/logo.svg"}
      alt={APP_NAME}
      height={height}
      style={{ height, width: "auto" }}
      className={className}
      draggable={false}
    />
  );
}

/** Compact circular "360" orbit mark for tight spaces. */
export function LogoMark({ size = 28, className = "" }: { size?: number; className?: string }) {
  return (
    // eslint-disable-next-line @next/next/no-img-element
    <img src="/logo-mark.svg" alt={APP_NAME} width={size} height={size} className={className} draggable={false} />
  );
}
