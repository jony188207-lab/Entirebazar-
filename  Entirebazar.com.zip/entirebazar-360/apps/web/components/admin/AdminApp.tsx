"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { CategoryEditor, CategoryList } from "./Categories";
import { Deposits, Ledger, Payments } from "./Finance";
import { Integrations } from "./Integrations";
import { NoticeEditor, NoticeList } from "./Notices";
import { Notify, Tickets, UserDetail, Users } from "./People";
import { ProductEditor, ProductList } from "./Products";
import { Audit, Dashboard, OrderDetail, Orders, Reports, Roles, Settings } from "./System";
import { Toaster, useAdmin } from "./kit";
import { ErrorBox, Loading } from "@/components/ui";

type Item = { href: string; label: string; icon: string; perm: string[] };
const MENU: { group: string; items: Item[] }[] = [
  { group: "Overview", items: [{ href: "/admin", label: "Dashboard", icon: "📊", perm: ["dashboard.view"] }, { href: "/admin/reports", label: "Reports", icon: "📈", perm: ["reports.view"] }] },
  { group: "Catalogue", items: [
    { href: "/admin/categories", label: "Categories & pages", icon: "🗂️", perm: ["catalog.view"] },
    { href: "/admin/products", label: "Products", icon: "📦", perm: ["products.view"] },
    { href: "/admin/notices", label: "Notices & banners", icon: "📣", perm: ["notices.manage"] },
  ] },
  { group: "Sales", items: [
    { href: "/admin/orders", label: "Orders", icon: "🧾", perm: ["orders.view"] },
    { href: "/admin/deposits", label: "Wallet deposits", icon: "💳", perm: ["deposits.view"] },
    { href: "/admin/ledger", label: "Wallet ledger", icon: "📒", perm: ["ledger.view"] },
    { href: "/admin/payments", label: "Payment methods", icon: "📱", perm: ["payments.configure"] },
  ] },
  { group: "People", items: [
    { href: "/admin/users", label: "Users", icon: "👥", perm: ["users.view"] },
    { href: "/admin/tickets", label: "Support tickets", icon: "🎧", perm: ["tickets.manage"] },
    { href: "/admin/notify", label: "Telegram messages", icon: "✉️", perm: ["notify.send"] },
  ] },
  { group: "System", items: [
    { href: "/admin/integrations", label: "API integrations", icon: "🔌", perm: ["integrations.view"] },
    { href: "/admin/settings", label: "General settings", icon: "⚙️", perm: ["settings.manage"] },
    { href: "/admin/roles", label: "Roles & permissions", icon: "🛡️", perm: ["roles.manage"] },
    { href: "/admin/audit", label: "Audit log", icon: "🕵️", perm: ["audit.view"] },
  ] },
];

export default function AdminApp() {
  const path = usePathname() ?? "/admin";
  const [open, setOpen] = useState(false);
  const me = useAdmin<any>("/me");
  const seg = path.replace(/^\/admin\/?/, "").split("/").filter(Boolean);

  if (me.loading && !me.data) return <Loading />;
  if (me.error || !me.data) return <ErrorBox msg={me.error ?? "Not an administrator"} />;
  const perms = new Set<string>(me.data.permissions);
  const can = (p: string) => perms.has(p);
  const allowed = (i: Item) => i.perm.every(can);

  const [a, b] = seg;
  const need = (p: string, el: React.ReactNode) => (can(p) ? el : <div className="card text-center text-hint">You do not have permission to view this page.</div>);
  let view: React.ReactNode;
  switch (a) {
    case undefined: view = need("dashboard.view", <Dashboard can={can} />); break;
    case "reports": view = need("reports.view", <Reports />); break;
    case "categories": view = need("catalog.view", b ? <CategoryEditor id={b} key={b} /> : <CategoryList />); break;
    case "products": view = need("products.view", b ? <ProductEditor id={b} key={b} /> : <ProductList />); break;
    case "notices": view = need("notices.manage", b ? <NoticeEditor id={b} key={b} /> : <NoticeList />); break;
    case "orders": view = need("orders.view", b ? <OrderDetail id={b} can={can} /> : <Orders />); break;
    case "deposits": view = need("deposits.view", <Deposits />); break;
    case "ledger": view = need("ledger.view", <Ledger />); break;
    case "payments": view = need("payments.configure", <Payments />); break;
    case "users": view = need("users.view", b ? <UserDetail id={b} can={can} /> : <Users />); break;
    case "tickets": view = need("tickets.manage", <Tickets />); break;
    case "notify": view = need("notify.send", <Notify />); break;
    case "integrations": view = need("integrations.view", <Integrations />); break;
    case "settings": view = need("settings.manage", <Settings />); break;
    case "roles": view = need("roles.manage", <Roles />); break;
    case "audit": view = need("audit.view", <Audit />); break;
    default: view = <div className="card text-center text-hint">Page not found.</div>;
  }

  const nav = (
    <nav aria-label="Admin" className="space-y-4">
      {MENU.map((g) => {
        const items = g.items.filter(allowed);
        if (!items.length) return null;
        return (
          <div key={g.group}>
            <div className="mb-1 px-2 text-xs font-semibold uppercase tracking-wide text-hint">{g.group}</div>
            {items.map((i) => {
              const active = i.href === "/admin" ? path === "/admin" : path.startsWith(i.href);
              return <Link key={i.href} href={i.href} onClick={() => setOpen(false)} className={`flex items-center gap-2 rounded-lg px-2 py-2 text-sm ${active ? "bg-brand text-brandfg font-semibold" : ""}`}><span>{i.icon}</span>{i.label}</Link>;
            })}
          </div>
        );
      })}
      <Link href="/" className="block px-2 text-sm text-hint">← Back to the shop</Link>
    </nav>
  );

  return (
    <div className="lg:grid lg:grid-cols-[14rem_1fr] lg:gap-6">
      <Toaster />
      <aside className="hidden lg:block"><div className="sticky top-4">{nav}</div></aside>
      <div className="mb-3 lg:hidden">
        <button className="btn-ghost w-full !py-2 text-sm" aria-expanded={open} onClick={() => setOpen(!open)}>☰ Menu · signed in as {me.data.name ?? "admin"} ({me.data.customRole ?? me.data.role})</button>
        {open && <div className="card mt-2">{nav}</div>}
      </div>
      <div className="min-w-0 pb-6">{view}</div>
    </div>
  );
}
