"use client";
import Link from "next/link";
import { useState } from "react";
import { money, when } from "@/lib/api";
import { Area, Async, Btn, Card, F, NumIn, Pager, Pill, SearchBox, Sel, Tabs, TextIn, adm, ask, run, statusTone, toast, useAdmin, Check } from "./kit";

/* ============================================================
 * Payment methods
 * ============================================================ */
export function Payments() {
  const r = useAdmin<any[]>("/providers");
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Payment methods</h1>
      <Card><p className="text-sm text-hint">Customers see the number and the exact amount, pay in their MFS app, then submit the transaction ID. A wallet is credited only after the payment is <b>verified</b>: automatically through an approved provider API once that adapter exists and tests succeed, or by you comparing the transaction in your merchant account (<b>manual review</b>, clearly labelled to customers). A submitted transaction ID alone never credits a wallet.</p></Card>
      <Async r={r}>{(items) => items.map((p: any) => <ProviderCard key={p.code} p={p} reload={r.reload} />)}</Async>
    </div>
  );
}

function ProviderCard({ p, reload }: { p: any; reload: () => void }) {
  const [f, setF] = useState({ displayName: p.displayName, receiverNumber: p.receiverNumber ?? "", instructions: p.instructions ?? "", minAmount: p.minAmount ? Number(p.minAmount) : null, maxAmount: p.maxAmount ? Number(p.maxAmount) : null, verificationMode: p.verificationMode, enabled: p.enabled });
  const save = async () => { const r = await run(() => adm(`/providers/${p.code}`, { ...f, receiverNumber: f.receiverNumber || null, instructions: f.instructions || null }, "PATCH"), "Saved"); if (r) reload(); };
  return (
    <Card title={<>{p.displayName} {p.isFuture ? <Pill>Coming soon</Pill> : p.enabled ? <Pill tone="green">Enabled</Pill> : <Pill>Disabled</Pill>}</>}>
      {p.isFuture ? <p className="text-sm text-hint">Not available yet. A Bitcoin integration needs a dedicated backend adapter (see docs/INTEGRATIONS.md).</p> : (
        <div className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <F label="Display name"><TextIn value={f.displayName} maxLength={40} onChange={(v) => setF({ ...f, displayName: v })} /></F>
            <F label="Receiving number customers pay to"><TextIn value={f.receiverNumber} maxLength={20} inputMode="tel" onChange={(v) => setF({ ...f, receiverNumber: v })} /></F>
            <F label="Minimum amount"><NumIn value={f.minAmount} min={0} onChange={(v) => setF({ ...f, minAmount: v })} /></F>
            <F label="Maximum amount"><NumIn value={f.maxAmount} min={0} onChange={(v) => setF({ ...f, maxAmount: v })} /></F>
          </div>
          <F label="Instructions shown to customers"><Area value={f.instructions} rows={3} maxLength={2000} onChange={(v) => setF({ ...f, instructions: v })} /></F>
          <F label="Verification" hint={p.apiVerificationReady ? "Automatic verification is ready." : p.adapterImplemented ? "The adapter exists but needs credentials and a successful connection test (API Integrations)." : "No automatic adapter is implemented for this provider yet, so manual review is the only honest option."}>
            <Sel value={f.verificationMode} onChange={(v) => setF({ ...f, verificationMode: v })} options={[{ value: "DISABLED", label: "Off" }, { value: "MANUAL_REVIEW", label: "Manual review by an admin" }, { value: "API", label: "Automatic (provider API)" }]} />
          </F>
          <Check label="Available to customers" checked={f.enabled} onChange={(v) => setF({ ...f, enabled: v })} />
          <Btn kind="primary" onClick={() => void save()}>Save</Btn>
        </div>
      )}
    </Card>
  );
}

/* ============================================================
 * Deposits (review queue)
 * ============================================================ */
export function Deposits() {
  const [status, setStatus] = useState("");
  const [review, setReview] = useState(false);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const list = useAdmin<any>(`/deposits?page=${page}${status ? `&status=${status}` : ""}${review ? "&needsReview=true" : ""}${q ? `&q=${encodeURIComponent(q)}` : ""}`);
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-bold">Wallet deposits</h1>
      <div className="grid gap-2 sm:grid-cols-[1fr_10rem_auto]">
        <SearchBox value={q} onChange={(v) => { setQ(v); setPage(1); }} placeholder="Invoice or transaction ID…" />
        <Sel value={status} onChange={(v) => { setStatus(v); setPage(1); }} options={[{ value: "", label: "All statuses" }, "PENDING", "SUCCESSFUL", "FAILED", "EXPIRED", "REJECTED"]} />
        <Check label="Needs review" checked={review} onChange={(v) => { setReview(v); setPage(1); }} />
      </div>
      <Async r={list}>{(d) => (<>
        {d.items.map((x: any) => (
          <div key={x.id} className="card !p-3">
            <button className="flex w-full flex-wrap items-center justify-between gap-2 text-left" onClick={() => setOpen(open === x.id ? null : x.id)}>
              <span><span className="font-mono font-semibold">{x.invoiceNo}</span> · {money(x.amount)} · {x.provider.displayName}</span>
              <span className="flex items-center gap-1.5"><Pill tone={statusTone(x.status)}>{x.status}</Pill>{x.needsReview && <Pill tone="amber">Needs review</Pill>}</span>
            </button>
            <div className="text-xs text-hint">{x.user.firstName ?? x.user.username} · {when(x.createdAt)} {x.providerTrxId && <>· TrxID <span className="font-mono">{x.providerTrxId}</span></>}</div>
            {open === x.id && <DepositDetail id={x.id} onDone={() => { setOpen(null); list.reload(); }} />}
          </div>
        ))}
        {!d.items.length && <div className="card text-center text-hint">No deposits.</div>}
        <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
      </>)}</Async>
    </div>
  );
}

function DepositDetail({ id, onDone }: { id: string; onDone: () => void }) {
  const r = useAdmin<any>(`/deposits/${id}`);
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");
  return (
    <div className="mt-3 space-y-3 border-t border-line pt-3 text-sm">
      <Async r={r}>{(d) => (<>
        <div className="grid gap-1 sm:grid-cols-2">
          <div>Expected amount: <b>{money(d.amount)}</b></div><div>Sender: {d.senderNumber ?? "—"}</div>
          <div>Verification: <b>{d.provider.verificationMode}</b></div><div>Expires: {d.expiresAt ? when(d.expiresAt) : "—"}</div>
        </div>
        {d.events.length > 0 && <div><div className="font-medium">Timeline</div>{d.events.map((e: any) => <div key={e.id} className="text-xs text-hint">{when(e.createdAt)} · {e.source} · {e.kind}</div>)}</div>}
        {d.status === "PENDING" && (
          <div className="space-y-2 rounded-xl border border-line p-3">
            {d.provider.verificationMode === "MANUAL_REVIEW" && d.providerTrxId ? (
              <>
                <p className="text-hint">Open your {d.provider.displayName} merchant account and find transaction <b className="font-mono">{d.providerTrxId}</b>. Approve only if it exists, was received, and matches this amount. Type the amount you saw to confirm.</p>
                <div className="flex flex-wrap items-end gap-2"><F label="Amount you saw (৳)"><NumIn value={amount === "" ? null : Number(amount)} onChange={(v) => setAmount(v === null ? "" : String(v))} /></F>
                  <Btn kind="primary" disabled={amount === ""} onClick={async () => { if (await ask(`Credit ${money(d.amount)} to this customer's wallet for transaction ${d.providerTrxId}?`)) { const r2: any = await run(() => adm(`/deposits/${id}/approve`, { confirmedAmount: Number(amount) })); if (r2) { toast(`Result: ${r2.result}`); onDone(); } } }}>Approve & credit</Btn></div>
              </>
            ) : <p className="text-hint">{d.providerTrxId ? "Waiting for automatic verification." : "The customer has not submitted a transaction ID yet."}</p>}
            <div className="flex flex-wrap items-end gap-2"><F label="Reject reason" className="flex-1"><TextIn value={reason} maxLength={300} onChange={setReason} /></F><Btn kind="danger" disabled={reason.trim().length < 3} onClick={async () => { const r2 = await run(() => adm(`/deposits/${id}/reject`, { reason }), "Rejected"); if (r2) onDone(); }}>Reject</Btn></div>
          </div>
        )}
      </>)}</Async>
    </div>
  );
}

/* ============================================================
 * Ledger & adjustments
 * ============================================================ */
export function Ledger() {
  const [type, setType] = useState("");
  const [page, setPage] = useState(1);
  const r = useAdmin<any>(`/ledger?page=${page}&limit=30${type ? `&type=${type}` : ""}`);
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-bold">Wallet ledger</h1>
      <p className="text-sm text-hint">Every balance change is an immutable ledger entry. To correct a balance, use “Adjust wallet” on the user's page: it is recorded with your name and reason.</p>
      <Sel value={type} onChange={(v) => { setType(v); setPage(1); }} options={[{ value: "", label: "All types" }, "DEPOSIT", "PURCHASE", "REFUND", "ADJUSTMENT"]} />
      <Async r={r}>{(d) => (<>
        <div className="card overflow-x-auto !p-0"><table className="w-full text-sm"><thead className="text-left text-xs text-hint"><tr><th className="p-2">When</th><th>User</th><th>Type</th><th className="text-right">Amount</th><th className="text-right">Balance</th><th className="p-2">Note</th></tr></thead>
          <tbody>{d.items.map((e: any) => <tr key={e.id} className="border-t border-line"><td className="p-2 whitespace-nowrap">{when(e.createdAt)}</td><td><Link className="text-brand" href={`/admin/users/${e.wallet.userId}`}>{e.wallet.user.firstName ?? e.wallet.user.username ?? "user"}</Link></td><td><Pill>{e.type}</Pill></td><td className={`text-right font-mono ${e.direction === "CREDIT" ? "text-emerald-600" : "text-red-600"}`}>{e.direction === "CREDIT" ? "+" : "−"}{money(e.amount)}</td><td className="text-right font-mono">{money(e.balanceAfter)}</td><td className="p-2 text-xs text-hint">{e.note}</td></tr>)}</tbody></table></div>
        <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
      </>)}</Async>
    </div>
  );
}

export function AdjustWallet({ userId, onDone }: { userId: string; onDone: () => void }) {
  const [f, setF] = useState({ direction: "CREDIT", amount: null as number | null, reason: "" });
  return (
    <Card title="Adjust wallet (audited)">
      <p className="mb-2 text-sm text-hint">Use for corrections only. Requires a recent sign-in, a written reason, and is visible to the customer and in the audit log.</p>
      <div className="grid gap-3 sm:grid-cols-3">
        <F label="Direction"><Sel value={f.direction} onChange={(v) => setF({ ...f, direction: v })} options={[{ value: "CREDIT", label: "Add money" }, { value: "DEBIT", label: "Remove money" }]} /></F>
        <F label="Amount (৳)"><NumIn value={f.amount} min={0} step="0.01" onChange={(v) => setF({ ...f, amount: v })} /></F>
        <F label="Reason (min 8 characters)" className="sm:col-span-3"><TextIn value={f.reason} maxLength={300} onChange={(v) => setF({ ...f, reason: v })} /></F>
      </div>
      <Btn kind="primary" className="mt-3" disabled={!f.amount || f.reason.trim().length < 8} onClick={async () => { if (await ask(`${f.direction === "CREDIT" ? "Add" : "Remove"} ${money(f.amount)} ${f.direction === "CREDIT" ? "to" : "from"} this wallet?`)) { const r = await run(() => adm(`/users/${userId}/wallet-adjust`, f), "Wallet adjusted"); if (r) { setF({ direction: "CREDIT", amount: null, reason: "" }); onDone(); } } }}>Apply adjustment</Btn>
    </Card>
  );
}
void Tabs;
