"use client";
import Link from "next/link";
import { useState } from "react";
import { money, when } from "@/lib/api";
import { AdjustWallet } from "./Finance";
import { Area, Async, Btn, Card, F, Pager, Pill, SearchBox, Sel, TextIn, adm, ask, run, statusTone, toast, useAdmin } from "./kit";

export function Users() {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const r = useAdmin<any>(`/users?page=${page}${q ? `&q=${encodeURIComponent(q)}` : ""}${status ? `&status=${status}` : ""}`);
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-bold">Users</h1>
      <div className="grid gap-2 sm:grid-cols-[1fr_10rem]"><SearchBox value={q} onChange={(v) => { setQ(v); setPage(1); }} placeholder="Name, @username or Telegram ID…" /><Sel value={status} onChange={(v) => { setStatus(v); setPage(1); }} options={[{ value: "", label: "All" }, "ACTIVE", "RESTRICTED", "BANNED"]} /></div>
      <Async r={r}>{(d) => (<>
        {d.items.map((u: any) => (
          <Link key={u.id} href={`/admin/users/${u.id}`} className="card flex flex-wrap items-center justify-between gap-2 !p-3">
            <span><b>{u.firstName ?? "—"}</b> {u.username && <span className="text-hint">@{u.username}</span>}<span className="ml-2 text-xs text-hint">joined {when(u.createdAt)}</span></span>
            <span className="flex items-center gap-2"><span className="font-mono">{money(u.wallet?.balance ?? 0)}</span><Pill tone={statusTone(u.status)}>{u.status}</Pill>{u.botBlocked && <Pill tone="amber">bot blocked</Pill>}</span>
          </Link>
        ))}
        {!d.items.length && <div className="card text-center text-hint">No users found.</div>}
        <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
      </>)}</Async>
    </div>
  );
}

export function UserDetail({ id, can }: { id: string; can: (p: string) => boolean }) {
  const r = useAdmin<any>(`/users/${id}`);
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState({ title: "", body: "" });
  return (
    <div className="space-y-4">
      <Link href="/admin/users" className="text-sm text-brand">← Users</Link>
      <Async r={r}>{(u) => (<>
        <Card title={<>{u.firstName} {u.lastName} {u.username && <span className="text-hint">@{u.username}</span>}</>}>
          <div className="grid gap-1 text-sm sm:grid-cols-2"><div>Telegram ID: <span className="font-mono">{String(u.telegramId)}</span></div><div>Status: <Pill tone={statusTone(u.status)}>{u.status}</Pill></div><div>Balance: <b>{money(u.wallet?.balance ?? 0)}</b></div><div>Joined: {when(u.createdAt)}</div></div>
        </Card>
        {can("users.manage") && (
          <Card title="Account status">
            <p className="mb-2 text-sm text-hint">Restricted users can browse but cannot pay or order. Banned users cannot sign in.</p>
            <F label="Reason (required to restrict or ban)"><TextIn value={reason} maxLength={300} onChange={setReason} /></F>
            <div className="mt-3 flex flex-wrap gap-2">{["ACTIVE", "RESTRICTED", "BANNED"].map((s) => <Btn key={s} disabled={u.status === s || (s !== "ACTIVE" && reason.trim().length < 3)} kind={s === "BANNED" ? "danger" : "ghost"} onClick={async () => { if (await ask(`Set this account to ${s}?`)) { const x = await run(() => adm(`/users/${id}/status`, { status: s, reason: reason || undefined }, "PATCH"), "Updated"); if (x) r.reload(); } }}>{s === "ACTIVE" ? "Reactivate" : s === "RESTRICTED" ? "Restrict" : "Ban"}</Btn>)}</div>
          </Card>
        )}
        {can("wallet.adjust") && <AdjustWallet userId={id} onDone={r.reload} />}
        {can("notify.send") && (
          <Card title="Message this user">
            <p className="mb-2 text-sm text-hint">Delivered in the app, and through the bot if they started it and have not blocked it.</p>
            <F label="Title"><TextIn value={msg.title} maxLength={100} onChange={(v) => setMsg({ ...msg, title: v })} /></F>
            <F label="Message" className="mt-2"><Area value={msg.body} rows={3} maxLength={1500} onChange={(v) => setMsg({ ...msg, body: v })} /></F>
            <Btn className="mt-2" disabled={!msg.title.trim() || !msg.body.trim()} onClick={async () => { const x = await run(() => adm("/broadcasts", { ...msg, audience: "one", userIds: [id] }), "Sent"); if (x) setMsg({ title: "", body: "" }); }}>Send</Btn>
          </Card>
        )}
        <Card title="Recent orders">{u.orders.length ? u.orders.map((o: any) => <Link key={o.id} href={`/admin/orders/${o.id}`} className="flex justify-between border-b border-line py-2 last:border-0"><span className="font-mono">{o.orderNo}</span><span>{money(o.total)} <Pill tone={statusTone(o.status)}>{o.status}</Pill></span></Link>) : <p className="text-sm text-hint">None.</p>}</Card>
        <Card title="Recent deposits">{u.deposits.length ? u.deposits.map((d: any) => <div key={d.id} className="flex justify-between border-b border-line py-2 last:border-0"><span>{d.provider.displayName} · <span className="font-mono">{d.invoiceNo}</span></span><span>{money(d.amount)} <Pill tone={statusTone(d.status)}>{d.status}</Pill></span></div>) : <p className="text-sm text-hint">None.</p>}</Card>
        {u.adjustments.length > 0 && <Card title="Wallet adjustments">{u.adjustments.map((a: any) => <div key={a.id} className="border-b border-line py-2 text-sm last:border-0">{when(a.createdAt)} · {a.direction === "CREDIT" ? "+" : "−"}{money(a.amount)} · {a.reason}</div>)}</Card>}
      </>)}</Async>
    </div>
  );
}

export function Tickets() {
  const [status, setStatus] = useState("OPEN");
  const [page, setPage] = useState(1);
  const r = useAdmin<any>(`/tickets?page=${page}${status ? `&status=${status}` : ""}`);
  const [reply, setReply] = useState<Record<string, string>>({});
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-bold">Support tickets</h1>
      <Sel value={status} onChange={(v) => { setStatus(v); setPage(1); }} options={[{ value: "", label: "All" }, "OPEN", "ANSWERED", "CLOSED"]} />
      <Async r={r}>{(d) => (<>
        {d.items.map((t: any) => (
          <Card key={t.id} title={<>{t.subject} <Pill tone={statusTone(t.status)}>{t.status}</Pill></>}>
            <div className="text-xs text-hint">{t.user.firstName ?? t.user.username} · {when(t.createdAt)}</div>
            <p className="mt-2 whitespace-pre-line text-sm">{t.message}</p>
            {t.reply && <div className="mt-2 rounded-lg bg-brand/10 p-2 text-sm"><b>Your reply:</b> {t.reply}</div>}
            {t.status !== "CLOSED" && (<div className="mt-3 space-y-2">
              <Area value={reply[t.id] ?? ""} rows={2} maxLength={2000} placeholder="Write a reply…" onChange={(v) => setReply({ ...reply, [t.id]: v })} />
              <div className="flex gap-2"><Btn kind="primary" disabled={!(reply[t.id] ?? "").trim()} onClick={async () => { const x = await run(() => adm(`/tickets/${t.id}/reply`, { reply: reply[t.id] }), "Reply sent"); if (x) { setReply({ ...reply, [t.id]: "" }); r.reload(); } }}>Send reply</Btn><Btn onClick={async () => { await run(() => adm(`/tickets/${t.id}/close`, {}), "Closed"); r.reload(); }}>Close</Btn></div>
            </div>)}
          </Card>
        ))}
        {!d.items.length && <div className="card text-center text-hint">Nothing here.</div>}
        <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
      </>)}</Async>
    </div>
  );
}

export function Notify() {
  const jobs = useAdmin<any[]>("/broadcasts");
  const errs = useAdmin<any>("/delivery-errors");
  const tpl = useAdmin<any[]>("/templates");
  const [f, setF] = useState({ title: "", body: "", scheduledAt: "" });
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Telegram notifications</h1>
      <Card title="Broadcast to all customers">
        <p className="mb-2 text-sm text-hint">Sent through the bot and saved in each customer's in-app history. Bots can only message people who have started them: customers who never opened the bot or who blocked it are skipped automatically (and counted below). Customers who muted promotions are skipped for Telegram but still see it in the app. Sending is rate-limited.</p>
        {tpl.data && tpl.data.length > 0 && <F label="Start from a template"><Sel value="" onChange={(id) => { const t = tpl.data!.find((x) => x.id === id); if (t) setF({ ...f, title: t.title, body: t.body }); }} options={[{ value: "", label: "—" }, ...tpl.data.map((t) => ({ value: t.id, label: t.name }))]} /></F>}
        <F label="Title" className="mt-2"><TextIn value={f.title} maxLength={100} onChange={(v) => setF({ ...f, title: v })} /></F>
        <F label="Message" className="mt-2"><Area value={f.body} rows={4} maxLength={1500} onChange={(v) => setF({ ...f, body: v })} /></F>
        <F label="Send later (optional)" className="mt-2"><input className="input" type="datetime-local" value={f.scheduledAt} onChange={(e) => setF({ ...f, scheduledAt: e.target.value })} /></F>
        <div className="mt-3 flex gap-2">
          <Btn kind="primary" disabled={!f.title.trim() || !f.body.trim()} onClick={async () => { if (await ask("Send this message to ALL customers?")) { const x = await run(() => adm("/broadcasts", { title: f.title, body: f.body, audience: "all", scheduledAt: f.scheduledAt ? new Date(f.scheduledAt).toISOString() : undefined }), "Broadcast queued"); if (x) { setF({ title: "", body: "", scheduledAt: "" }); jobs.reload(); } } }}>Send broadcast</Btn>
          <Btn disabled={!f.title.trim() || !f.body.trim()} onClick={async () => { const n = prompt("Template name"); if (n) { await run(() => adm("/templates", { name: n, title: f.title, body: f.body }), "Template saved"); tpl.reload(); } }}>Save as template</Btn>
        </div>
        <p className="mt-2 text-xs text-hint">To message one person, open them in Users.</p>
      </Card>
      <Card title="Recent broadcasts"><Async r={jobs}>{(items) => items.length ? items.map((j: any) => (
        <div key={j.id} className="border-b border-line py-2 text-sm last:border-0"><b>{j.title}</b> <span className="text-xs text-hint">{j.audience} · {when(j.createdAt)}</span>
          <div className="text-xs text-hint">{j.finishedAt ? `Done: ${j.sent} delivered · ${j.blocked} blocked the bot · ${j.failed} failed · ${j.total} recipients` : j.startedAt ? "Sending…" : j.scheduledAt ? `Scheduled for ${when(j.scheduledAt)}` : "Queued"}</div></div>
      )) : <p className="text-sm text-hint">None yet.</p>}</Async></Card>
      <Card title="Delivery problems"><Async r={errs}>{(d) => (<>
        <p className="mb-2 text-sm text-hint">{d.blockedUsers} customer(s) have blocked the bot. They still receive in-app notifications.</p>
        {d.items.slice(0, 30).map((e: any) => <div key={e.id} className="border-b border-line py-1.5 text-xs last:border-0"><Pill tone={e.telegram === "BLOCKED" ? "amber" : "red"}>{e.telegram}</Pill> {when(e.createdAt)} · {e.title} · {e.telegramError}</div>)}
        {!d.items.length && <p className="text-sm text-hint">No failures.</p>}
      </>)}</Async></Card>
      <Card title="Templates"><Async r={tpl}>{(items) => items.length ? items.map((t: any) => <div key={t.id} className="flex items-center justify-between border-b border-line py-2 text-sm last:border-0"><span>{t.name}</span><Btn small kind="danger" onClick={async () => { if (await ask("Delete template?")) { await run(() => adm(`/templates/${t.id}`, undefined, "DELETE")); tpl.reload(); } }}>Delete</Btn></div>) : <p className="text-sm text-hint">No templates.</p>}</Async></Card>
    </div>
  );
}
void toast;
