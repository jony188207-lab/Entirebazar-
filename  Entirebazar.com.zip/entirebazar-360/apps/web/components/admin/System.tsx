"use client";
import Link from "next/link";
import { useState } from "react";
import { assetUrl, money, when } from "@/lib/api";
import { Area, Async, Btn, Card, Check, F, NumIn, Pager, Pill, ProductPicker, SearchBox, Sel, TextIn, adm, ask, move, run, statusTone, toast, useAdmin } from "./kit";

/* ============================================================ Dashboard */
export function Dashboard({ can }: { can: (p: string) => boolean }) {
  const r = useAdmin<any>("/dashboard");
  const tile = (label: string, v: any, href?: string, tone = "") => v === null || v === undefined ? null : (
    <Link href={href ?? "#"} className={`card block !p-3 ${tone}`}><div className="text-xs text-hint">{label}</div><div className="text-2xl font-extrabold">{v}</div></Link>
  );
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      <Async r={r}>{(d) => (<>
        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          {tile("Deposits needing review", d.depositsNeedingReview, "/admin/deposits", d.depositsNeedingReview ? "ring-2 ring-amber-500" : "")}
          {tile("Manual orders to fulfil", d.manualFulfilmentQueue, "/admin/orders", d.manualFulfilmentQueue ? "ring-2 ring-blue-500" : "")}
          {tile("Open tickets", d.openTickets, "/admin/tickets")}
          {tile("Low-stock products", d.lowStockProducts, "/admin/products")}
          {tile("Total sales", d.totalSales !== null ? money(d.totalSales) : null, "/admin/reports")}
          {tile("Deposited (verified)", d.totalDeposits !== null ? money(d.totalDeposits) : null, "/admin/deposits")}
          {tile("Customers", d.totalUsers, "/admin/users")}
          {tile("Pending orders", d.pendingOrders, "/admin/orders")}
          {tile("Live categories", d.publishedCategories, "/admin/categories")}
          {tile("Draft categories", d.draftCategories, "/admin/categories")}
        </div>
        {can("catalog.edit") && <Card title="Quick actions"><div className="flex flex-wrap gap-2"><Link className="btn !px-3 !py-2 text-sm" href="/admin/categories">Manage categories</Link><Link className="btn-ghost !px-3 !py-2 text-sm" href="/admin/products">Products</Link><Link className="btn-ghost !px-3 !py-2 text-sm" href="/admin/notices/new">New notice</Link></div></Card>}
        {d.recentActivity.length > 0 && <Card title="Recent payment activity">{d.recentActivity.map((e: any) => <div key={e.id} className="border-b border-line py-1.5 text-xs text-hint last:border-0">{when(e.createdAt)} · {e.source} · {e.kind}</div>)}</Card>}
      </>)}</Async>
    </div>
  );
}

/* ============================================================ Orders */
export function Orders() {
  const [status, setStatus] = useState("");
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);
  const [mode, setMode] = useState<"" | "manual" | "refunds">("");
  const r = useAdmin<any>(`/orders?page=${page}${status ? `&status=${status}` : ""}${q ? `&q=${encodeURIComponent(q)}` : ""}${mode === "manual" ? "&manual=true" : ""}${mode === "refunds" ? "&refunds=requested" : ""}`);
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-bold">Orders</h1>
      <div className="flex flex-wrap gap-2">{([["", "All"], ["manual", "Manual queue"], ["refunds", "Refund requests"]] as const).map(([k, l]) => <button key={k} onClick={() => { setMode(k); setPage(1); }} className={`rounded-full px-3 py-1.5 text-sm ${mode === k ? "bg-brand text-brandfg" : "bg-card"}`}>{l}</button>)}</div>
      <div className="grid gap-2 sm:grid-cols-[1fr_10rem]"><SearchBox value={q} onChange={(v) => { setQ(v); setPage(1); }} placeholder="Order number or @username…" /><Sel value={status} onChange={(v) => { setStatus(v); setPage(1); }} options={[{ value: "", label: "All statuses" }, "PENDING", "PAID", "PROCESSING", "DELIVERED", "CANCELLED", "REFUNDED"]} /></div>
      <Async r={r}>{(d) => (<>
        {d.items.map((o: any) => (
          <Link key={o.id} href={`/admin/orders/${o.id}`} className="card block !p-3">
            <div className="flex flex-wrap items-center justify-between gap-2"><span className="font-mono font-semibold">{o.orderNo}</span><span className="flex items-center gap-1.5">{o.refundStatus === "REQUESTED" && <Pill tone="amber">Refund requested</Pill>}<Pill tone={statusTone(o.status)}>{o.status}</Pill></span></div>
            <div className="text-xs text-hint">{o.user.firstName ?? o.user.username} · {when(o.createdAt)} · {money(o.total)}</div>
            <div className="mt-1 text-sm">{o.items.map((i: any) => `${i.quantity}× ${i.productName ?? "item"}${i.variantName ? ` (${i.variantName})` : ""}`).join(", ")}</div>
          </Link>
        ))}
        {!d.items.length && <div className="card text-center text-hint">No orders.</div>}
        <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
      </>)}</Async>
    </div>
  );
}

export function OrderDetail({ id, can }: { id: string; can: (p: string) => boolean }) {
  const r = useAdmin<any>(`/orders/${id}`);
  const [data, setData] = useState<Record<string, string>>({});
  const [note, setNote] = useState<string | null>(null);
  return (
    <div className="space-y-4">
      <Link href="/admin/orders" className="text-sm text-brand">← Orders</Link>
      <Async r={r}>{(o) => (<>
        <Card title={<span className="font-mono">{o.orderNo} <Pill tone={statusTone(o.status)}>{o.status}</Pill></span>}>
          <div className="text-sm text-hint">{o.user.firstName ?? o.user.username} · {when(o.createdAt)} · Total <b>{money(o.total)}</b> · Refund: {o.refundStatus}</div>
          {o.refundReason && <p className="mt-2 rounded-lg bg-amber-500/10 p-2 text-sm"><b>Customer's refund reason:</b> {o.refundReason}</p>}
        </Card>
        {o.items.map((i: any) => (
          <Card key={i.id} title={`${i.quantity}× ${i.productName ?? i.product.name}${i.variantName ? ` · ${i.variantName}` : ""}`}>
            <div className="text-sm text-hint">Unit price {money(i.unitPrice)}</div>
            {i.customerInput && <div className="mt-1 rounded-lg bg-blue-500/10 p-2 text-sm">{i.product.inputLabel ?? "Customer input"}: <b className="font-mono">{i.customerInput}</b></div>}
            {i.deliveredAt ? <p className="mt-2 text-sm text-emerald-700">Delivered {when(i.deliveredAt)}</p> : can("orders.fulfil") && ["PAID", "PROCESSING"].includes(o.status) ? (
              <div className="mt-3 space-y-2">
                {i.product.deliveryInstructions && <p className="text-xs text-hint">Instructions shown to the buyer: {i.product.deliveryInstructions}</p>}
                <F label="What the customer receives (code, account details, message)"><Area value={data[i.id] ?? ""} rows={3} maxLength={5000} onChange={(v) => setData({ ...data, [i.id]: v })} /></F>
                <Btn kind="primary" disabled={!(data[i.id] ?? "").trim()} onClick={async () => { if (await ask("Mark this line delivered and notify the customer?")) { const x = await run(() => adm(`/orders/${id}/deliver`, { itemId: i.id, data: data[i.id] }), "Delivered"); if (x) r.reload(); } }}>Mark delivered</Btn>
              </div>
            ) : <p className="mt-2 text-sm text-hint">Not delivered.</p>}
          </Card>
        ))}
        {can("orders.refund") && (
          <Card title="Refund">
            {o.status === "REFUNDED" ? <p className="text-sm text-hint">Refunded to the wallet{o.refundLedgerEntry ? ` (${money(o.refundLedgerEntry.amount)})` : ""}.</p> : ["PAID", "PROCESSING", "DELIVERED"].includes(o.status) ? (
              <div className="space-y-2">
                <p className="text-sm text-hint">A refund returns the full order total to the customer's wallet, exactly once. Requires a recent sign-in.</p>
                <div className="flex gap-2"><Btn kind="danger" onClick={async () => { if (await ask(`Refund ${money(o.total)} to the customer's wallet?`)) { const x = await run(() => adm(`/orders/${id}/refund`, {}), "Refunded"); if (x) r.reload(); } }}>Refund order</Btn>
                  {o.refundStatus === "REQUESTED" && <Btn onClick={async () => { const reason = prompt("Reason for declining (shown to the customer)") ?? ""; const x = await run(() => adm(`/orders/${id}/refund-reject`, { reason: reason || undefined }), "Declined"); if (x) r.reload(); }}>Decline request</Btn>}</div>
              </div>
            ) : <p className="text-sm text-hint">Not refundable in this status.</p>}
          </Card>
        )}
        {can("orders.fulfil") && (
          <Card title="Internal note"><Area value={note ?? o.adminNote ?? ""} rows={2} maxLength={1000} onChange={setNote} /><Btn className="mt-2" onClick={async () => { await run(() => adm(`/orders/${id}/note`, { note: note ?? o.adminNote ?? "" }), "Saved"); r.reload(); }}>Save note</Btn></Card>
        )}
      </>)}</Async>
    </div>
  );
}

/* ============================================================ Reports */
export function Reports() {
  const [days, setDays] = useState(30);
  const r = useAdmin<any>(`/reports?days=${days}`);
  const bars = (rows: { d: string; total?: string; n: number }[], useTotal: boolean) => {
    const max = Math.max(1, ...rows.map((x) => (useTotal ? Number(x.total) : x.n)));
    return <div className="flex h-32 items-end gap-0.5">{rows.map((x) => <div key={x.d} title={`${x.d}: ${useTotal ? money(x.total) : x.n}`} className="flex-1 rounded-t bg-brand/70" style={{ height: `${Math.max(3, ((useTotal ? Number(x.total) : x.n) / max) * 100)}%` }} />)}{!rows.length && <p className="text-sm text-hint">No data.</p>}</div>;
  };
  const sum = (rows: any[], k: string) => rows.reduce((a, x) => a + Number(x[k]), 0);
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between"><h1 className="text-2xl font-bold">Reports</h1><Sel value={String(days)} onChange={(v) => setDays(Number(v))} options={[{ value: "7", label: "7 days" }, { value: "30", label: "30 days" }, { value: "90", label: "90 days" }, { value: "365", label: "1 year" }]} /></div>
      <Async r={r}>{(d) => (<>
        <div className="grid gap-4 lg:grid-cols-2">
          <Card title={`Sales: ${money(sum(d.sales, "total"))} · ${sum(d.sales, "n")} orders`}>{bars(d.sales, true)}</Card>
          <Card title={`Verified deposits: ${money(sum(d.deposits, "total"))}`}>{bars(d.deposits, true)}</Card>
          <Card title={`New customers: ${sum(d.signups, "n")}`}>{bars(d.signups, false)}</Card>
          <Card title="Orders by status">{d.ordersByStatus.map((s: any) => <div key={s.status} className="flex justify-between border-b border-line py-1.5 text-sm last:border-0"><Pill tone={statusTone(s.status)}>{s.status}</Pill><b>{s.count}</b></div>)}</Card>
        </div>
        <Card title="Top products by revenue">{d.topProducts.length ? d.topProducts.map((p: any) => <div key={p.productId} className="flex justify-between border-b border-line py-1.5 text-sm last:border-0"><span>{p.name}</span><span>{p.qty} sold · <b>{money(p.revenue)}</b></span></div>) : <p className="text-sm text-hint">No sales in this period.</p>}</Card>
      </>)}</Async>
    </div>
  );
}

/* ============================================================ Settings */
export function Settings() {
  const r = useAdmin<any>("/settings");
  const meta = useAdmin<any>("/cms/meta");
  const [f, setF] = useState<any | null>(null);
  const cur = f ?? r.data;
  async function save() {
    const out = await run(() => adm("/settings", cur, "PUT"), "Settings saved");
    if (out) { setF(null); r.reload(); }
  }
  const labels: Record<string, string> = Object.fromEntries((meta.data?.homeBlocks ?? []).map((b: any) => [b.id, b.label]));
  return (
    <div className="space-y-4 pb-24">
      <h1 className="text-2xl font-bold">General settings</h1>
      <Async r={r}>{() => cur && (<>
        <Card title="Maintenance mode">
          <Check label="Put the Mini App in maintenance mode" hint="Customers see the message below and cannot place orders or payments. Admins can still sign in." checked={cur.maintenance} onChange={(v) => setF({ ...cur, maintenance: v })} />
          <F label="Message" className="mt-2"><TextIn value={cur.maintenanceMessage} maxLength={300} onChange={(v) => setF({ ...cur, maintenanceMessage: v })} /></F>
        </Card>
        <Card title="Contact & support links">
          <div className="grid gap-3 sm:grid-cols-2">
            <F label="Support Telegram username"><TextIn value={cur.contact.telegramUsername ?? ""} maxLength={32} placeholder="entirebazar_support" onChange={(v) => setF({ ...cur, contact: { ...cur.contact, telegramUsername: v.replace(/^@/, "") || null } })} /></F>
            <F label="Support email"><TextIn value={cur.contact.email ?? ""} maxLength={120} onChange={(v) => setF({ ...cur, contact: { ...cur.contact, email: v || null } })} /></F>
            <F label="Phone"><TextIn value={cur.contact.phone ?? ""} maxLength={30} onChange={(v) => setF({ ...cur, contact: { ...cur.contact, phone: v || null } })} /></F>
            <F label="Support hours"><TextIn value={cur.contact.supportHours ?? ""} maxLength={80} placeholder="Daily 10:00–22:00" onChange={(v) => setF({ ...cur, contact: { ...cur.contact, supportHours: v || null } })} /></F>
          </div>
        </Card>
        <Card title="Homepage sections">
          <p className="mb-2 text-sm text-hint">Choose which blocks appear on the homepage and in what order. Banners, notices and featured categories are managed in their own screens.</p>
          {cur.homeLayout.map((b: any, i: number) => (
            <div key={b.id} className="mb-1 flex items-center gap-2 rounded-xl border border-line p-2">
              <div className="flex-1"><Check label={labels[b.id] ?? b.id} checked={b.enabled} onChange={(v) => setF({ ...cur, homeLayout: cur.homeLayout.map((x: any) => (x.id === b.id ? { ...x, enabled: v } : x)) })} /></div>
              <Btn small disabled={i === 0} onClick={() => setF({ ...cur, homeLayout: move(cur.homeLayout, i, -1) })}>↑</Btn><Btn small disabled={i === cur.homeLayout.length - 1} onClick={() => setF({ ...cur, homeLayout: move(cur.homeLayout, i, 1) })}>↓</Btn>
            </div>
          ))}
          {(meta.data?.homeBlocks ?? []).filter((b: any) => !cur.homeLayout.some((x: any) => x.id === b.id)).map((b: any) => <Btn key={b.id} small className="mr-2 mt-1" onClick={() => setF({ ...cur, homeLayout: [...cur.homeLayout, { id: b.id, enabled: true }] })}>＋ {b.label}</Btn>)}
        </Card>
        <Card title="Featured products on the homepage">
          <HomeProducts ids={cur.homeFeaturedProductIds} onChange={(ids) => setF({ ...cur, homeFeaturedProductIds: ids })} />
        </Card>
        <Card title="Allowed link hosts">
          <p className="mb-2 text-sm text-hint">Buttons and support links may only open HTTPS pages on these hosts. One per line, e.g. <code>example.com</code> or <code>*.example.com</code>. Telegram links (t.me) are included by default.</p>
          <Area value={cur.allowedExternalHosts.join("\n")} rows={4} onChange={(v) => setF({ ...cur, allowedExternalHosts: v.split("\n").map((x) => x.trim().toLowerCase()).filter(Boolean) })} />
        </Card>
        <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card p-3"><div className="mx-auto flex max-w-6xl items-center gap-3"><span className="flex-1 text-sm text-hint">{f ? "Unsaved changes." : "Saved."}</span><Btn kind="primary" disabled={!f} onClick={() => void save()}>Save settings</Btn></div></div>
      </>)}</Async>
    </div>
  );
}
function HomeProducts({ ids, onChange }: { ids: string[]; onChange: (ids: string[]) => void }) {
  return <><ProductPicker value={ids} max={24} onChange={onChange} /><p className="mt-2 text-xs text-hint">Leave empty to show products marked “Featured”.</p></>;
}

/* ============================================================ Roles & admins */
export function Roles() {
  const roles = useAdmin<any>("/roles");
  const admins = useAdmin<any[]>("/admins");
  const [edit, setEdit] = useState<any | null>(null);
  const [nu, setNu] = useState<{ telegramId: string; name: string; roleKey: string } | null>(null);
  const groups: { label: string; permissions: string[] }[] = roles.data?.groups ?? [];
  async function saveRole() {
    const body = { name: edit.name, description: edit.description || null, permissions: edit.permissions };
    const x = await run(() => (edit.id ? adm(`/roles/${edit.id}`, body, "PUT") : adm("/roles", body)), "Role saved");
    if (x) { setEdit(null); roles.reload(); }
  }
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">Roles & permissions</h1>
      <Card title="Administrators" actions={<Btn small onClick={() => setNu({ telegramId: "", name: "", roleKey: "SUPPORT" })}>＋ Add administrator</Btn>}>
        <p className="mb-3 text-sm text-hint">Administrators sign in with their Telegram account. Money, credential and role actions additionally need a recent sign-in. You cannot change your own role.</p>
        <Async r={admins}>{(items) => items.map((a: any) => (
          <div key={a.id} className="mb-2 flex flex-wrap items-center gap-2 rounded-xl border border-line p-2">
            <div className="min-w-0 flex-1"><div className="font-medium">{a.name ?? "—"} <span className="font-mono text-xs text-hint">{a.telegramId}</span></div><div className="text-xs"><Pill tone="blue">{a.customRole?.name ?? a.role}</Pill> {a.disabled && <Pill tone="red">disabled</Pill>}</div></div>
            <Sel value={a.customRole?.id ? `role:${a.customRole.id}` : a.role} onChange={async (v) => { const body = v.startsWith("role:") ? { roleId: v.slice(5) } : { role: v, roleId: null }; const x = await run(() => adm(`/admins/${a.id}`, body, "PATCH"), "Updated"); if (x) admins.reload(); }}
              options={[{ value: "OWNER", label: "Owner" }, { value: "ADMIN", label: "Admin" }, { value: "SUPPORT", label: "Support" }, ...((roles.data?.custom ?? []).map((r: any) => ({ value: `role:${r.id}`, label: r.name })))]} />
            <Btn small kind={a.disabled ? "ghost" : "danger"} onClick={async () => { if (await ask(a.disabled ? "Re-enable this administrator?" : "Disable this administrator?")) { const x = await run(() => adm(`/admins/${a.id}`, { disabled: !a.disabled }, "PATCH"), "Updated"); if (x) admins.reload(); } }}>{a.disabled ? "Enable" : "Disable"}</Btn>
          </div>
        ))}</Async>
        {nu && (
          <div className="mt-3 space-y-2 rounded-xl border border-brand/40 p-3">
            <div className="grid gap-3 sm:grid-cols-3"><F label="Telegram numeric ID"><TextIn value={nu.telegramId} inputMode="numeric" onChange={(v) => setNu({ ...nu, telegramId: v.replace(/\D/g, "") })} /></F><F label="Name"><TextIn value={nu.name} maxLength={60} onChange={(v) => setNu({ ...nu, name: v })} /></F>
              <F label="Role"><Sel value={nu.roleKey} onChange={(v) => setNu({ ...nu, roleKey: v })} options={[{ value: "ADMIN", label: "Admin" }, { value: "SUPPORT", label: "Support" }, ...((roles.data?.custom ?? []).map((r: any) => ({ value: `role:${r.id}`, label: r.name })))]} /></F></div>
            <div className="flex gap-2"><Btn kind="primary" disabled={nu.telegramId.length < 3} onClick={async () => { const body: any = { telegramId: nu.telegramId, name: nu.name || undefined }; if (nu.roleKey.startsWith("role:")) body.roleId = nu.roleKey.slice(5); else body.role = nu.roleKey; const x = await run(() => adm("/admins", body), "Administrator added"); if (x) { setNu(null); admins.reload(); } }}>Add</Btn><Btn onClick={() => setNu(null)}>Cancel</Btn></div>
          </div>
        )}
      </Card>
      <Card title="Custom roles" actions={<Btn small onClick={() => setEdit({ name: "", description: "", permissions: [] })}>＋ New role</Btn>}>
        <Async r={roles}>{(d) => (<>
          {d.custom.map((r: any) => (
            <div key={r.id} className="mb-2 flex flex-wrap items-center gap-2 rounded-xl border border-line p-2"><div className="min-w-0 flex-1"><div className="font-medium">{r.name} {r.system && <Pill>built-in template</Pill>}</div><div className="text-xs text-hint">{r.permissions.length} permissions · {r._count.admins} admins · {r.description}</div></div>
              <Btn small onClick={() => setEdit({ ...r, description: r.description ?? "" })}>Edit</Btn>
              {!r.system && <Btn small kind="danger" onClick={async () => { if (await ask(`Delete role ${r.name}?`)) { await run(() => adm(`/roles/${r.id}`, undefined, "DELETE"), "Deleted"); roles.reload(); } }}>Delete</Btn>}</div>
          ))}
          {d.builtIn.map((b: any) => <div key={b.name} className="mb-1 text-sm"><Pill tone="gray">{b.name}</Pill> <span className="text-hint">{b.permissions.length} permissions (fixed)</span></div>)}
        </>)}</Async>
        {edit && (
          <div className="mt-3 space-y-3 rounded-xl border border-brand/40 p-3">
            <div className="grid gap-3 sm:grid-cols-2"><F label="Role name"><TextIn value={edit.name} maxLength={40} disabled={edit.system} onChange={(v) => setEdit({ ...edit, name: v })} /></F><F label="Description"><TextIn value={edit.description} maxLength={200} onChange={(v) => setEdit({ ...edit, description: v })} /></F></div>
            {groups.map((g) => (
              <div key={g.label}><div className="text-sm font-semibold">{g.label}</div><div className="grid gap-x-4 sm:grid-cols-2">{g.permissions.map((p) => <Check key={p} label={p} checked={edit.permissions.includes(p)} onChange={(v) => setEdit({ ...edit, permissions: v ? [...edit.permissions, p] : edit.permissions.filter((x: string) => x !== p) })} />)}</div></div>
            ))}
            <p className="text-xs text-hint">You can only grant permissions you hold yourself (owners can grant any).</p>
            <div className="flex gap-2"><Btn kind="primary" disabled={edit.name.trim().length < 2} onClick={() => void saveRole()}>Save role</Btn><Btn onClick={() => setEdit(null)}>Cancel</Btn></div>
          </div>
        )}
      </Card>
    </div>
  );
}

/* ============================================================ Audit */
export function Audit() {
  const [action, setAction] = useState("");
  const [page, setPage] = useState(1);
  const r = useAdmin<any>(`/audit?page=${page}&limit=50${action ? `&action=${encodeURIComponent(action)}` : ""}`);
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-bold">Audit log</h1>
      <SearchBox value={action} onChange={(v) => { setAction(v); setPage(1); }} placeholder="Filter by action, e.g. wallet, deposit, category…" />
      <Async r={r}>{(d) => (<>
        <div className="card overflow-x-auto !p-0"><table className="w-full text-sm"><thead className="text-left text-xs text-hint"><tr><th className="p-2">When</th><th>Admin</th><th>Action</th><th>Target</th><th className="p-2">Details</th></tr></thead>
          <tbody>{d.items.map((a: any) => <tr key={a.id} className="border-t border-line align-top"><td className="p-2 whitespace-nowrap text-xs">{when(a.createdAt)}</td><td className="whitespace-nowrap">{a.admin?.name ?? "—"}</td><td className="font-mono text-xs">{a.action}</td><td className="text-xs">{a.targetType} {a.targetId?.slice(0, 10)}</td><td className="max-w-xs break-words p-2 text-xs text-hint">{a.meta ? JSON.stringify(a.meta).slice(0, 160) : ""}</td></tr>)}</tbody></table></div>
        <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
      </>)}</Async>
    </div>
  );
}
void assetUrl; void toast; void NumIn;
