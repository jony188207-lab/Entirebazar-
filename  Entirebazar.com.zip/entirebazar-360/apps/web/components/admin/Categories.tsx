"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { CategoryView } from "@/components/CategoryView";
import { ButtonBuilder, SectionBuilder } from "./Builders";
import { Area, Async, Btn, Card, CategoryPicker, Check, DateIn, F, FaqEditor, ImageField, NumIn, Pill, Sel, Tabs, TextIn, adm, ask, move, run, statusTone, toast, useAdmin, useDirty } from "./kit";

/* ============================================================
 * Category list / tree
 * ============================================================ */
export function CategoryList() {
  const router = useRouter();
  const [archived, setArchived] = useState(false);
  const list = useAdmin<any[]>(`/categories?${archived ? "status=ARCHIVED" : ""}`);
  const [draft, setDraft] = useState<{ name: string; parentId: string | null } | null>(null);
  const rows = list.data ?? [];

  const tree = useMemo(() => {
    const kids = new Map<string | null, any[]>();
    for (const c of rows) kids.set(c.parentId, [...(kids.get(c.parentId) ?? []), c]);
    for (const v of kids.values()) v.sort((a, b) => a.sortOrder - b.sortOrder);
    const known = new Set(rows.map((r) => r.id));
    const out: { c: any; depth: number; siblings: any[] }[] = [];
    const walk = (pid: string | null, depth: number) => { const s = kids.get(pid) ?? []; for (const c of s) { out.push({ c, depth, siblings: s }); walk(c.id, depth + 1); } };
    walk(null, 0);
    // rows whose parent is hidden (e.g. archived parent) still appear
    for (const c of rows) if (c.parentId && !known.has(c.parentId)) out.push({ c, depth: 1, siblings: [c] });
    return out;
  }, [rows]);

  async function create() {
    const r = await run(() => adm("/categories", { name: draft!.name, parentId: draft!.parentId }), "Category created as a draft");
    if (r) router.push(`/admin/categories/${r.id}`);
  }
  async function act(c: any, what: string, confirmText?: string, okMsg?: string) {
    if (confirmText && !(await ask(confirmText))) return;
    const r = await run(() => (what === "delete" ? adm(`/categories/${c.id}`, undefined, "DELETE") : adm(`/categories/${c.id}/${what}`, {})), okMsg);
    if (r && (r as any).warnings?.length) toast((r as any).warnings.join(" "), "ok");
    list.reload();
  }
  async function reorder(siblings: any[], i: number, dir: -1 | 1) {
    await run(() => adm("/categories/reorder", { ids: move(siblings, i, dir).map((s) => s.id) }));
    list.reload();
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h1 className="text-2xl font-bold">Categories</h1>
        <div className="flex gap-2">
          <Btn small onClick={() => setArchived(!archived)}>{archived ? "← Active categories" : "Archived"}</Btn>
          {!archived && <Btn small kind="primary" onClick={() => setDraft({ name: "", parentId: null })}>＋ New category</Btn>}
        </div>
      </div>

      {draft && (
        <Card title="New category">
          <div className="grid gap-3 sm:grid-cols-2">
            <F label="Name"><TextIn value={draft.name} maxLength={80} onChange={(v) => setDraft({ ...draft, name: v })} /></F>
            <F label="Parent (optional)"><CategoryPicker single value={draft.parentId ? [draft.parentId] : []} onChange={(v) => setDraft({ ...draft, parentId: v[0] ?? null })} /></F>
          </div>
          <p className="mt-2 text-xs text-hint">It is created as a draft. Customers cannot see it until you publish it.</p>
          <div className="mt-3 flex gap-2"><Btn kind="primary" disabled={!draft.name.trim()} onClick={() => void create()}>Create & edit</Btn><Btn onClick={() => setDraft(null)}>Cancel</Btn></div>
        </Card>
      )}

      <Async r={list}>{() => (
        <div className="space-y-2">
          {!tree.length && <div className="card text-center text-hint">{archived ? "No archived categories." : "No categories yet. Create your first one."}</div>}
          {tree.map(({ c, depth, siblings }) => {
            const i = siblings.findIndex((s) => s.id === c.id);
            return (
              <div key={c.id} className="card !p-3" style={{ marginLeft: Math.min(depth, 4) * 16 }}>
                <div className="flex flex-wrap items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <Link href={`/admin/categories/${c.id}`} className="font-semibold">{c.icon ?? "🗂️"} {c.name}</Link>
                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-hint">
                      <Pill tone={statusTone(c.status)}>{c.status}</Pill>
                      {c.status === "PUBLISHED" && <Pill tone={c.live ? "green" : "amber"}>{c.live ? "Live" : "Not live yet"}</Pill>}
                      {c.featured && <Pill tone="blue">★ Featured</Pill>}
                      {c.visibility === "UNLISTED" && <Pill>Unlisted</Pill>}
                      <span>/{c.slug} · {c.counts.products} products · {c.counts.sections} sections</span>
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {!archived && <><Btn small disabled={i <= 0} onClick={() => void reorder(siblings, i, -1)}>↑</Btn><Btn small disabled={i === siblings.length - 1} onClick={() => void reorder(siblings, i, 1)}>↓</Btn></>}
                    <Link href={`/admin/categories/${c.id}`} className="btn-ghost !px-3 !py-1.5 text-sm">Edit</Link>
                    {!archived && c.status !== "PUBLISHED" && <Btn small onClick={() => void act(c, "publish", undefined, "Published")}>Publish</Btn>}
                    {!archived && c.status === "PUBLISHED" && <Btn small onClick={() => void act(c, "unpublish", "Unpublish? Customers will no longer see it.", "Unpublished")}>Unpublish</Btn>}
                    {!archived && <Btn small onClick={() => void act(c, "duplicate", undefined, "Duplicated as a draft")}>Duplicate</Btn>}
                    {!archived && <Btn small onClick={() => void act(c, "archive", `Archive "${c.name}"? It disappears from the Mini App but can be restored.`, "Archived")}>Archive</Btn>}
                    {archived && <Btn small onClick={() => void act(c, "restore", undefined, "Restored as a draft")}>Restore</Btn>}
                    {archived && <Btn small kind="danger" onClick={() => void act(c, "delete", `Permanently delete "${c.name}" with its sections and buttons? Products are kept.`, "Deleted")}>Delete</Btn>}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}</Async>
    </div>
  );
}

/* ============================================================
 * Category editor: 11 tabs
 * ============================================================ */
const TABS = [
  ["general", "General"], ["layout", "Layout & Sections"], ["products", "Products"], ["buttons", "Buttons & Actions"], ["notices", "Notices & Banners"],
  ["filters", "Filters & Sorting"], ["pricing", "Pricing & Discounts"], ["faq", "FAQ & Support"], ["seo", "SEO & Display"], ["visibility", "Visibility & Scheduling"], ["preview", "Preview"],
].map(([id, label]) => ({ id, label }));

const toForm = (c: any) => ({
  name: c.name, slug: c.slug, parentId: c.parentId ?? null, description: c.description ?? "", icon: c.icon ?? "", imageUrl: c.imageUrl ?? null, coverUrl: c.coverUrl ?? null,
  visibility: c.visibility, purchasable: c.purchasable, unavailableMessage: c.unavailableMessage ?? "", featured: c.featured, featuredOrder: c.featuredOrder,
  publishAt: c.publishAt ?? null, unpublishAt: c.unpublishAt ?? null, supportLink: c.supportLink ?? "", settings: c.settings, faq: c.faq ?? [],
  discountPercent: c.discountPercent === null || c.discountPercent === undefined ? null : Number(c.discountPercent), discountStartsAt: c.discountStartsAt ?? null, discountEndsAt: c.discountEndsAt ?? null,
});
const toPayload = (f: any) => ({ ...f, description: f.description || null, icon: f.icon || null, unavailableMessage: f.unavailableMessage || null, supportLink: f.supportLink || null });

export function CategoryEditor({ id }: { id: string }) {
  const router = useRouter();
  const r = useAdmin<any>(`/categories/${id}`);
  const { form, setForm, reset, dirty } = useDirty<any>(null);
  const [tab, setTab] = useState("general");
  const [saving, setSaving] = useState(false);
  useEffect(() => { if (r.data && !form) reset(toForm(r.data)); }, [r.data]); // eslint-disable-line react-hooks/exhaustive-deps

  if (r.loading && !r.data) return <div className="py-8 text-center text-hint">Loading…</div>;
  if (r.error || !r.data || !form) return <div className="card text-red-600">{r.error ?? "Not found"}</div>;
  const c = r.data;
  const readOnly = c.status === "ARCHIVED";
  const set = (patch: any) => setForm({ ...form, ...patch });
  const setS = (group: string, patch: any) => setForm({ ...form, settings: { ...form.settings, [group]: { ...form.settings[group], ...patch } } });
  const st = form.settings;

  async function save() {
    setSaving(true);
    const out = await run(() => adm(`/categories/${id}`, toPayload(form), "PUT"), "Saved");
    setSaving(false);
    if (out) { const fresh = await r.reload(); void fresh; reset(form); }
  }
  async function lifecycle(what: string, confirmText?: string, okMsg?: string) {
    if (dirty && !(await ask("You have unsaved changes. Continue without saving them?"))) return;
    if (confirmText && !(await ask(confirmText))) return;
    const out: any = await run(() => (what === "delete" ? adm(`/categories/${id}`, undefined, "DELETE") : adm(`/categories/${id}/${what}`, {})), okMsg);
    if (!out) return;
    if (out.warnings?.length) toast(out.warnings.join(" "));
    if (what === "delete") return router.push("/admin/categories");
    if (what === "duplicate") return router.push(`/admin/categories/${out.id}`);
    setForm(null); r.reload();
  }

  return (
    <div className="pb-24">
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Link href="/admin/categories" className="text-sm text-brand">← Categories</Link>
        <h1 className="text-xl font-bold">{c.icon} {c.name}</h1>
        <Pill tone={statusTone(c.status)}>{c.status}</Pill>
        {c.status === "PUBLISHED" && <Pill tone={c.live ? "green" : "amber"}>{c.live ? "Live" : "Not live yet"}</Pill>}
      </div>
      {readOnly && <div className="mb-3 rounded-xl bg-amber-500/15 p-3 text-sm text-amber-700">This category is archived. Restore it (Visibility & Scheduling tab) to edit it.</div>}
      <Tabs tabs={TABS} value={tab} onChange={setTab} />

      <fieldset disabled={readOnly} className="space-y-4">
        {tab === "general" && (
          <Card title="General settings">
            <div className="grid gap-3 sm:grid-cols-2">
              <F label="Name"><TextIn value={form.name} maxLength={80} onChange={(v) => set({ name: v })} /></F>
              <F label="URL slug" hint="Lowercase letters, numbers and dashes. Changing it changes the page link."><TextIn value={form.slug} maxLength={60} onChange={(v) => set({ slug: v.toLowerCase() })} /></F>
              <F label="Parent category"><CategoryPicker single exclude={[id]} value={form.parentId ? [form.parentId] : []} onChange={(v) => set({ parentId: v[0] ?? null })} /></F>
              <F label="Icon (emoji)"><TextIn value={form.icon} maxLength={8} onChange={(v) => set({ icon: v })} /></F>
            </div>
            <F label="Description" className="mt-3"><Area value={form.description} maxLength={1000} onChange={(v) => set({ description: v })} /></F>
            <div className="mt-3 grid gap-4 sm:grid-cols-2">
              <ImageField label="Category image" value={form.imageUrl} onChange={(v) => set({ imageUrl: v })} />
              <ImageField label="Cover banner" value={form.coverUrl} onChange={(v) => set({ coverUrl: v })} />
            </div>
            <div className="mt-3 grid gap-3 sm:grid-cols-2">
              <Check label="Featured on the homepage" checked={form.featured} onChange={(v) => set({ featured: v })} />
              {form.featured && <F label="Featured order (lower first)"><NumIn value={form.featuredOrder} min={0} onChange={(v) => set({ featuredOrder: v ?? 0 })} /></F>}
            </div>
          </Card>
        )}

        {tab === "layout" && (
          <>
            <Card title="Page layout">
              <div className="grid gap-3 sm:grid-cols-2">
                <F label="Product columns"><Sel value={String(st.layout.columns)} onChange={(v) => setS("layout", { columns: Number(v) })} options={[{ value: "1", label: "1 (list)" }, { value: "2", label: "2" }, { value: "3", label: "3" }]} /></F>
                <F label="Product card style"><Sel value={st.layout.productCardLayout} onChange={(v) => setS("layout", { productCardLayout: v })} options={["DEFAULT", "COMPACT", "WIDE"]} /></F>
              </div>
              <div className="mt-2 grid gap-1 sm:grid-cols-2">
                <Check label="Show breadcrumbs" checked={st.layout.showBreadcrumbs} onChange={(v) => setS("layout", { showBreadcrumbs: v })} />
                <Check label="Show subcategories" checked={st.layout.showSubcategories} onChange={(v) => setS("layout", { showSubcategories: v })} />
                <Check label="Show cover banner" checked={st.layout.showCover} onChange={(v) => setS("layout", { showCover: v })} />
                <Check label="Show product counts" checked={st.layout.showProductCount} onChange={(v) => setS("layout", { showProductCount: v })} />
                <Check label="Show the full product list under the sections" checked={st.layout.showDefaultProductList} onChange={(v) => setS("layout", { showDefaultProductList: v })} />
              </div>
              <F label="Message when there are no products" className="mt-3"><TextIn value={st.layout.emptyMessage} maxLength={200} onChange={(v) => setS("layout", { emptyMessage: v })} /></F>
              <p className="mt-2 text-xs text-hint">Save the layout settings with the Save button below. Sections are saved separately, as you edit them.</p>
            </Card>
            <SectionBuilder categoryId={id} sections={c.sections} reload={r.reload} />
          </>
        )}

        {tab === "products" && <CategoryProducts id={id} items={c.products} reload={r.reload} />}
        {tab === "buttons" && <ButtonBuilder owner={{ categoryId: id }} title="Category buttons" note="These appear on the category page. Use position TOP, BOTTOM or STICKY. Buttons for individual sections are edited inside each section." />}
        {tab === "notices" && <CategoryNotices id={id} />}

        {tab === "filters" && (
          <Card title="Filters & sorting">
            <p className="mb-2 text-sm font-medium">Filters customers can use</p>
            <Check label="Search box" checked={st.filters.search} onChange={(v) => setS("filters", { search: v })} />
            <Check label="Price range" checked={st.filters.priceRange} onChange={(v) => setS("filters", { priceRange: v })} />
            <Check label="In-stock only" checked={st.filters.inStock} onChange={(v) => setS("filters", { inStock: v })} />
            <Check label="Product type" checked={st.filters.productTypes} onChange={(v) => setS("filters", { productTypes: v })} />
            <p className="mb-2 mt-4 text-sm font-medium">Sort options offered</p>
            {["NEWEST", "POPULAR", "PRICE_ASC", "PRICE_DESC", "NAME"].map((o) => (
              <Check key={o} label={o.replace("_", " ").toLowerCase()} checked={st.sorting.options.includes(o)}
                onChange={(v) => { const opts = v ? [...st.sorting.options, o] : st.sorting.options.filter((x: string) => x !== o); if (opts.length) setS("sorting", { options: opts, default: opts.includes(st.sorting.default) ? st.sorting.default : opts[0] }); }} />
            ))}
            <F label="Default sort" className="mt-3"><Sel value={st.sorting.default} onChange={(v) => setS("sorting", { default: v })} options={st.sorting.options} /></F>
            <Check label="Show pinned products first" hint="Pin products on the Products tab." checked={st.sorting.pinnedFirst} onChange={(v) => setS("sorting", { pinnedFirst: v })} />
          </Card>
        )}

        {tab === "pricing" && (
          <Card title="Pricing & discounts">
            <p className="mb-3 text-sm text-hint">A category discount applies to every product in it. The customer always gets the single best discount (discounts never stack), and the checkout recalculates the price on the server.</p>
            <div className="grid gap-3 sm:grid-cols-3">
              <F label="Discount %"><NumIn value={form.discountPercent} min={0} max={90} step="0.5" onChange={(v) => set({ discountPercent: v })} /></F>
              <F label="Starts (optional)"><DateIn value={form.discountStartsAt} onChange={(v) => set({ discountStartsAt: v })} /></F>
              <F label="Ends (optional)"><DateIn value={form.discountEndsAt} onChange={(v) => set({ discountEndsAt: v })} /></F>
            </div>
            <p className="mb-1 mt-4 text-sm font-medium">How prices are shown</p>
            <Check label="Show the original price crossed out" checked={st.pricing.showOriginalPrice} onChange={(v) => setS("pricing", { showOriginalPrice: v })} />
            <Check label="Show a discount badge" checked={st.pricing.showDiscountBadge} onChange={(v) => setS("pricing", { showDiscountBadge: v })} />
            <F label="Badge text" className="mt-2"><TextIn value={st.pricing.badgeText} maxLength={30} onChange={(v) => setS("pricing", { badgeText: v })} /></F>
          </Card>
        )}

        {tab === "faq" && (
          <>
            <Card title="Category FAQ"><FaqEditor items={form.faq} onChange={(v) => set({ faq: v })} /></Card>
            <Card title="Support link">
              <F label="Help link for this category" hint="HTTPS only, and the host must be on the allow-list (Settings → Allowed link hosts). Telegram links (t.me) are allowed by default."><TextIn value={form.supportLink} maxLength={500} placeholder="https://t.me/your_support" onChange={(v) => set({ supportLink: v })} /></F>
            </Card>
          </>
        )}

        {tab === "seo" && (
          <>
            <Card title="Search & sharing">
              <F label="Page title"><TextIn value={st.seo.title} maxLength={70} onChange={(v) => setS("seo", { title: v })} /></F>
              <F label="Description" className="mt-3"><TextIn value={st.seo.description} maxLength={160} onChange={(v) => setS("seo", { description: v })} /></F>
              <F label="Keywords (comma separated, up to 10)" className="mt-3"><TextIn value={(st.seo.keywords ?? []).join(", ")} onChange={(v) => setS("seo", { keywords: v.split(",").map((x) => x.trim()).filter(Boolean).slice(0, 10) })} /></F>
            </Card>
            <Card title="Display">
              <F label="Accent colour (optional, #RRGGBB)"><TextIn value={st.display.accentColor ?? ""} maxLength={7} placeholder="#2563eb" onChange={(v) => setS("display", { accentColor: v || null })} /></F>
              <Check label="Show in the shop's category chips" checked={st.display.showInShopMenu} onChange={(v) => setS("display", { showInShopMenu: v })} />
              <Check label="Hide this category while it has no products" checked={st.display.hideWhenEmpty} onChange={(v) => setS("display", { hideWhenEmpty: v })} />
            </Card>
          </>
        )}

        {tab === "visibility" && (
          <>
            <Card title="Visibility & scheduling">
              <div className="grid gap-3 sm:grid-cols-2">
                <F label="Who can find it" hint="Unlisted pages work from a direct link but are hidden from lists."><Sel value={form.visibility} onChange={(v) => set({ visibility: v })} options={[{ value: "PUBLIC", label: "Public (listed)" }, { value: "UNLISTED", label: "Unlisted (link only)" }]} /></F>
                <div><Check label="Purchases enabled" hint="Turn off to browse-only (e.g. out of season)." checked={form.purchasable} onChange={(v) => set({ purchasable: v })} /></div>
                {!form.purchasable && <F label="Message shown to customers" className="sm:col-span-2"><TextIn value={form.unavailableMessage} maxLength={200} onChange={(v) => set({ unavailableMessage: v })} /></F>}
                <F label="Publish automatically at (optional)"><DateIn value={form.publishAt} onChange={(v) => set({ publishAt: v })} /></F>
                <F label="Unpublish automatically at (optional)"><DateIn value={form.unpublishAt} onChange={(v) => set({ unpublishAt: v })} /></F>
              </div>
              <p className="mt-2 text-xs text-hint">A category is live only when it and all its parents are published and inside their schedule. Edits to a published category go live as soon as you save: unpublish or duplicate it first to work on changes privately.</p>
            </Card>
            <Card title="Lifecycle">
              <div className="flex flex-wrap gap-2">
                {c.status !== "PUBLISHED" && c.status !== "ARCHIVED" && <Btn kind="primary" onClick={() => void lifecycle("publish", undefined, "Published")}>Publish</Btn>}
                {c.status === "PUBLISHED" && <Btn onClick={() => void lifecycle("unpublish", "Unpublish? Customers will no longer see this category.", "Unpublished")}>Unpublish</Btn>}
                {c.status !== "ARCHIVED" && <Btn onClick={() => void lifecycle("duplicate", undefined, "Duplicated as a draft")}>Duplicate</Btn>}
                {c.status !== "ARCHIVED" && <Btn onClick={() => void lifecycle("archive", "Archive this category? It can be restored later.", "Archived")}>Archive</Btn>}
                {c.status === "ARCHIVED" && <Btn onClick={() => void lifecycle("restore", undefined, "Restored as a draft")}>Restore</Btn>}
                {c.status === "ARCHIVED" && <Btn kind="danger" onClick={() => void lifecycle("delete", "Permanently delete this category, its sections and buttons? Products are kept.", "Deleted")}>Delete permanently</Btn>}
              </div>
            </Card>
          </>
        )}
      </fieldset>

      {tab === "preview" && <Preview id={id} dirty={dirty} />}

      {!readOnly && tab !== "preview" && !["layout-sections-only"].includes(tab) && (
        <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card p-3">
          <div className="mx-auto flex max-w-6xl items-center gap-3">
            <span className="flex-1 text-sm text-hint">{dirty ? "You have unsaved changes." : "All changes saved."}</span>
            {dirty && <Btn onClick={() => reset(toForm(c))}>Discard</Btn>}
            <Btn kind="primary" disabled={!dirty || saving} onClick={() => void save()}>{saving ? "Saving…" : "Save changes"}</Btn>
          </div>
        </div>
      )}
    </div>
  );
}

function Preview({ id, dirty }: { id: string; dirty: boolean }) {
  const [q, setQ] = useState({ q: "", sort: "", page: 1 });
  const r = useAdmin<any>(`/categories/${id}/preview?page=${q.page}${q.sort ? `&sort=${q.sort.toLowerCase()}` : ""}${q.q ? `&q=${encodeURIComponent(q.q)}` : ""}`);
  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2 text-sm">
        <Btn small onClick={r.reload}>↻ Refresh</Btn>
        {dirty && <span className="text-amber-600">Unsaved edits are not shown. Save first, then refresh.</span>}
        {r.data && <span className="text-hint">{r.data.note}</span>}
      </div>
      <Async r={r}>{(d) => (
        <div className="mx-auto max-w-sm overflow-hidden rounded-[2rem] border-4 border-gray-800 bg-bg p-4 shadow-xl">
          <CategoryView page={d.page} readOnly query={{ q: q.q, sort: q.sort || d.page.settings.sorting.default, inStock: false, page: q.page }} onQuery={(n) => setQ({ ...q, ...n } as any)} />
        </div>
      )}</Async>
    </div>
  );
}

function CategoryProducts({ id, items, reload }: { id: string; items: any[]; reload: () => void }) {
  const [q, setQ] = useState("");
  const res = useAdmin<any>(q.length >= 2 ? `/products?q=${encodeURIComponent(q)}&limit=10` : null);
  const assigned = new Set(items.map((i) => i.productId));
  async function order(next: any[]) { await run(() => adm(`/categories/${id}/products/order`, { ids: next.map((i) => i.productId) }, "PUT")); reload(); }
  return (
    <Card title={`Products in this category (${items.length})`}>
      <div className="space-y-2">
        {items.map((it, i) => (
          <div key={it.productId} className="flex flex-wrap items-center gap-2 rounded-xl border border-line p-2">
            <div className="min-w-0 flex-1"><div className="font-medium">{it.pinned ? "📌 " : ""}{it.product.name}</div><div className="text-xs text-hint"><Pill tone={statusTone(it.product.status)}>{it.product.status}</Pill> ৳{String(it.product.price)}</div></div>
            <Btn small disabled={i === 0} onClick={() => void order(move(items, i, -1))}>↑</Btn>
            <Btn small disabled={i === items.length - 1} onClick={() => void order(move(items, i, 1))}>↓</Btn>
            <Btn small onClick={async () => { await run(() => adm(`/categories/${id}/products/${it.productId}`, { pinned: !it.pinned }, "PATCH")); reload(); }}>{it.pinned ? "Unpin" : "Pin"}</Btn>
            <Btn small kind="danger" onClick={async () => { await run(() => adm(`/categories/${id}/products/${it.productId}`, undefined, "DELETE"), "Removed from category"); reload(); }}>Remove</Btn>
          </div>
        ))}
        {!items.length && <p className="text-sm text-hint">No products assigned yet.</p>}
      </div>
      <div className="mt-4">
        <input className="input" placeholder="Search products to add…" value={q} onChange={(e) => setQ(e.target.value)} />
        {res.data?.items?.filter((p: any) => !assigned.has(p.id)).map((p: any) => (
          <button key={p.id} className="mt-1 flex w-full items-center justify-between rounded-xl border border-line px-3 py-2 text-left text-sm" onClick={async () => { await run(() => adm(`/categories/${id}/products`, { productIds: [p.id] }), "Added"); setQ(""); reload(); }}>
            <span>{p.name}</span><Pill tone={statusTone(p.status)}>{p.status}</Pill>
          </button>
        ))}
      </div>
    </Card>
  );
}

function CategoryNotices({ id }: { id: string }) {
  const list = useAdmin<any>(`/notices?categoryId=${id}&limit=50`);
  return (
    <Card title="Notices for this category" actions={<Link className="btn !px-3 !py-1.5 text-sm" href={`/admin/notices/new?category=${id}`}>＋ New notice</Link>}>
      <p className="mb-3 text-sm text-hint">Notices shown on this category page (and its subcategories). Banners for the homepage are managed under Notices & Banners.</p>
      <Async r={list}>{(d) => (
        <div className="space-y-2">
          {d.items.map((n: any) => (
            <div key={n.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-line p-2">
              <div className="min-w-0 flex-1"><div className="font-medium">{n.title}</div><div className="text-xs text-hint">{n.type} · {n.enabled ? "enabled" : "disabled"}</div></div>
              <Link href={`/admin/notices/${n.id}`} className="btn-ghost !px-3 !py-1.5 text-sm">Edit</Link>
            </div>
          ))}
          {!d.items.length && <p className="text-sm text-hint">No notices target this category.</p>}
        </div>
      )}</Async>
    </Card>
  );
}
