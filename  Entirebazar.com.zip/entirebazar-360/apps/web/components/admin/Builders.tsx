"use client";
import { useEffect, useState } from "react";
import { Area, Btn, Card, CategoryPicker, Check, DateIn, F, FaqEditor, ImageField, NumIn, Pill, ProductPicker, Sel, TextIn, adm, ask, move, run, useAdmin } from "./kit";

/* =====================================================================
 * Custom Button Builder: reusable for category, section, product and notice owners
 * ===================================================================== */
export type Owner = { categoryId?: string; sectionId?: string; productId?: string; noticeId?: string };
const ownerQuery = (o: Owner) => Object.entries(o).filter(([, v]) => v).map(([k, v]) => `${k}=${v}`).join("&");

const blankButton = (o: Owner) => ({ ...o, label: "", icon: "", style: "PRIMARY", size: "MD", placement: "INLINE", action: "OPEN_WALLET", target: {}, confirmTitle: "", confirmMessage: "", visibility: { audience: "ALL" }, enabled: true });

export function ButtonBuilder({ owner, title = "Buttons", note }: { owner: Owner; title?: string; note?: string }) {
  const q = ownerQuery(owner);
  const list = useAdmin<any[]>(`/buttons?${q}`);
  const meta = useAdmin<any>("/cms/meta");
  const [edit, setEdit] = useState<any | null>(null);
  const items = list.data ?? [];

  async function save() {
    const b = edit;
    const body = { ...owner, ...b, icon: b.icon || null, confirmTitle: b.confirmTitle || null, confirmMessage: b.confirmMessage || null };
    delete body.id; delete body.createdAt; delete body.updatedAt;
    const r = await run(() => (b.id ? adm(`/buttons/${b.id}`, body, "PUT") : adm("/buttons", body)), "Button saved");
    if (r) { setEdit(null); list.reload(); }
  }
  async function reorder(i: number, dir: -1 | 1) {
    const ids = move(items, i, dir).map((b) => b.id);
    await run(() => adm("/buttons/reorder", { ids }));
    list.reload();
  }

  return (
    <Card title={title} actions={<Btn small onClick={() => setEdit(blankButton(owner))}>＋ Add button</Btn>}>
      {note && <p className="mb-3 text-sm text-hint">{note}</p>}
      {!items.length && !edit && <p className="text-sm text-hint">No buttons yet.</p>}
      <div className="space-y-2">
        {items.map((b, i) => (
          <div key={b.id} className="flex flex-wrap items-center gap-2 rounded-xl border border-line p-2">
            <div className="min-w-0 flex-1">
              <div className="font-semibold">{b.icon} {b.label} {!b.enabled && <Pill>disabled</Pill>}</div>
              <div className="text-xs text-hint">{b.action} · {b.style}/{b.size} · {b.visibility?.audience ?? "ALL"}</div>
            </div>
            <Btn small disabled={i === 0} onClick={() => void reorder(i, -1)}>↑</Btn>
            <Btn small disabled={i === items.length - 1} onClick={() => void reorder(i, 1)}>↓</Btn>
            <Btn small onClick={async () => { await run(() => adm(`/buttons/${b.id}`, { ...b, enabled: !b.enabled }, "PUT")); list.reload(); }}>{b.enabled ? "Disable" : "Enable"}</Btn>
            <Btn small onClick={() => setEdit({ ...b, icon: b.icon ?? "", confirmTitle: b.confirmTitle ?? "", confirmMessage: b.confirmMessage ?? "" })}>Edit</Btn>
            <Btn small onClick={async () => { await run(() => adm(`/buttons/${b.id}/duplicate`, {}), "Duplicated (disabled)"); list.reload(); }}>Duplicate</Btn>
            <Btn small kind="danger" onClick={async () => { if (await ask(`Delete button "${b.label}"?`)) { await run(() => adm(`/buttons/${b.id}`, undefined, "DELETE"), "Deleted"); list.reload(); } }}>Delete</Btn>
          </div>
        ))}
      </div>

      {edit && (
        <div className="mt-4 space-y-3 rounded-xl border border-brand/40 p-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <F label="Button text"><TextIn value={edit.label} maxLength={40} onChange={(v) => setEdit({ ...edit, label: v })} /></F>
            <F label="Icon (emoji, optional)"><TextIn value={edit.icon} maxLength={8} onChange={(v) => setEdit({ ...edit, icon: v })} /></F>
            <F label="Style"><Sel value={edit.style} onChange={(v) => setEdit({ ...edit, style: v })} options={meta.data?.buttons.styles ?? ["PRIMARY"]} /></F>
            <F label="Size"><Sel value={edit.size} onChange={(v) => setEdit({ ...edit, size: v })} options={meta.data?.buttons.sizes ?? ["MD"]} /></F>
            <F label="Position" hint="TOP/BOTTOM/STICKY apply to category pages; INLINE inside sections, cards and notices."><Sel value={edit.placement} onChange={(v) => setEdit({ ...edit, placement: v })} options={meta.data?.buttons.placements ?? ["INLINE"]} /></F>
            <F label="Action">
              <Sel value={edit.action} onChange={(v) => setEdit({ ...edit, action: v, target: {} })} options={(meta.data?.buttons.actions ?? []).map((a: any) => ({ value: a.value, label: a.label }))} />
            </F>
          </div>
          <TargetEditor action={edit.action} target={edit.target} onChange={(t) => setEdit({ ...edit, target: t })} />
          <div className="grid gap-3 sm:grid-cols-2">
            <F label="Confirmation title (optional)"><TextIn value={edit.confirmTitle} maxLength={80} onChange={(v) => setEdit({ ...edit, confirmTitle: v })} /></F>
            <F label="Confirmation message (shows a dialog first)"><TextIn value={edit.confirmMessage} maxLength={300} onChange={(v) => setEdit({ ...edit, confirmMessage: v })} /></F>
            <F label="Show to" hint="Evaluated on the server for each customer.">
              <Sel value={edit.visibility?.audience ?? "ALL"} onChange={(v) => setEdit({ ...edit, visibility: { ...edit.visibility, audience: v } })}
                options={[{ value: "ALL", label: "Everyone" }, { value: "NEW_USERS", label: "New customers (no orders)" }, { value: "RETURNING", label: "Returning customers" }, { value: "LOW_BALANCE", label: "Low wallet balance" }, { value: "HAS_BALANCE", label: "Has wallet balance" }]} />
            </F>
            {["LOW_BALANCE", "HAS_BALANCE"].includes(edit.visibility?.audience) && (
              <F label="Balance threshold"><NumIn value={edit.visibility?.threshold} onChange={(v) => setEdit({ ...edit, visibility: { ...edit.visibility, threshold: v ?? undefined } })} /></F>
            )}
          </div>
          <Check label="Enabled" checked={edit.enabled} onChange={(v) => setEdit({ ...edit, enabled: v })} />
          <p className="text-xs text-hint">Buttons only navigate. Purchases, wallet and orders still require sign-in, balance checks and server-side validation.</p>
          <div className="flex gap-2"><Btn kind="primary" onClick={() => void save()}>Save button</Btn><Btn onClick={() => setEdit(null)}>Cancel</Btn></div>
        </div>
      )}
    </Card>
  );
}

function TargetEditor({ action, target, onChange }: { action: string; target: any; onChange: (t: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...target, [k]: v === "" ? undefined : v });
  const product = useAdmin<any>(action === "START_PURCHASE" && target.productId ? `/products/${target.productId}` : null);
  switch (action) {
    case "OPEN_CATEGORY": return <F label="Category"><CategoryPicker single value={target.categoryId ? [target.categoryId] : []} onChange={(v) => set("categoryId", v[0])} /></F>;
    case "OPEN_PRODUCT": return <F label="Product"><ProductPicker max={1} value={target.productId ? [target.productId] : []} onChange={(v) => set("productId", v[v.length - 1])} /></F>;
    case "START_PURCHASE":
      return (
        <div className="space-y-2">
          <F label="Product" hint="Opens the product page ready to buy. The customer still confirms and pays from their wallet."><ProductPicker max={1} value={target.productId ? [target.productId] : []} onChange={(v) => onChange({ productId: v[v.length - 1] })} /></F>
          {product.data?.variants?.length > 0 && (
            <F label="Variant (optional)"><Sel value={target.variantId ?? ""} onChange={(v) => set("variantId", v)} options={[{ value: "", label: "Customer chooses" }, ...product.data.variants.map((v: any) => ({ value: v.id, label: v.name }))]} /></F>
          )}
        </div>
      );
    case "OPEN_PRODUCT_LIST":
      return (
        <div className="grid gap-3 sm:grid-cols-2">
          <F label="Category (optional)"><CategoryPicker single value={target.categoryId ? [target.categoryId] : []} onChange={(v) => set("categoryId", v[0])} /></F>
          <F label="Sort"><Sel value={target.sort ?? ""} onChange={(v) => set("sort", v)} options={[{ value: "", label: "Default" }, "NEWEST", "POPULAR", "PRICE_ASC", "PRICE_DESC"]} /></F>
          <F label="Search text (optional)"><TextIn value={target.q} maxLength={60} onChange={(v) => set("q", v)} /></F>
          <Check label="Featured only" checked={!!target.featured} onChange={(v) => set("featured", v || undefined)} />
        </div>
      );
    case "OPEN_FAQ": return <F label="Category FAQ (optional)" hint="Leave empty to open the general FAQ."><CategoryPicker single value={target.categoryId ? [target.categoryId] : []} onChange={(v) => set("categoryId", v[0])} /></F>;
    case "OPEN_EXTERNAL": return <F label="HTTPS link" hint="The host must be on the allow-list in Settings → Allowed link hosts, otherwise the server rejects it."><TextIn value={target.url} placeholder="https://example.com/page" maxLength={500} onChange={(v) => set("url", v)} /></F>;
    case "OPEN_TELEGRAM_BOT":
      return (
        <div className="grid gap-3 sm:grid-cols-2">
          <F label="Bot or channel username"><TextIn value={target.username} placeholder="MyBot" maxLength={32} onChange={(v) => set("username", v.replace(/^@/, ""))} /></F>
          <F label="Start parameter (optional)"><TextIn value={target.startParam} maxLength={64} onChange={(v) => set("startParam", v)} /></F>
        </div>
      );
    default: return <p className="text-sm text-hint">No extra settings for this action.</p>;
  }
}

/* =====================================================================
 * Category Page Builder: sections
 * ===================================================================== */
const SECTION_BUTTONS = new Set(["BUTTON_GROUP", "PROMO_BANNER", "NOTICE"]);

export function SectionBuilder({ categoryId, sections, reload }: { categoryId: string; sections: any[]; reload: () => void }) {
  const meta = useAdmin<any>("/cms/meta");
  const [open, setOpen] = useState<string | null>(null);
  const [adding, setAdding] = useState(false);

  async function add(type: string) {
    const def = meta.data.sections.find((s: any) => s.type === type);
    const r = await run(() => adm(`/categories/${categoryId}/sections`, { type, title: null, enabled: true, config: def.defaults }), "Section added");
    setAdding(false);
    if (r) { reload(); setOpen(r.id); }
  }
  async function reorder(i: number, dir: -1 | 1) {
    await run(() => adm(`/categories/${categoryId}/sections/reorder`, { ids: move(sections, i, dir).map((s) => s.id) }));
    reload();
  }
  const label = (t: string) => meta.data?.sections.find((s: any) => s.type === t)?.label ?? t;

  return (
    <Card title="Page sections" actions={<Btn small kind="primary" onClick={() => setAdding(!adding)}>＋ Add Section</Btn>}>
      {adding && meta.data && (
        <div className="mb-4 grid grid-cols-2 gap-2 sm:grid-cols-3">
          {meta.data.sections.map((s: any) => <button key={s.type} className="rounded-xl border border-line p-3 text-left text-sm font-medium active:opacity-70" onClick={() => void add(s.type)}>{s.label}</button>)}
        </div>
      )}
      {!sections.length && <p className="text-sm text-hint">No sections yet. Without sections the page shows the default product list.</p>}
      <div className="space-y-2">
        {sections.map((s, i) => (
          <div key={s.id} className="rounded-xl border border-line">
            <div className="flex flex-wrap items-center gap-2 p-2">
              <button className="min-w-0 flex-1 text-left" onClick={() => setOpen(open === s.id ? null : s.id)}>
                <div className="font-semibold">{label(s.type)}{s.title ? ` · ${s.title}` : ""}</div>
                <div className="text-xs text-hint">{!s.enabled ? "Disabled" : "Enabled"}{(s.startsAt || s.endsAt) ? " · scheduled" : ""}</div>
              </button>
              <Btn small disabled={i === 0} onClick={() => void reorder(i, -1)}>↑</Btn>
              <Btn small disabled={i === sections.length - 1} onClick={() => void reorder(i, 1)}>↓</Btn>
              <Btn small onClick={async () => { await run(() => adm(`/sections/${s.id}`, { enabled: !s.enabled }, "PUT")); reload(); }}>{s.enabled ? "Disable" : "Enable"}</Btn>
              <Btn small onClick={async () => { await run(() => adm(`/sections/${s.id}/duplicate`, {}), "Duplicated (disabled)"); reload(); }}>Duplicate</Btn>
              <Btn small kind="danger" onClick={async () => { if (await ask("Remove this section?")) { await run(() => adm(`/sections/${s.id}`, undefined, "DELETE"), "Section removed"); reload(); } }}>Remove</Btn>
            </div>
            {open === s.id && <SectionEditor s={s} onSaved={reload} />}
          </div>
        ))}
      </div>
    </Card>
  );
}

function SectionEditor({ s, onSaved }: { s: any; onSaved: () => void }) {
  const [f, setF] = useState({ title: s.title ?? "", startsAt: s.startsAt as string | null, endsAt: s.endsAt as string | null, config: s.config as any });
  useEffect(() => setF({ title: s.title ?? "", startsAt: s.startsAt, endsAt: s.endsAt, config: s.config }), [s]);
  async function save() {
    const r = await run(() => adm(`/sections/${s.id}`, { title: f.title || null, startsAt: f.startsAt, endsAt: f.endsAt, config: f.config }, "PUT"), "Section saved");
    if (r) onSaved();
  }
  return (
    <div className="space-y-3 border-t border-line p-3">
      <F label="Heading shown above the section (optional)"><TextIn value={f.title} maxLength={120} onChange={(v) => setF({ ...f, title: v })} /></F>
      <ConfigForm type={s.type} config={f.config} onChange={(config) => setF({ ...f, config })} />
      <div className="grid gap-3 sm:grid-cols-2">
        <F label="Show from (optional)"><DateIn value={f.startsAt} onChange={(v) => setF({ ...f, startsAt: v })} /></F>
        <F label="Hide after (optional)"><DateIn value={f.endsAt} onChange={(v) => setF({ ...f, endsAt: v })} /></F>
      </div>
      <Btn kind="primary" onClick={() => void save()}>Save section</Btn>
      {SECTION_BUTTONS.has(s.type) && <ButtonBuilder owner={{ sectionId: s.id }} title="Buttons in this section" />}
    </div>
  );
}

function ConfigForm({ type, config: c, onChange }: { type: string; config: any; onChange: (c: any) => void }) {
  const set = (k: string, v: any) => onChange({ ...c, [k]: v });
  const text = (k: string, label: string, max = 200, area = false, hint?: string) => (
    <F label={label} hint={hint}>{area ? <Area value={c[k]} rows={4} maxLength={max} onChange={(v) => set(k, v)} /> : <TextIn value={c[k]} maxLength={max} onChange={(v) => set(k, v)} />}</F>
  );
  const sel = (k: string, label: string, options: string[]) => <F label={label}><Sel value={c[k] ?? options[0]} onChange={(v) => set(k, v)} options={options} /></F>;
  switch (type) {
    case "PRODUCT_GRID":
      return (<div className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">
          {sel("source", "Products from", ["CATEGORY", "SUBTREE", "MANUAL"])}{sel("layout", "Layout", ["GRID_2", "GRID_3", "LIST", "CAROUSEL"])}
          {sel("sort", "Sort", ["MANUAL", "NEWEST", "POPULAR", "PRICE_ASC", "PRICE_DESC"])}
          <F label="How many"><NumIn value={c.limit} min={1} max={48} onChange={(v) => set("limit", v ?? 12)} /></F>
        </div>
        {c.source === "MANUAL" && <F label="Choose products"><ProductPicker value={c.productIds ?? []} onChange={(v) => set("productIds", v)} /></F>}
        <p className="text-xs text-hint">CATEGORY = this category only, SUBTREE = including subcategories, MANUAL = hand-picked. Manual sort follows the product order set on the Products tab.</p>
      </div>);
    case "FEATURED_PRODUCTS":
      return (<div className="space-y-3">
        <div className="grid gap-3 sm:grid-cols-2">{sel("source", "Products from", ["FLAGGED", "MANUAL"])}{sel("layout", "Layout", ["CAROUSEL", "GRID_2"])}<F label="How many"><NumIn value={c.limit} min={1} max={24} onChange={(v) => set("limit", v ?? 6)} /></F></div>
        {c.source === "MANUAL" ? <F label="Choose products"><ProductPicker value={c.productIds ?? []} onChange={(v) => set("productIds", v)} /></F> : <p className="text-xs text-hint">FLAGGED shows products marked “Featured” in this category and its subcategories.</p>}
      </div>);
    case "PROMO_BANNER":
      return (<div className="space-y-3">{text("heading", "Heading", 120)}{text("text", "Text", 500, true)}<ImageField label="Banner image" value={c.imageUrl} onChange={(v) => set("imageUrl", v)} />{sel("tone", "Colour", ["BRAND", "SUCCESS", "WARNING", "DARK"])}</div>);
    case "NOTICE":
      return (<div className="space-y-3">{text("heading", "Heading", 120)}{text("text", "Message", 1000, true)}<div className="grid gap-3 sm:grid-cols-2"><F label="Icon (emoji)"><TextIn value={c.icon} maxLength={8} onChange={(v) => set("icon", v || null)} /></F>{sel("tone", "Type", ["INFO", "PROMO", "WARNING", "MAINTENANCE"])}</div></div>);
    case "RICH_TEXT":
      return (<div className="space-y-3">{text("text", "Text", 5000, true, "Plain text. Use a blank line for a new paragraph, “- ” for bullets and **bold**. HTML is not supported.")}{sel("align", "Alignment", ["LEFT", "CENTER"])}</div>);
    case "IMAGE":
      return (<div className="space-y-3"><ImageField value={c.imageUrl} onChange={(v) => set("imageUrl", v)} />{text("alt", "Alt text (accessibility)", 120)}{text("caption", "Caption", 200)}<div className="grid gap-3 sm:grid-cols-2">{sel("fit", "Fit", ["COVER", "CONTAIN"])}{sel("aspect", "Shape", ["16_9", "4_3", "1_1"])}</div></div>);
    case "BUTTON_GROUP":
      return (<div>{sel("layout", "Layout", ["ROW", "STACK", "GRID"])}<p className="mt-2 text-xs text-hint">Add the buttons below, after saving.</p></div>);
    case "CATEGORY_GRID":
      return (<div className="space-y-3"><div className="grid gap-3 sm:grid-cols-2">{sel("source", "Categories", ["CHILDREN", "MANUAL", "FEATURED"])}<F label="Columns"><Sel value={String(c.columns ?? 2)} onChange={(v) => set("columns", Number(v))} options={["2", "3"]} /></F></div>
        {c.source === "MANUAL" && <F label="Choose categories"><CategoryPicker value={c.categoryIds ?? []} onChange={(v) => set("categoryIds", v)} /></F>}
        <Check label="Show images" checked={c.showImages !== false} onChange={(v) => set("showImages", v)} /></div>);
    case "FAQ":
      return (<div className="space-y-3"><Check label="Also include this category's FAQ (FAQ & Support tab)" checked={!!c.useCategoryFaq} onChange={(v) => set("useCategoryFaq", v)} /><FaqEditor items={c.items ?? []} onChange={(v) => set("items", v)} /></div>);
    case "HOW_IT_WORKS":
      return (
        <div className="space-y-3">
          {(c.steps ?? []).map((st: any, i: number) => (
            <div key={i} className="rounded-xl border border-line p-3">
              <div className="grid gap-2 sm:grid-cols-[1fr_5rem]"><F label={`Step ${i + 1} title`}><TextIn value={st.title} maxLength={80} onChange={(v) => set("steps", c.steps.map((x: any, j: number) => (j === i ? { ...x, title: v } : x)))} /></F><F label="Icon"><TextIn value={st.icon} maxLength={8} onChange={(v) => set("steps", c.steps.map((x: any, j: number) => (j === i ? { ...x, icon: v || null } : x)))} /></F></div>
              <F label="Details" className="mt-2"><TextIn value={st.text} maxLength={300} onChange={(v) => set("steps", c.steps.map((x: any, j: number) => (j === i ? { ...x, text: v } : x)))} /></F>
              <div className="mt-2 flex gap-2"><Btn small disabled={i === 0} onClick={() => set("steps", move(c.steps, i, -1))}>↑</Btn><Btn small disabled={i === c.steps.length - 1} onClick={() => set("steps", move(c.steps, i, 1))}>↓</Btn><Btn small kind="danger" disabled={c.steps.length <= 1} onClick={() => set("steps", c.steps.filter((_: any, j: number) => j !== i))}>Remove</Btn></div>
            </div>
          ))}
          <Btn small disabled={(c.steps ?? []).length >= 8} onClick={() => set("steps", [...(c.steps ?? []), { title: "", text: "", icon: null }])}>＋ Add step</Btn>
        </div>
      );
    case "SUPPORT_INFO":
      return (<div className="space-y-3">{text("text", "Message (optional)", 1000, true)}<Check label="Show the shop's contact details (Settings → Contact)" checked={c.useGlobalContact !== false} onChange={(v) => set("useGlobalContact", v)} /></div>);
    case "TERMS":
      return (<div className="space-y-3">{text("text", "Terms and conditions", 8000, true)}<Check label="Collapsed by default" checked={c.collapsed !== false} onChange={(v) => set("collapsed", v)} /></div>);
    case "COUNTDOWN":
      return (<div className="space-y-3">{text("label", "Label", 120)}<F label="Ends at"><DateIn value={c.endsAt} onChange={(v) => set("endsAt", v)} /></F>{text("expiredMessage", "Message after it ends (optional)", 200)}<Check label="Hide the section once it has ended" checked={!!c.hideWhenExpired} onChange={(v) => set("hideWhenExpired", v)} /></div>);
    case "EMPTY_STATE":
      return (<div className="space-y-3"><F label="Icon (emoji)"><TextIn value={c.icon} maxLength={8} onChange={(v) => set("icon", v || null)} /></F>{text("heading", "Heading", 120)}{text("text", "Text", 300)}</div>);
    default: return <p className="text-sm text-red-600">Unknown section type.</p>;
  }
}
