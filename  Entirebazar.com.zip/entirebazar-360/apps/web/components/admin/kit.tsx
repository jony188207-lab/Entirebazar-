"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { ApiError, adminUpload, api, assetUrl, fieldErrors, useApi } from "@/lib/api";
import { confirmAsk } from "@/components/blocks";

/* ---------------- data helpers ---------------- */
export const adm = <T = any,>(path: string, body?: unknown, method?: string) => api<T>(path, { admin: true, body, method });
export const useAdmin = <T = any,>(path: string | null) => useApi<T>(path, true);
export const ask = confirmAsk;

/* ---------------- toasts ---------------- */
type Toast = { id: number; msg: string; kind: "ok" | "err" };
let toasts: Toast[] = [];
const subs = new Set<() => void>();
let seq = 0;
export function toast(msg: string, kind: "ok" | "err" = "ok") {
  const t = { id: ++seq, msg, kind };
  toasts = [...toasts, t];
  subs.forEach((f) => f());
  setTimeout(() => { toasts = toasts.filter((x) => x.id !== t.id); subs.forEach((f) => f()); }, kind === "err" ? 7000 : 3000);
}
export function Toaster() {
  const [, tick] = useState(0);
  useEffect(() => { const f = () => tick((n) => n + 1); subs.add(f); return () => void subs.delete(f); }, []);
  return (
    <div className="pointer-events-none fixed inset-x-0 top-2 z-50 mx-auto flex max-w-md flex-col gap-2 px-3">
      {toasts.map((t) => (
        <div key={t.id} role="status" className={`pointer-events-auto rounded-xl px-3 py-2 text-sm shadow-lg ${t.kind === "ok" ? "bg-emerald-600 text-white" : "bg-red-600 text-white"}`}>{t.msg}</div>
      ))}
    </div>
  );
}

/** Runs an admin action: shows server validation errors clearly, returns undefined on failure. */
export async function run<T>(fn: () => Promise<T>, okMsg?: string): Promise<T | undefined> {
  try {
    const r = await fn();
    if (okMsg) toast(okMsg);
    return r;
  } catch (e: any) {
    const extra = fieldErrors(e);
    toast(extra.length ? `${e.message}: ${extra.slice(0, 3).join("; ")}` : e.message ?? "Something went wrong", "err");
    return undefined;
  }
}

/* ---------------- dates ---------------- */
export const toLocal = (iso?: string | null) => {
  if (!iso) return "";
  const d = new Date(iso);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
};
export const fromLocal = (s?: string | null) => (s ? new Date(s).toISOString() : null);

/* ---------------- form primitives ---------------- */
export function F({ label, hint, children, className = "" }: { label: string; hint?: string; children: React.ReactNode; className?: string }) {
  return (
    <label className={`block ${className}`}>
      <span className="mb-1 block text-sm font-medium">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-hint">{hint}</span>}
    </label>
  );
}
export const TextIn = ({ value, onChange, ...r }: { value: any; onChange: (v: string) => void } & Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value">) =>
  <input className="input" value={value ?? ""} onChange={(e) => onChange(e.target.value)} {...r} />;
export const Area = ({ value, onChange, rows = 3, ...r }: { value: any; onChange: (v: string) => void; rows?: number } & Omit<React.TextareaHTMLAttributes<HTMLTextAreaElement>, "onChange" | "value">) =>
  <textarea className="input" rows={rows} value={value ?? ""} onChange={(e) => onChange(e.target.value)} {...r} />;
export const NumIn = ({ value, onChange, ...r }: { value: any; onChange: (v: number | null) => void } & Omit<React.InputHTMLAttributes<HTMLInputElement>, "onChange" | "value">) =>
  <input className="input" type="number" inputMode="decimal" value={value ?? ""} onChange={(e) => onChange(e.target.value === "" ? null : Number(e.target.value))} {...r} />;
export const DateIn = ({ value, onChange }: { value?: string | null; onChange: (iso: string | null) => void }) =>
  <input className="input" type="datetime-local" value={toLocal(value)} onChange={(e) => onChange(fromLocal(e.target.value))} />;
export function Sel<T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: (T | { value: T; label: string })[] }) {
  return (
    <select className="input" value={value} onChange={(e) => onChange(e.target.value as T)}>
      {options.map((o) => typeof o === "string" ? <option key={o} value={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
}
export function Check({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <label className="flex items-start gap-2 py-1">
      <input type="checkbox" className="mt-1 h-4 w-4" checked={!!checked} onChange={(e) => onChange(e.target.checked)} />
      <span><span className="text-sm font-medium">{label}</span>{hint && <span className="block text-xs text-hint">{hint}</span>}</span>
    </label>
  );
}

export function ImageField({ value, onChange, label = "Image" }: { value?: string | null; onChange: (v: string | null) => void; label?: string }) {
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLInputElement>(null);
  async function pick(file?: File | null) {
    if (!file) return;
    setBusy(true);
    const fd = new FormData();
    fd.append("file", file);
    const r = await run(() => adminUpload(fd));
    setBusy(false);
    if (r) onChange(r.url);
    if (ref.current) ref.current.value = "";
  }
  return (
    <div>
      <span className="mb-1 block text-sm font-medium">{label}</span>
      <div className="flex items-center gap-3">
        <div className="flex h-16 w-24 items-center justify-center overflow-hidden rounded-lg bg-line text-xs text-hint">
          {value ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={assetUrl(value)!} alt="" className="h-full w-full object-cover" /> : "No image"}
        </div>
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn-ghost !px-3 !py-1.5 text-sm" disabled={busy} onClick={() => ref.current?.click()}>{busy ? "Uploading…" : value ? "Replace" : "Upload"}</button>
          {value && <button type="button" className="btn-ghost !px-3 !py-1.5 text-sm" onClick={() => onChange(null)}>Remove</button>}
        </div>
        <input ref={ref} type="file" accept="image/png,image/jpeg,image/webp" className="hidden" onChange={(e) => void pick(e.target.files?.[0])} />
      </div>
      <p className="mt-1 text-xs text-hint">PNG, JPEG or WebP, up to 2 MB. SVG is not accepted.</p>
    </div>
  );
}

/* ---------------- layout primitives ---------------- */
export const Card = ({ title, actions, children, className = "" }: { title?: React.ReactNode; actions?: React.ReactNode; children: React.ReactNode; className?: string }) => (
  <section className={`card ${className}`}>
    {(title || actions) && <div className="mb-3 flex flex-wrap items-center justify-between gap-2">{title && <h3 className="font-bold">{title}</h3>}<div className="flex flex-wrap gap-2">{actions}</div></div>}
    {children}
  </section>
);
export const Btn = ({ kind = "ghost", small, ...p }: { kind?: "primary" | "ghost" | "danger"; small?: boolean } & React.ButtonHTMLAttributes<HTMLButtonElement>) => (
  <button type="button" {...p} className={`${kind === "primary" ? "btn" : kind === "danger" ? "rounded-xl border border-red-500/50 px-4 py-3 font-medium text-red-600 active:opacity-80 disabled:opacity-50" : "btn-ghost"} ${small ? "!px-3 !py-1.5 text-sm" : ""} ${p.className ?? ""}`} />
);
export const Pill = ({ children, tone = "gray" }: { children: React.ReactNode; tone?: "gray" | "green" | "amber" | "red" | "blue" }) => (
  <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${{ gray: "bg-gray-500/15", green: "bg-emerald-500/15 text-emerald-700", amber: "bg-amber-500/15 text-amber-700", red: "bg-red-500/15 text-red-700", blue: "bg-blue-500/15 text-blue-700" }[tone]}`}>{children}</span>
);
export const statusTone = (s: string) => (["PUBLISHED", "SUCCESSFUL", "DELIVERED", "ACTIVE", "CONNECTED", "ANSWERED"].includes(s) ? "green" : ["DRAFT", "PENDING", "PROCESSING", "OPEN", "UNTESTED", "RESTRICTED"].includes(s) ? "amber" : ["FAILED", "REJECTED", "BANNED", "TEST_FAILED", "CANCELLED"].includes(s) ? "red" : "gray") as any;

export function Tabs({ tabs, value, onChange }: { tabs: { id: string; label: string }[]; value: string; onChange: (id: string) => void }) {
  return (
    <div role="tablist" className="-mx-4 mb-4 flex gap-1 overflow-x-auto px-4 pb-1">
      {tabs.map((t) => (
        <button key={t.id} role="tab" aria-selected={value === t.id} onClick={() => onChange(t.id)} className={`whitespace-nowrap rounded-full px-3 py-1.5 text-sm ${value === t.id ? "bg-brand text-brandfg" : "bg-card"}`}>{t.label}</button>
      ))}
    </div>
  );
}

export function Pager({ page, pages, onPage, total }: { page: number; pages: number; onPage: (p: number) => void; total?: number }) {
  if (pages <= 1 && !total) return null;
  return (
    <div className="mt-3 flex items-center justify-center gap-3 text-sm">
      <Btn small disabled={page <= 1} onClick={() => onPage(page - 1)}>‹ Prev</Btn>
      <span>{page} / {pages}{total !== undefined ? ` · ${total} total` : ""}</span>
      <Btn small disabled={page >= pages} onClick={() => onPage(page + 1)}>Next ›</Btn>
    </div>
  );
}

export function SearchBox({ value, onChange, placeholder = "Search…" }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  const [v, setV] = useState(value);
  useEffect(() => { const t = setTimeout(() => onChange(v), 350); return () => clearTimeout(t); }, [v]); // eslint-disable-line react-hooks/exhaustive-deps
  return <input className="input" placeholder={placeholder} value={v} onChange={(e) => setV(e.target.value)} />;
}

export function Async({ r, children }: { r: { data: any; error: string | null; loading: boolean; reload: () => void }; children: (d: any) => React.ReactNode }) {
  if (r.loading && !r.data) return <div className="py-8 text-center text-hint">Loading…</div>;
  if (r.error) return <div className="card text-red-600">{r.error} <button className="ml-2 underline" onClick={r.reload}>Retry</button></div>;
  return <>{children(r.data)}</>;
}

/** Up/down/remove controls for ordered lists. */
export function move<T>(arr: T[], i: number, dir: -1 | 1): T[] {
  const j = i + dir;
  if (j < 0 || j >= arr.length) return arr;
  const c = [...arr];
  [c[i], c[j]] = [c[j], c[i]];
  return c;
}

/** FAQ / generic list editor. */
export function FaqEditor({ items, onChange, max = 50 }: { items: { q: string; a: string }[]; onChange: (v: { q: string; a: string }[]) => void; max?: number }) {
  return (
    <div className="space-y-3">
      {items.map((it, i) => (
        <div key={i} className="rounded-xl border border-line p-3">
          <F label={`Question ${i + 1}`}><TextIn value={it.q} maxLength={200} onChange={(v) => onChange(items.map((x, j) => (j === i ? { ...x, q: v } : x)))} /></F>
          <F label="Answer" className="mt-2"><Area value={it.a} rows={2} maxLength={1500} onChange={(v) => onChange(items.map((x, j) => (j === i ? { ...x, a: v } : x)))} /></F>
          <div className="mt-2 flex gap-2">
            <Btn small disabled={i === 0} onClick={() => onChange(move(items, i, -1))}>↑</Btn>
            <Btn small disabled={i === items.length - 1} onClick={() => onChange(move(items, i, 1))}>↓</Btn>
            <Btn small kind="danger" onClick={() => onChange(items.filter((_, j) => j !== i))}>Remove</Btn>
          </div>
        </div>
      ))}
      <Btn small disabled={items.length >= max} onClick={() => onChange([...items, { q: "", a: "" }])}>＋ Add question</Btn>
    </div>
  );
}

/** Pick products by searching; shows names for the selected ids. */
export function ProductPicker({ value, onChange, max = 48 }: { value: string[]; onChange: (ids: string[]) => void; max?: number }) {
  const [q, setQ] = useState("");
  const sel = useAdmin<any>(value.length ? `/products?ids=${value.join(",")}&limit=100` : null);
  const res = useAdmin<any>(q.length >= 2 ? `/products?q=${encodeURIComponent(q)}&limit=8` : null);
  const names = new Map<string, string>((sel.data?.items ?? []).map((p: any) => [p.id, p.name]));
  return (
    <div>
      <div className="mb-2 flex flex-wrap gap-2">
        {value.map((id) => (
          <span key={id} className="inline-flex items-center gap-1 rounded-full bg-brand/10 px-2 py-1 text-sm">
            {names.get(id) ?? "…"}
            <button aria-label="Remove" onClick={() => onChange(value.filter((x) => x !== id))}>×</button>
          </span>
        ))}
        {!value.length && <span className="text-sm text-hint">No products selected.</span>}
      </div>
      <input className="input" placeholder="Search products to add…" value={q} onChange={(e) => setQ(e.target.value)} />
      {res.data?.items?.length > 0 && (
        <div className="mt-1 overflow-hidden rounded-xl border border-line">
          {res.data.items.filter((p: any) => !value.includes(p.id)).map((p: any) => (
            <button key={p.id} disabled={value.length >= max} className="flex w-full items-center justify-between border-b border-line px-3 py-2 text-left text-sm last:border-0" onClick={() => { onChange([...value, p.id]); setQ(""); }}>
              <span>{p.name}</span><Pill tone={statusTone(p.status)}>{p.status}</Pill>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

export function CategoryPicker({ value, onChange, exclude = [], single = false }: { value: string[]; onChange: (ids: string[]) => void; exclude?: string[]; single?: boolean }) {
  const cats = useAdmin<any[]>("/categories");
  const list = (cats.data ?? []).filter((c) => !exclude.includes(c.id));
  const byId = new Map((cats.data ?? []).map((c) => [c.id, c]));
  const label = (c: any) => { const parts = [c.name]; let p = c.parentId ? byId.get(c.parentId) : null; let n = 0; while (p && n++ < 5) { parts.unshift(p.name); p = p.parentId ? byId.get(p.parentId) : null; } return parts.join(" › "); };
  if (single) {
    return (
      <select className="input" value={value[0] ?? ""} onChange={(e) => onChange(e.target.value ? [e.target.value] : [])}>
        <option value="">— none —</option>
        {list.map((c) => <option key={c.id} value={c.id}>{label(c)}</option>)}
      </select>
    );
  }
  return (
    <div className="max-h-48 overflow-y-auto rounded-xl border border-line p-2">
      {list.map((c) => (
        <Check key={c.id} label={label(c)} checked={value.includes(c.id)} onChange={(v) => onChange(v ? [...value, c.id] : value.filter((x) => x !== c.id))} />
      ))}
      {!list.length && <span className="text-sm text-hint">No categories yet.</span>}
    </div>
  );
}

export function useDirty<T>(initial: T | null) {
  const [form, setForm] = useState<T | null>(initial);
  const base = useRef<string>(initial ? JSON.stringify(initial) : "");
  const reset = useCallback((v: T) => { base.current = JSON.stringify(v); setForm(v); }, []);
  const dirty = !!form && JSON.stringify(form) !== base.current;
  return { form, setForm, reset, dirty };
}

export { ApiError };
