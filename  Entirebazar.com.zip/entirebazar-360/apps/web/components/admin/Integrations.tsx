"use client";
import { useState } from "react";
import { when } from "@/lib/api";
import { Async, Btn, Card, Check, F, Pill, Sel, TextIn, adm, ask, run, useAdmin } from "./kit";

const TONE: Record<string, any> = { CONNECTED: "green", UNTESTED: "amber", TEST_FAILED: "red", DISABLED: "gray", MISSING_CREDENTIALS: "amber", MODE_MISMATCH: "amber", NOT_IMPLEMENTED: "gray" };

export function Integrations() {
  const list = useAdmin<any[]>("/integrations");
  const [open, setOpen] = useState<string | null>(null);
  return (
    <div className="space-y-3">
      <h1 className="text-2xl font-bold">API integrations</h1>
      <Card><p className="text-sm text-hint">An integration is shown as <b>Connected</b> only when its adapter is implemented, credentials are saved, it is enabled in the right mode, <b>and</b> a server-side connection test succeeded. Saving a form never counts as proof. Secrets are encrypted on the server and never shown again; you can only replace them. Adding a provider that has no adapter needs backend development (see <code>docs/INTEGRATIONS.md</code>); a URL and key alone are not enough.</p></Card>
      <Async r={list}>{(items) => items.map((i: any) => (
        <Card key={i.code}>
          <button className="flex w-full flex-wrap items-center justify-between gap-2 text-left" onClick={() => setOpen(open === i.code ? null : i.code)}>
            <span><span className="font-bold">{i.name}</span> <span className="text-xs text-hint">{i.kind === "payment" ? "payment" : "service"}</span></span>
            <span className="flex flex-wrap items-center gap-1.5">{i.requiresApproval && <Pill tone="amber">Needs provider approval</Pill>}{!i.implemented && <Pill>Adapter not built</Pill>}<Pill tone={TONE[i.status.state]}>{i.status.label}</Pill></span>
          </button>
          {open === i.code && <IntegrationDetail code={i.code} onChange={list.reload} />}
        </Card>
      ))}</Async>
    </div>
  );
}

function IntegrationDetail({ code, onChange }: { code: string; onChange: () => void }) {
  const r = useAdmin<any>(`/integrations/${code}`);
  const [settings, setSettings] = useState<Record<string, string> | null>(null);
  const [mode, setMode] = useState<"sandbox" | "production" | null>(null);
  const [secretMode, setSecretMode] = useState<"sandbox" | "production">("sandbox");
  const [newSecret, setNewSecret] = useState<{ name: string; value: string } | null>(null);
  const [testing, setTesting] = useState(false);
  const refresh = () => { r.reload(); onChange(); };
  return (
    <div className="mt-4 space-y-4 border-t border-line pt-4">
      <Async r={r}>{(d) => {
        const curMode = mode ?? d.mode;
        const vals = settings ?? Object.fromEntries(d.settings.map((s: any) => [s.key, s.value]));
        return (<>
          <p className="text-sm">{d.summary}</p>
          {!d.implemented && <div className="rounded-xl bg-amber-500/15 p-3 text-sm text-amber-700">There is no working adapter for this integration in the codebase, so it cannot be enabled or tested. Developers: follow the steps below.</div>}
          <details className="rounded-xl border border-line p-3 text-sm" open={!d.implemented}><summary className="cursor-pointer font-semibold">Setup instructions</summary><ol className="mt-2 list-decimal space-y-1 pl-5">{d.instructions.map((s: string, i: number) => <li key={i}>{s}</li>)}</ol></details>

          <div className="grid gap-3 sm:grid-cols-2">
            <F label="Mode" hint={`This server runs in ${d.serverEnvironment} mode. A different mode cannot be enabled here.`}><Sel value={curMode} onChange={(v) => setMode(v)} options={["sandbox", "production"]} /></F>
            <div className="pt-6"><Check label="Enabled" checked={d.enabled} onChange={async (v) => { const x = await run(() => adm(`/integrations/${code}`, { enabled: v, mode: curMode }, "PATCH"), v ? "Enabled" : "Disabled"); if (x) { setMode(null); refresh(); } }} hint={d.implemented ? undefined : "Unavailable: adapter not implemented"} /></div>
          </div>

          {d.settings.length > 0 && (
            <div className="space-y-3">
              <div className="font-semibold">Settings (not secret)</div>
              {d.settings.map((s: any) => <F key={s.key} label={s.label} hint={s.fromEnv ? "Currently provided by a server environment variable." : s.placeholder}><TextIn value={vals[s.key]} onChange={(v) => setSettings({ ...vals, [s.key]: v })} /></F>)}
              <Btn onClick={async () => { const x = await run(() => adm(`/integrations/${code}`, { mode: curMode, enabled: d.enabled, settings: vals }, "PATCH"), "Settings saved"); if (x) { setSettings(null); setMode(null); refresh(); } }}>Save settings</Btn>
            </div>
          )}

          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2"><div className="font-semibold">Credentials</div><Sel value={secretMode} onChange={(v) => setSecretMode(v)} options={["sandbox", "production"]} /></div>
            {d.encryptionKey !== "ok" && <div className="rounded-xl bg-red-500/10 p-3 text-sm text-red-700">SECRETS_ENCRYPTION_KEY is {d.encryptionKey} on the server, so credentials cannot be stored from this panel. Set it, or supply the credentials as environment variables.</div>}
            {d.secrets[secretMode].map((s: any) => {
              const meta = (d as any).secretFields?.find?.((x: any) => x.key === s.name);
              return (
                <div key={s.name} className="flex flex-wrap items-center gap-2 rounded-xl border border-line p-2">
                  <div className="min-w-0 flex-1"><div className="font-mono text-sm">{s.name}</div><div className="text-xs text-hint">{s.set ? <>●●●●●●●● saved ({s.source === "environment" ? "server environment" : "encrypted in database"})</> : "Not set"}{meta?.label ? ` · ${meta.label}` : ""}</div></div>
                  <Btn small onClick={() => setNewSecret({ name: s.name, value: "" })}>{s.set ? "Replace" : "Set"}</Btn>
                  {s.set && s.source === "database" && <Btn small kind="danger" onClick={async () => { if (await ask(`Remove ${s.name} (${secretMode})?`)) { await run(() => adm(`/integrations/${code}/secrets/${s.name}?mode=${secretMode}`, undefined, "DELETE"), "Removed"); refresh(); } }}>Remove</Btn>}
                </div>
              );
            })}
            {newSecret && (
              <div className="space-y-2 rounded-xl border border-brand/40 p-3">
                <F label={`New value for ${newSecret.name} (${secretMode})`} hint="Sent once over HTTPS, encrypted at rest, never displayed again."><input className="input" type="password" autoComplete="off" value={newSecret.value} onChange={(e) => setNewSecret({ ...newSecret, value: e.target.value })} /></F>
                <div className="flex gap-2"><Btn kind="primary" disabled={!newSecret.value} onClick={async () => { const x = await run(() => adm(`/integrations/${code}/secrets/${newSecret.name}`, { mode: secretMode, value: newSecret.value }, "PUT"), "Credential saved. Run a connection test."); setNewSecret(null); if (x) refresh(); }}>Save credential</Btn><Btn onClick={() => setNewSecret(null)}>Cancel</Btn></div>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex flex-wrap items-center gap-2">
              <Btn disabled={!d.implemented || testing} onClick={async () => { setTesting(true); await run(() => adm(`/integrations/${code}/test`, {}), "Test finished"); setTesting(false); refresh(); }}>{testing ? "Testing…" : "Run connection test"}</Btn>
              {d.lastTest && <span className="text-sm"><Pill tone={d.lastTest.ok ? "green" : "red"}>{d.lastTest.ok ? "Passed" : "Failed"}</Pill> <span className="text-hint">{when(d.lastTest.at)} · {d.lastTest.message}</span></span>}
            </div>
            <p className="text-xs text-hint">The test runs on the server with the stored credentials. It only checks communication and never moves money.</p>
          </div>

          <div>
            <div className="mb-1 font-semibold">Recent log (sanitised)</div>
            {d.logs.length ? <div className="max-h-48 overflow-y-auto rounded-xl border border-line p-2 text-xs">{d.logs.map((l: any) => <div key={l.id} className={l.level === "error" ? "text-red-600" : l.level === "warn" ? "text-amber-600" : "text-hint"}>{when(l.createdAt)} · {l.message}</div>)}</div> : <p className="text-sm text-hint">No log entries.</p>}
          </div>
        </>);
      }}</Async>
    </div>
  );
}
