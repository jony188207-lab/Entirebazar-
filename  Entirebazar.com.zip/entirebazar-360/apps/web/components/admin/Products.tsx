"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { money, when } from "@/lib/api";
import { ButtonBuilder } from "./Builders";
import { Area, Async, Btn, Card, CategoryPicker, Check, DateIn, F, FaqEditor, ImageField, NumIn, Pager, Pill, SearchBox, Sel, Tabs, TextIn, adm, ask, run, statusTone, toast, useAdmin, useDirty } from "./kit";

export function ProductList() {
  const router = useRouter();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  const [page, setPage] = useState(1);
  const [low, setLow] = useState(false);
  const list = useAdmin<any>(`/products?page=${page}&limit=20${q ? `&q=${encodeURIComponent(q)}` : ""}${status ? `&status=${status}` : ""}${low ? "&lowStock=true" : ""}`);
  async function create() {
    const r: any = await run(() => adm("/products", { name: "New product", description: "", price: 100, categoryIds: [], deliveryType: "MANUAL", productType: "MANUAL" }), "Draft created");
    if (r) router.push(`/admin/products/${r.product.id}`);
  }
  async function act(p: any, what: string, confirmText?: string) {
    if (confirmText && !(await ask(confirmText))) return;
    const r: any = await run(() => (what === "delete" ? adm(`/products/${p.id}`, undefined, "DELETE") : adm(`/products/${p.id}/${what}`, {})), "Done");
    if (r?.message) toast(r.message);
    if (r?.warnings?.length) toast(r.warnings.join(" "));
    if (what === "duplicate" && r?.id) return router.push(`/admin/products/${r.id}`);
    list.reload();
  }
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2"><h1 className="text-2xl font-bold">Products</h1><Btn kind="primary" small onClick={() => void create()}>＋ New product</Btn></div>
      <div className="grid gap-2 sm:grid-cols-[1fr_10rem_auto]">
        <SearchBox value={q} onChange={(v) => { setQ(v); setPage(1); }} placeholder="Search by name…" />
        <Sel value={status} onChange={(v) => { setStatus(v); setPage(1); }} options={[{ value: "", label: "All (not archived)" }, "DRAFT", "PUBLISHED", "ARCHIVED"]} />
        <Check label="Low stock" checked={low} onChange={(v) => { setLow(v); setPage(1); }} />
      </div>
      <Async r={list}>{(d) => (
        <>
          <div className="space-y-2">
            {d.items.map((p: any) => (
              <div key={p.id} className="card !p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <Link href={`/admin/products/${p.id}`} className="font-semibold">{p.name}</Link>
                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-hint">
                      <Pill tone={statusTone(p.status)}>{p.status}</Pill><span>{money(p.price)}</span><span>{p.productType}</span><span>{p.deliveryType === "TEXT_KEYS" ? `${p.availableKeys} keys left` : p.stock === null ? "unlimited" : `${p.stock} in stock`}</span>
                      {p.variantCount > 0 && <span>{p.variantCount} variants</span>}<span>{p.orderCount} orders</span>
                      {p.categories.map((c: any) => <Pill key={c.categoryId}>{c.category.name}</Pill>)}
                    </div>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    <Link href={`/admin/products/${p.id}`} className="btn-ghost !px-3 !py-1.5 text-sm">Edit</Link>
                    {p.status !== "PUBLISHED" && p.status !== "ARCHIVED" && <Btn small onClick={() => void act(p, "publish")}>Publish</Btn>}
                    {p.status === "PUBLISHED" && <Btn small onClick={() => void act(p, "unpublish", "Unpublish this product?")}>Unpublish</Btn>}
                    <Btn small onClick={() => void act(p, "duplicate")}>Duplicate</Btn>
                    {p.status === "ARCHIVED" ? <Btn small onClick={() => void act(p, "restore")}>Restore</Btn> : <Btn small onClick={() => void act(p, "archive", "Archive this product?")}>Archive</Btn>}
                    <Btn small kind="danger" onClick={() => void act(p, "delete", "Delete this product? If it has orders it is archived instead.")}>Delete</Btn>
                  </div>
                </div>
              </div>
            ))}
            {!d.items.length && <div className="card text-center text-hint">No products found.</div>}
          </div>
          <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
        </>
      )}</Async>
    </div>
  );
}

const toForm = (p: any) => ({
  name: p.name, description: p.description, features: p.features ?? [], imageUrl: p.imageUrl ?? null, price: Number(p.price),
  discountType: p.discountType, discountValue: p.discountValue === null ? null : Number(p.discountValue), discountStartsAt: p.discountStartsAt ?? null, discountEndsAt: p.discountEndsAt ?? null,
  stock: p.stock ?? null, featured: p.featured, productType: p.productType, deliveryType: p.deliveryType, deliveryFileUrl: p.deliveryFileUrl ?? "", deliveryInstructions: p.deliveryInstructions ?? "",
  inputLabel: p.inputLabel ?? "", cardLayout: p.cardLayout, faq: p.faq ?? [], categoryIds: p.categories.map((c: any) => c.categoryId), primaryCategoryId: p.categoryId ?? null,
});
const payload = (f: any) => ({ ...f, deliveryFileUrl: f.deliveryFileUrl || null, deliveryInstructions: f.deliveryInstructions || null, inputLabel: f.inputLabel || null, discountValue: f.discountType === "NONE" ? null : f.discountValue,
  primaryCategoryId: f.categoryIds.includes(f.primaryCategoryId) ? f.primaryCategoryId : null });

const PTABS = ["Details", "Pricing", "Delivery & stock", "Categories", "Variants", "Notices & FAQ", "Orders"].map((l) => ({ id: l, label: l }));

export function ProductEditor({ id }: { id: string }) {
  const r = useAdmin<any>(`/products/${id}`);
  const { form, setForm, reset, dirty } = useDirty<any>(null);
  const [tab, setTab] = useState("Details");
  useEffect(() => { if (r.data && !form) reset(toForm(r.data)); }, [r.data]); // eslint-disable-line react-hooks/exhaustive-deps
  if (r.loading && !r.data) return <div className="py-8 text-center text-hint">Loading…</div>;
  if (r.error || !r.data || !form) return <div className="card text-red-600">{r.error ?? "Not found"}</div>;
  const p = r.data;
  const set = (patch: any) => setForm({ ...form, ...patch });
  async function save() {
    const out: any = await run(() => adm(`/products/${id}`, payload(form), "PUT"), "Saved");
    if (out) { if (out.warnings?.length) toast(out.warnings.join(" ")); reset(form); r.reload(); }
  }
  return (
    <div className="pb-24">
      <div className="mb-3 flex flex-wrap items-center gap-2"><Link href="/admin/products" className="text-sm text-brand">← Products</Link><h1 className="text-xl font-bold">{p.name}</h1><Pill tone={statusTone(p.status)}>{p.status}</Pill></div>
      <Tabs tabs={PTABS} value={tab} onChange={setTab} />
      <div className="space-y-4">
        {tab === "Details" && (
          <Card title="Details">
            <F label="Name"><TextIn value={form.name} maxLength={120} onChange={(v) => set({ name: v })} /></F>
            <F label="Description" className="mt-3" hint="Plain text. Blank line = new paragraph, “- ” = bullet, **bold**."><Area value={form.description} rows={5} maxLength={5000} onChange={(v) => set({ description: v })} /></F>
            <F label="Feature bullets (one per line)" className="mt-3"><Area value={(form.features ?? []).join("\n")} rows={3} onChange={(v) => set({ features: v.split("\n").map((x) => x.trim()).filter(Boolean).slice(0, 20) })} /></F>
            <div className="mt-3"><ImageField value={form.imageUrl} onChange={(v) => set({ imageUrl: v })} /></div>
            <div className="mt-3 grid gap-3 sm:grid-cols-3">
              <F label="Product type"><Sel value={form.productType} onChange={(v) => set({ productType: v, ...(v === "MANUAL" ? { deliveryType: "MANUAL" } : {}) })} options={["DIGITAL", "SUBSCRIPTION", "LICENSE_KEY", "SERVICE_PACKAGE", "DOWNLOADABLE", "MANUAL"]} /></F>
              <F label="Card layout"><Sel value={form.cardLayout} onChange={(v) => set({ cardLayout: v })} options={["DEFAULT", "COMPACT", "WIDE"]} /></F>
              <Check label="Featured" checked={form.featured} onChange={(v) => set({ featured: v })} />
            </div>
          </Card>
        )}
        {tab === "Pricing" && (
          <Card title="Price & discount">
            <div className="grid gap-3 sm:grid-cols-2">
              <F label="Price (৳)" hint="Variants can override this."><NumIn value={form.price} min={0} step="0.01" onChange={(v) => set({ price: v ?? 0 })} /></F>
              <F label="Discount"><Sel value={form.discountType} onChange={(v) => set({ discountType: v })} options={[{ value: "NONE", label: "None" }, { value: "PERCENT", label: "Percent" }, { value: "FIXED", label: "Fixed amount" }]} /></F>
              {form.discountType !== "NONE" && <>
                <F label={form.discountType === "PERCENT" ? "Percent off (max 90)" : "Amount off (৳)"}><NumIn value={form.discountValue} min={0} onChange={(v) => set({ discountValue: v })} /></F>
                <div />
                <F label="Starts (optional)"><DateIn value={form.discountStartsAt} onChange={(v) => set({ discountStartsAt: v })} /></F>
                <F label="Ends (optional)"><DateIn value={form.discountEndsAt} onChange={(v) => set({ discountEndsAt: v })} /></F>
              </>}
            </div>
            <p className="mt-2 text-xs text-hint">Only the best single discount applies (product, category or variant). Checkout recomputes the price on the server.</p>
          </Card>
        )}
        {tab === "Delivery & stock" && (
          <>
            <Card title="Delivery">
              <F label="How is it delivered?">
                <Sel value={form.deliveryType} onChange={(v) => set({ deliveryType: v })} options={[{ value: "TEXT_KEYS", label: "Automatic: keys / codes from stock" }, { value: "FILE_URL", label: "Automatic: download link" }, { value: "MANUAL", label: "Manual: our team fulfils it" }]} />
              </F>
              {form.deliveryType === "FILE_URL" && <F label="Download file or link (HTTPS)" className="mt-3" hint="Upload a PDF/ZIP (stored privately; buyers get a 15-minute link after payment) or paste an HTTPS link."><TextIn value={form.deliveryFileUrl} maxLength={1000} onChange={(v) => set({ deliveryFileUrl: v })} /><input type="file" accept="application/pdf,application/zip" className="mt-2 block text-sm" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; const fd = new FormData(); fd.append("file", f); const r = await run(() => adminUploadFile(fd)); if (r) set({ deliveryFileUrl: r.ref }); e.target.value = ""; }} /></F>}
              {form.deliveryType === "MANUAL" && <p className="mt-2 rounded-lg bg-blue-500/10 p-2 text-sm text-blue-700">Paid orders wait in <b>Processing</b>. Open Orders → Manual queue, enter what the buyer should receive and mark each line delivered.</p>}
              <F label="Ask the buyer for (optional)" className="mt-3" hint="e.g. “Player ID” or “Email”. Required at checkout and shown to your team."><TextIn value={form.inputLabel} maxLength={60} onChange={(v) => set({ inputLabel: v })} /></F>
              <F label="Delivery instructions shown to buyers" className="mt-3"><Area value={form.deliveryInstructions} rows={3} maxLength={2000} onChange={(v) => set({ deliveryInstructions: v })} /></F>
            </Card>
            <Card title="Stock">
              {form.deliveryType === "TEXT_KEYS" ? <KeysPanel p={p} reload={r.reload} /> : (
                <F label="Units available (leave empty for unlimited)"><NumIn value={form.stock} min={0} onChange={(v) => set({ stock: v })} /></F>
              )}
            </Card>
          </>
        )}
        {tab === "Categories" && (
          <Card title="Categories">
            <p className="mb-2 text-sm text-hint">A product can live in several categories. It is visible when at least one of them is live; with none it appears only in the general shop.</p>
            <CategoryPicker value={form.categoryIds} onChange={(v) => set({ categoryIds: v })} />
            {form.categoryIds.length > 1 && <F label="Primary category" className="mt-3"><CategoryPicker single value={form.primaryCategoryId ? [form.primaryCategoryId] : []} onChange={(v) => set({ primaryCategoryId: v[0] ?? null })} /></F>}
          </Card>
        )}
        {tab === "Variants" && <VariantsPanel p={p} reload={r.reload} />}
        {tab === "Notices & FAQ" && (
          <>
            <Card title="Product FAQ"><FaqEditor items={form.faq} onChange={(v) => set({ faq: v })} /></Card>
            <Card title="Product notices" actions={<Link className="btn !px-3 !py-1.5 text-sm" href={`/admin/notices/new?product=${id}`}>＋ New notice</Link>}>
              {p.notices.length ? p.notices.map((n: any) => <div key={n.id} className="flex items-center justify-between border-b border-line py-2 last:border-0"><span>{n.title} {!n.enabled && <Pill>disabled</Pill>}</span><Link className="text-brand" href={`/admin/notices/${n.id}`}>Edit</Link></div>) : <p className="text-sm text-hint">No notices for this product.</p>}
            </Card>
            <ButtonBuilder owner={{ productId: id }} title="Product buttons" note="Extra buttons shown on the product page (e.g. a help link)." />
          </>
        )}
        {tab === "Orders" && <ProductOrders id={id} />}
      </div>

      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card p-3">
        <div className="mx-auto flex max-w-6xl items-center gap-3">
          <span className="flex-1 text-sm text-hint">{dirty ? "You have unsaved changes." : "All changes saved."}</span>
          {dirty && <Btn onClick={() => reset(toForm(p))}>Discard</Btn>}
          <Btn kind="primary" disabled={!dirty} onClick={() => void save()}>Save changes</Btn>
        </div>
      </div>
    </div>
  );
}

function KeysPanel({ p, reload }: { p: any; reload: () => void }) {
  const [text, setText] = useState("");
  const [variantId, setVariantId] = useState(p.variants[0]?.id ?? "");
  const keys = useAdmin<any[]>(`/products/${p.id}/keys?limit=20`);
  const lines = [...new Set(text.split("\n").map((l) => l.trim()).filter(Boolean))];
  async function add() {
    const r: any = await run(() => adm(`/products/${p.id}/keys`, { keys: lines, variantId: p.variants.length ? variantId : undefined }), undefined);
    if (r) { toast(`${r.added} keys added${r.duplicatesIgnored ? `, ${r.duplicatesIgnored} duplicates ignored` : ""}`); setText(""); reload(); keys.reload(); }
  }
  return (
    <div className="space-y-3">
      <div className="text-sm">Unsold keys: {Object.entries(p.keyStock).map(([k, n]) => <Pill key={k} tone="blue">{k === "_product" ? "product" : p.variants.find((v: any) => v.id === k)?.name ?? k}: {String(n)}</Pill>)} {!Object.keys(p.keyStock).length && <b>0</b>} · delivered: {p.usedKeys}</div>
      {p.variants.length > 0 && <F label="Add keys to variant"><Sel value={variantId} onChange={setVariantId} options={p.variants.map((v: any) => ({ value: v.id, label: v.name }))} /></F>}
      <F label="Paste keys, one per line" hint="Stored for delivery only. They are never written to logs and shown masked here."><Area value={text} rows={4} onChange={setText} /></F>
      <Btn kind="primary" disabled={!lines.length || lines.length > 1000} onClick={() => void add()}>Add {lines.length || ""} key{lines.length === 1 ? "" : "s"}</Btn>
      {keys.data && keys.data.length > 0 && (
        <div className="text-sm"><div className="mb-1 font-medium">Latest unsold keys</div>
          {keys.data.map((k) => <div key={k.id} className="flex items-center justify-between border-b border-line py-1 font-mono"><span>{k.preview}</span><button className="text-red-600" onClick={async () => { if (await ask("Remove this key?")) { await run(() => adm(`/keys/${k.id}`, undefined, "DELETE"), "Removed"); keys.reload(); reload(); } }}>Remove</button></div>)}
        </div>
      )}
    </div>
  );
}

function VariantsPanel({ p, reload }: { p: any; reload: () => void }) {
  const [edit, setEdit] = useState<any | null>(null);
  async function save() {
    const b = { name: edit.name, sku: edit.sku || null, price: edit.price === null || edit.price === "" ? null : edit.price, stock: edit.stock, status: edit.status };
    const r = await run(() => (edit.id ? adm(`/variants/${edit.id}`, b, "PUT") : adm(`/products/${p.id}/variants`, b)), "Variant saved");
    if (r) { setEdit(null); reload(); }
  }
  return (
    <Card title="Variants" actions={<Btn small onClick={() => setEdit({ name: "", sku: "", price: null, stock: null, status: "PUBLISHED" })}>＋ Add variant</Btn>}>
      <p className="mb-3 text-sm text-hint">Variants let customers choose an option (e.g. “100 diamonds”, “1 month”). A variant without its own price uses the product price.{p.deliveryType === "TEXT_KEYS" && " Keys are stocked per variant."}</p>
      {p.variants.map((v: any) => (
        <div key={v.id} className="mb-2 flex flex-wrap items-center gap-2 rounded-xl border border-line p-2">
          <div className="min-w-0 flex-1"><div className="font-medium">{v.name} {v.status !== "PUBLISHED" && <Pill>hidden</Pill>}</div><div className="text-xs text-hint">{v.price !== null ? money(v.price) : "product price"} · {p.deliveryType === "TEXT_KEYS" ? `${p.keyStock[v.id] ?? 0} keys` : v.stock === null ? "unlimited" : `${v.stock} left`}</div></div>
          <Btn small onClick={() => setEdit({ ...v, price: v.price === null ? null : Number(v.price), sku: v.sku ?? "" })}>Edit</Btn>
          <Btn small kind="danger" onClick={async () => { if (await ask(`Delete variant "${v.name}"?`)) { const r: any = await run(() => adm(`/variants/${v.id}`, undefined, "DELETE")); if (r?.hiddenInstead) toast("It has orders, so it was hidden instead."); reload(); } }}>Delete</Btn>
        </div>
      ))}
      {edit && (
        <div className="mt-3 space-y-3 rounded-xl border border-brand/40 p-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <F label="Name"><TextIn value={edit.name} maxLength={80} onChange={(v) => setEdit({ ...edit, name: v })} /></F>
            <F label="SKU (optional)"><TextIn value={edit.sku} maxLength={40} onChange={(v) => setEdit({ ...edit, sku: v })} /></F>
            <F label="Price (empty = product price)"><NumIn value={edit.price} min={0} step="0.01" onChange={(v) => setEdit({ ...edit, price: v })} /></F>
            {p.deliveryType !== "TEXT_KEYS" && <F label="Units (empty = unlimited)"><NumIn value={edit.stock} min={0} onChange={(v) => setEdit({ ...edit, stock: v })} /></F>}
            <F label="Visibility"><Sel value={edit.status} onChange={(v) => setEdit({ ...edit, status: v })} options={[{ value: "PUBLISHED", label: "Shown" }, { value: "DRAFT", label: "Hidden" }]} /></F>
          </div>
          <div className="flex gap-2"><Btn kind="primary" disabled={!edit.name.trim()} onClick={() => void save()}>Save variant</Btn><Btn onClick={() => setEdit(null)}>Cancel</Btn></div>
        </div>
      )}
    </Card>
  );
}

function ProductOrders({ id }: { id: string }) {
  const r = useAdmin<any[]>(`/products/${id}/orders?limit=30`);
  return (
    <Card title="Related orders"><Async r={r}>{(items) => items.length ? items.map((i: any) => (
      <Link key={i.id} href={`/admin/orders/${i.order.id}`} className="flex flex-wrap items-center justify-between gap-2 border-b border-line py-2 last:border-0">
        <span><span className="font-mono">{i.order.orderNo}</span> · {i.quantity}× {i.variantName ?? ""} · {i.order.user.firstName ?? i.order.user.username}</span>
        <span className="flex items-center gap-2"><Pill tone={statusTone(i.order.status)}>{i.order.status}</Pill><span className="text-xs text-hint">{when(i.order.createdAt)}</span></span>
      </Link>
    )) : <p className="text-sm text-hint">No orders yet.</p>}</Async></Card>
  );
}
