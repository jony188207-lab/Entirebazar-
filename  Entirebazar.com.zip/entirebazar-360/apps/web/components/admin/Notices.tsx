"use client";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { when } from "@/lib/api";
import { ButtonBuilder } from "./Builders";
import { Area, Async, Btn, Card, CategoryPicker, Check, DateIn, F, ImageField, NumIn, Pager, Pill, ProductPicker, SearchBox, Sel, TextIn, adm, ask, run, toast, useAdmin, useDirty } from "./kit";

export function NoticeList() {
  const [q, setQ] = useState("");
  const [loc, setLoc] = useState("");
  const [page, setPage] = useState(1);
  const meta = useAdmin<any>("/cms/meta");
  const list = useAdmin<any>(`/notices?page=${page}&limit=20${q ? `&q=${encodeURIComponent(q)}` : ""}${loc ? `&location=${loc}` : ""}`);
  return (
    <div className="space-y-3">
      <div className="flex flex-wrap items-center justify-between gap-2"><h1 className="text-2xl font-bold">Notices & banners</h1><Link href="/admin/notices/new" className="btn !px-3 !py-1.5 text-sm">＋ New notice</Link></div>
      <p className="text-sm text-hint">Banners and notices appear in the places you choose: homepage banners, category pages, product pages, wallet, payments, orders and the notification centre. Never put private customer data in a notice: every customer in the audience can read it.</p>
      <div className="grid gap-2 sm:grid-cols-2">
        <SearchBox value={q} onChange={(v) => { setQ(v); setPage(1); }} placeholder="Search by title…" />
        <Sel value={loc} onChange={(v) => { setLoc(v); setPage(1); }} options={[{ value: "", label: "All locations" }, ...((meta.data?.noticeLocations ?? []) as string[])]} />
      </div>
      <Async r={list}>{(d) => (
        <>
          {d.items.map((n: any) => {
            const now = Date.now();
            const state = !n.enabled ? "Disabled" : new Date(n.publishAt).getTime() > now ? "Scheduled" : n.expiresAt && new Date(n.expiresAt).getTime() < now ? "Expired" : "Showing";
            return (
              <div key={n.id} className="card !p-3">
                <div className="flex flex-wrap items-center gap-2">
                  <div className="min-w-0 flex-1">
                    <Link href={`/admin/notices/${n.id}`} className="font-semibold">{n.pinned ? "📌 " : ""}{n.icon ?? ""} {n.title}</Link>
                    <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-hint">
                      <Pill tone={state === "Showing" ? "green" : state === "Scheduled" ? "blue" : "gray"}>{state}</Pill><Pill>{n.type}</Pill><span>{n.audience === "ALL" ? "All users" : n.audience === "CATEGORIES" ? `${n.categoryIds.length} categories` : `${n.productIds.length} products`}</span>
                      <span>{n.locations.join(", ")}</span><span>{when(n.publishAt)}</span><span>{n._count.dismissals} dismissed</span>
                    </div>
                  </div>
                  <Btn small onClick={async () => { await run(() => adm(`/notices/${n.id}`, { ...n, publishAt: n.publishAt, enabled: !n.enabled }, "PUT")); list.reload(); }}>{n.enabled ? "Disable" : "Enable"}</Btn>
                  <Link href={`/admin/notices/${n.id}`} className="btn-ghost !px-3 !py-1.5 text-sm">Edit</Link>
                  <Btn small onClick={async () => { await run(() => adm(`/notices/${n.id}/duplicate`, {}), "Duplicated (disabled)"); list.reload(); }}>Duplicate</Btn>
                  <Btn small kind="danger" onClick={async () => { if (await ask(`Delete "${n.title}"?`)) { await run(() => adm(`/notices/${n.id}`, undefined, "DELETE"), "Deleted"); list.reload(); } }}>Delete</Btn>
                </div>
              </div>
            );
          })}
          {!d.items.length && <div className="card text-center text-hint">No notices.</div>}
          <Pager page={d.page} pages={d.pages} total={d.total} onPage={setPage} />
        </>
      )}</Async>
    </div>
  );
}

const blank = (cat?: string | null, prod?: string | null) => ({
  title: "", body: "", type: "INFO", icon: "", imageUrl: null as string | null, locations: [cat ? "CATEGORY_PAGE" : prod ? "PRODUCT_DETAIL" : "HOME_BANNER"],
  audience: cat ? "CATEGORIES" : prod ? "PRODUCTS" : "ALL", categoryIds: cat ? [cat] : [], productIds: prod ? [prod] : [], priority: 0, dismissible: true, pinned: false, enabled: true,
  publishAt: new Date().toISOString(), expiresAt: null as string | null,
});

function NoticeEditorInner({ id }: { id: string }) {
  const router = useRouter();
  const sp = useSearchParams();
  const isNew = id === "new";
  const meta = useAdmin<any>("/cms/meta");
  const r = useAdmin<any>(isNew ? null : `/notices/${id}`);
  const { form, setForm, reset, dirty } = useDirty<any>(null);
  useEffect(() => {
    if (isNew && !form) reset(blank(sp.get("category"), sp.get("product")));
    else if (r.data && !form) { const n = r.data; reset({ title: n.title, body: n.body, type: n.type, icon: n.icon ?? "", imageUrl: n.imageUrl ?? null, locations: n.locations, audience: n.audience, categoryIds: n.categoryIds, productIds: n.productIds, priority: n.priority, dismissible: n.dismissible, pinned: n.pinned, enabled: n.enabled, publishAt: n.publishAt, expiresAt: n.expiresAt ?? null }); }
  }, [r.data, isNew]); // eslint-disable-line react-hooks/exhaustive-deps
  if (!form) return <div className="py-8 text-center text-hint">{r.error ?? "Loading…"}</div>;
  const set = (p: any) => setForm({ ...form, ...p });
  async function save() {
    const body = { ...form, icon: form.icon || null };
    const out: any = await run(() => (isNew ? adm("/notices", body) : adm(`/notices/${id}`, body, "PUT")), "Saved");
    if (!out) return;
    if (isNew) router.replace(`/admin/notices/${out.id}`);
    else { reset(form); r.reload(); }
  }
  async function telegram() {
    if (!(await ask("Send this notice to all users who accept announcements through the Telegram bot? Users who blocked the bot are skipped."))) return;
    const j: any = await run(() => adm(`/notices/${id}/telegram`, {}), "Broadcast started");
    void j;
  }
  const locs: string[] = meta.data?.noticeLocations ?? [];
  return (
    <div className="pb-24">
      <div className="mb-3 flex items-center gap-2"><Link href="/admin/notices" className="text-sm text-brand">← Notices</Link><h1 className="text-xl font-bold">{isNew ? "New notice" : form.title || "Notice"}</h1></div>
      <div className="space-y-4">
        <Card title="Content">
          <F label="Title"><TextIn value={form.title} maxLength={120} onChange={(v) => set({ title: v })} /></F>
          <F label="Message" className="mt-3"><Area value={form.body} rows={4} maxLength={2000} onChange={(v) => set({ body: v })} /></F>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            <F label="Type"><Sel value={form.type} onChange={(v) => set({ type: v })} options={["INFO", "PROMO", "WARNING", "MAINTENANCE", "PAYMENT", "ORDER", "UPDATE"]} /></F>
            <F label="Icon (emoji)"><TextIn value={form.icon} maxLength={8} onChange={(v) => set({ icon: v })} /></F>
            <F label="Priority (higher first)"><NumIn value={form.priority} min={0} max={1000} onChange={(v) => set({ priority: v ?? 0 })} /></F>
          </div>
          <div className="mt-3"><ImageField label="Image (optional)" value={form.imageUrl} onChange={(v) => set({ imageUrl: v })} /></div>
        </Card>
        <Card title="Where it appears">
          <div className="grid gap-1 sm:grid-cols-2">
            {locs.map((l) => <Check key={l} label={l.replace(/_/g, " ").toLowerCase()} checked={form.locations.includes(l)} onChange={(v) => set({ locations: v ? [...form.locations, l] : form.locations.filter((x: string) => x !== l) })} />)}
          </div>
          <F label="Show to" className="mt-3"><Sel value={form.audience} onChange={(v) => set({ audience: v })} options={[{ value: "ALL", label: "Everyone on those pages" }, { value: "CATEGORIES", label: "Only in selected categories" }, { value: "PRODUCTS", label: "Only for selected products" }]} /></F>
          {form.audience === "CATEGORIES" && <div className="mt-2"><CategoryPicker value={form.categoryIds} onChange={(v) => set({ categoryIds: v })} /></div>}
          {form.audience === "PRODUCTS" && <div className="mt-2"><ProductPicker max={50} value={form.productIds} onChange={(v) => set({ productIds: v })} /></div>}
          {form.audience === "CATEGORIES" && !form.locations.includes("CATEGORY_PAGE") && <p className="mt-2 text-xs text-amber-600">Tip: also tick “category page”, otherwise it will not show there.</p>}
          {form.audience === "PRODUCTS" && !form.locations.includes("PRODUCT_DETAIL") && <p className="mt-2 text-xs text-amber-600">Tip: also tick “product detail”.</p>}
        </Card>
        <Card title="Schedule & behaviour">
          <div className="grid gap-3 sm:grid-cols-2"><F label="Starts"><DateIn value={form.publishAt} onChange={(v) => set({ publishAt: v ?? new Date().toISOString() })} /></F><F label="Ends (optional)"><DateIn value={form.expiresAt} onChange={(v) => set({ expiresAt: v })} /></F></div>
          <Check label="Enabled" checked={form.enabled} onChange={(v) => set({ enabled: v })} />
          <Check label="Customers can dismiss it" hint="Turn off for payment instructions and maintenance notices that must stay visible." checked={form.dismissible} onChange={(v) => set({ dismissible: v })} />
          <Check label="Pin to the top" checked={form.pinned} onChange={(v) => set({ pinned: v })} />
        </Card>
        {!isNew && <ButtonBuilder owner={{ noticeId: id }} title="Action buttons" note="Optional buttons shown inside the notice." />}
        {!isNew && form.audience === "ALL" && <Card title="Telegram"><p className="mb-2 text-sm text-hint">Also push this notice to customers through the bot. It is queued and rate-limited; customers who muted promotions or blocked the bot are skipped, and the in-app copy always remains.</p><Btn onClick={() => void telegram()}>Send via Telegram bot</Btn></Card>}
      </div>
      <div className="fixed inset-x-0 bottom-0 z-20 border-t border-line bg-card p-3"><div className="mx-auto flex max-w-6xl items-center gap-3"><span className="flex-1 text-sm text-hint">{dirty || isNew ? "Unsaved changes." : "Saved."}</span><Btn kind="primary" disabled={!form.title.trim() || !form.body.trim() || !form.locations.length || (!dirty && !isNew)} onClick={() => void save()}>{isNew ? "Create notice" : "Save changes"}</Btn></div></div>
    </div>
  );
}
export const NoticeEditor = ({ id }: { id: string }) => <Suspense fallback={<div className="py-8 text-center text-hint">Loading…</div>}><NoticeEditorInner id={id} /></Suspense>;
void toast;
