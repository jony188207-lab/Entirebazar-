"use client";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { publicApi, tg, useApi } from "@/lib/api";
import { Announcements } from "./ui";
import { Logo } from "./Logo";
import { APP_NAME, APP_TAGLINE } from "@/lib/brand";

const NAV = [
  { href: "/", label: "Home", icon: "🏠" },
  { href: "/shop", label: "Shop", icon: "🛍️" },
  { href: "/wallet", label: "Wallet", icon: "👛" },
  { href: "/orders", label: "Orders", icon: "📦" },
  { href: "/profile", label: "Profile", icon: "👤" },
];

export default function Shell({ children }: { children: React.ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<{ maintenance: boolean; message?: string; notices: any[] } | null>(null);
  const isAdmin = path.startsWith("/admin");

  useEffect(() => {
    const w = tg();
    w?.ready();
    w?.expand();
    setReady(true);
    publicApi("/status").then(setStatus).catch(() => setStatus({ maintenance: false, notices: [] }));
  }, []);

  // Telegram's native back button mirrors in-app navigation.
  useEffect(() => {
    const b = tg()?.BackButton;
    if (!b) return;
    const back = () => router.back();
    if (path === "/") b.hide();
    else {
      b.show();
      b.onClick(back);
    }
    return () => b.offClick?.(back);
  }, [path, router]);

  if (!ready || !status) {
    return (
      <div className="flex flex-col items-center gap-3 p-8 text-center text-hint">
        <Logo height={36} />
        <span>Loading…</span>
      </div>
    );
  }

  if (!tg()?.initData) {
    return (
      <div className="p-8 text-center">
        <div className="mb-4 flex justify-center"><Logo height={40} /></div>
        <p className="text-lg font-semibold">Open {APP_NAME} inside Telegram</p>
        <p className="mt-2 text-hint">Your Telegram account is used to sign you in securely.</p>
      </div>
    );
  }

  if (status.maintenance && !isAdmin) {
    return (
      <div className="p-6">
        <div className="card text-center">
          <div className="mb-3 flex justify-center"><Logo height={36} /></div>
          <div className="text-4xl">🛠️</div>
          <h1 className="mt-2 text-xl font-bold">Under maintenance</h1>
          <p className="mt-1 text-hint">{status.message || "We'll be back shortly."}</p>
        </div>
        <div className="mt-4"><Announcements items={status.notices} /></div>
      </div>
    );
  }

  return (
    <>
      <header className={`mx-auto flex ${isAdmin ? "max-w-6xl" : "max-w-xl"} items-center justify-between px-4 pt-3`}>
        <Link href={isAdmin ? "/admin" : "/"} aria-label={`${APP_NAME} home`}>
          <Logo height={28} />
        </Link>
        {isAdmin && <span className="rounded-full bg-brand/15 px-2 py-0.5 text-xs font-semibold text-brand">Admin</span>}
      </header>
      <main className={`mx-auto px-4 pt-4 ${isAdmin ? "max-w-6xl" : "max-w-xl"}`}>{children}</main>
      <footer className="mx-auto max-w-xl px-4 pb-4 pt-6 text-center text-xs text-hint">
        <div className="font-semibold">{APP_NAME}</div>
        <div>{APP_TAGLINE}</div>
        <div className="mt-1">© {new Date().getFullYear()} {APP_NAME}. All rights reserved.</div>
      </footer>
      {!isAdmin && (
        <nav className="fixed inset-x-0 bottom-0 border-t border-line bg-card pb-[env(safe-area-inset-bottom)]">
          <ul className="mx-auto flex max-w-xl">
            {NAV.map((n) => {
              const active = n.href === "/" ? path === "/" : path.startsWith(n.href);
              return (
                <li key={n.href} className="flex-1">
                  <Link href={n.href} className={`flex flex-col items-center py-2 text-xs ${active ? "text-brand font-semibold" : "text-hint"}`}>
                    <span className="text-lg">{n.icon}</span>
                    {n.label}
                  </Link>
                </li>
              );
            })}
          </ul>
        </nav>
      )}
    </>
  );
}

export function Bell() {
  const { data } = useApi<{ unread: number }>("/notifications/unread-count");
  return (
    <Link href="/notifications" className="relative text-2xl" aria-label="Notifications">
      🔔
      {!!data?.unread && (
        <span className="absolute -right-2 -top-1 min-w-5 rounded-full bg-red-500 px-1 text-center text-[11px] font-bold text-white">
          {data.unread > 99 ? "99+" : data.unread}
        </span>
      )}
    </Link>
  );
}
