"use client";
import Link from "next/link";
import { ActionButtons, CategoryCards, FaqList, Notices, ProductGrid, SafeImg, SectionView, SupportInfo, useGo } from "./blocks";

export interface CategoryQuery { q: string; sort: string; inStock: boolean; page: number }

/** Renders a category page payload exactly as customers see it. Shared by the Mini App route and the admin preview. */
export function CategoryView({ page, query, onQuery, readOnly = false }: { page: any; query?: CategoryQuery; onQuery?: (q: Partial<CategoryQuery>) => void; readOnly?: boolean }) {
  const go = useGo();
  const c = page.category;
  const st = page.settings;
  const hasFaqSection = page.sections.some((s: any) => s.type === "FAQ");
  const topButtons = (page.buttons as any[]).filter((b) => b.placement !== "BOTTOM" && b.placement !== "STICKY");
  const bottomButtons = (page.buttons as any[]).filter((b) => b.placement === "BOTTOM");
  const sticky = (page.buttons as any[]).filter((b) => b.placement === "STICKY");
  const accent = st.display?.accentColor as string | null;
  const q = query ?? { q: "", sort: st.sorting.default, inStock: false, page: 1 };

  return (
    <div className={`pb-6 ${readOnly ? "pointer-events-none select-none" : ""}`} style={accent ? ({ ["--brand" as any]: accent } as React.CSSProperties) : undefined}>
      {st.layout.showBreadcrumbs && page.breadcrumbs.length > 0 && (
        <nav className="mb-2 text-xs text-hint">
          <Link href="/shop">Shop</Link>{page.breadcrumbs.map((b: any) => <span key={b.slug}> › <Link href={`/category/${b.slug}`}>{b.name}</Link></span>)}
        </nav>
      )}
      {st.layout.showCover && c.coverUrl && <SafeImg src={c.coverUrl} className="mb-3 h-32 w-full rounded-2xl object-cover" />}
      <div className="flex items-start gap-3">
        {c.icon && <div className="text-3xl">{c.icon}</div>}
        <div className="min-w-0 flex-1">
          <h1 className="text-2xl font-bold">{c.name}</h1>
          {c.description && <p className="mt-0.5 text-hint">{c.description}</p>}
        </div>
      </div>
      {c.discountPercent ? <div className="mt-2 inline-block rounded-full bg-red-500/15 px-3 py-1 text-sm font-semibold text-red-600">🔥 {c.discountPercent}% off in this category</div> : null}
      {!c.purchasable && <div className="mt-3 rounded-xl bg-amber-500/15 p-3 text-sm text-amber-700">{c.unavailableMessage}</div>}

      <div className="mt-3"><Notices items={page.notices} readOnly={readOnly} /></div>
      {topButtons.length > 0 && <div className="mt-3"><ActionButtons buttons={topButtons} disabled={readOnly} /></div>}

      {page.children.length > 0 && (
        <section className="mt-5"><h2 className="mb-2 text-lg font-bold">Subcategories</h2><CategoryCards items={page.children} /></section>
      )}

      {page.sections.map((s: any) => <SectionView key={s.id} s={s} serverNow={page.serverNow} readOnly={readOnly} />)}

      {st.layout.showDefaultProductList && (page.list.total > 0 || q.q || q.inStock) && (
        <section className="mt-5">
          <h2 className="mb-2 text-lg font-bold">{page.sections.length ? "All products" : "Products"}</h2>
          {(st.filters.search || st.filters.inStock || st.sorting.options.length > 1) && (
            <div className="mb-3 space-y-2">
              {st.filters.search && <input className="input" placeholder="Search in this category…" value={q.q} onChange={(e) => onQuery?.({ q: e.target.value, page: 1 })} />}
              <div className="flex items-center gap-3 text-sm">
                {st.sorting.options.length > 1 && (
                  <select className="rounded-lg bg-card px-2 py-1.5" value={q.sort} onChange={(e) => onQuery?.({ sort: e.target.value, page: 1 })}>
                    {st.sorting.options.map((o: string) => <option key={o} value={o}>{({ NEWEST: "Newest", POPULAR: "Popular", PRICE_ASC: "Price: low → high", PRICE_DESC: "Price: high → low", NAME: "Name" } as any)[o]}</option>)}
                  </select>
                )}
                {st.filters.inStock && <label className="flex items-center gap-1.5"><input type="checkbox" checked={q.inStock} onChange={(e) => onQuery?.({ inStock: e.target.checked, page: 1 })} /> In stock</label>}
              </div>
            </div>
          )}
          {page.list.items.length ? (
            <ProductGrid items={page.list.items} layout={st.layout.columns === 1 ? "LIST" : st.layout.columns === 3 ? "GRID_3" : "GRID_2"} />
          ) : (
            <p className="py-6 text-center text-hint">{st.layout.emptyMessage}</p>
          )}
          {page.list.pages > 1 && (
            <div className="mt-3 flex items-center justify-center gap-3 text-sm">
              <button className="btn-ghost !py-1.5" disabled={q.page <= 1} onClick={() => onQuery?.({ page: q.page - 1 })}>‹ Prev</button>
              <span>{page.list.page} / {page.list.pages}</span>
              <button className="btn-ghost !py-1.5" disabled={q.page >= page.list.pages} onClick={() => onQuery?.({ page: q.page + 1 })}>Next ›</button>
            </div>
          )}
        </section>
      )}
      {!page.sections.length && !page.list.total && !page.children.length && !q.q && <p className="py-10 text-center text-hint">{st.layout.emptyMessage}</p>}

      {!hasFaqSection && page.faq.length > 0 && <section id="faq" className="mt-5"><h2 className="mb-2 text-lg font-bold">FAQ</h2><FaqList items={page.faq} /></section>}
      {page.support && (
        <button className="btn-ghost mt-5 w-full" onClick={() => void go({ nav: { kind: "external", url: page.support.url }, confirm: { title: "Open support link?", message: `This opens ${new URL(page.support.url).hostname}.` } })}>💬 Get help with this category</button>
      )}
      {!page.support && page.contact?.telegramUsername && <div className="mt-5"><SupportInfo contact={page.contact} /></div>}

      {bottomButtons.length > 0 && <div className="mt-5"><ActionButtons buttons={bottomButtons} disabled={readOnly} /></div>}
      {sticky.length > 0 && (
        <div className="fixed inset-x-0 bottom-[calc(64px+env(safe-area-inset-bottom))] z-10 border-t border-line bg-card p-3">
          <div className="mx-auto max-w-xl"><ActionButtons buttons={sticky} layout="GRID" disabled={readOnly} /></div>
        </div>
      )}
    </div>
  );
}
