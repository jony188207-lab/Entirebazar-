"use client";

export { Announcements, Notices, Banners, ProductCard } from "./blocks";

const BADGE: Record<string, string> = {
  PENDING: "bg-amber-500/15 text-amber-700",
  SUCCESSFUL: "bg-emerald-500/15 text-emerald-700",
  DELIVERED: "bg-emerald-500/15 text-emerald-700",
  PAID: "bg-blue-500/15 text-blue-700",
  PROCESSING: "bg-blue-500/15 text-blue-700",
  FAILED: "bg-red-500/15 text-red-700",
  REJECTED: "bg-red-500/15 text-red-700",
  EXPIRED: "bg-gray-500/15 text-gray-600",
  REFUNDED: "bg-purple-500/15 text-purple-700",
  CANCELLED: "bg-gray-500/15 text-gray-600",
};
export const Badge = ({ s }: { s: string }) => (
  <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${BADGE[s] ?? "bg-gray-500/15"}`}>{s}</span>
);

export const Section = ({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) => (
  <section className="mt-5">
    <div className="mb-2 flex items-center justify-between">
      <h2 className="text-lg font-bold">{title}</h2>
      {action}
    </div>
    {children}
  </section>
);

export const Loading = () => <div className="py-10 text-center text-hint">Loading…</div>;
export const ErrorBox = ({ msg }: { msg: string }) => <div className="card text-red-500">{msg}</div>;
