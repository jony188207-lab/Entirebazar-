import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bg: "var(--bg)",
        card: "var(--card)",
        fg: "var(--fg)",
        hint: "var(--hint)",
        brand: "var(--brand)",
        brandfg: "var(--brandfg)",
        line: "var(--line)",
      },
    },
  },
  plugins: [],
} satisfies Config;
