import React from "react";
export default function Link({ href, children, ...r }: any) { return React.createElement("a", { href, ...r }, children); }
export const useRouter = () => ({ push() {}, back() {} });
export const usePathname = () => "/";
export const useParams = () => ({});
export const useSearchParams = () => new URLSearchParams();
