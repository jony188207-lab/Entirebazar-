// Server-render the safe renderers with hostile content and check nothing executable reaches the markup.
import test from "node:test";
import assert from "node:assert/strict";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { createRequire } from "node:module";
import esbuild from "esbuild";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const require = createRequire(import.meta.url);
const stub = path.join(root, "test/stubs.tsx");

const out = await esbuild.build({
  stdin: { contents: `export * from "./components/blocks"; export * from "./components/CategoryView";`, resolveDir: root, loader: "tsx" },
  bundle: true, platform: "node", format: "cjs", write: false, jsx: "automatic", logLevel: "silent",
  alias: { "next/link": stub, "next/navigation": stub, "@": root }, external: ["react", "react-dom", "react/jsx-runtime"],
});
const m = { exports: {} };
new Function("module", "exports", "require", out.outputFiles[0].text)(m, m.exports, require);
const { SectionView, Md, CategoryView } = m.exports;
const React = require("react");
const { renderToStaticMarkup } = require("react-dom/server");
const html = (el) => renderToStaticMarkup(el);

const EVIL = `<script>alert(1)</script><img src=x onerror=alert(2)> **bold**`;

test("rich text is rendered as escaped text, never as HTML", () => {
  const out = html(React.createElement(SectionView, { s: { id: "1", type: "RICH_TEXT", config: { text: EVIL, align: "LEFT" }, buttons: [] }, serverNow: new Date().toISOString() }));
  assert.ok(!out.includes("<script"));
  assert.ok(!out.includes("<img"));
  assert.ok(out.includes("&lt;script&gt;"));
  assert.ok(out.includes("<strong>bold</strong>"));
});

test("markdown subset: lists and paragraphs", () => {
  const out = html(React.createElement(Md, { text: "- one\n- two\n\nplain" }));
  assert.match(out, /<ul[^>]*><li>one<\/li><li>two<\/li><\/ul>/);
});

test("image sections only render absolute http(s) URLs", () => {
  const mk = (u) => html(React.createElement(SectionView, { s: { id: "i", type: "IMAGE", config: { imageUrl: u, alt: "x", fit: "COVER", aspect: "16_9" }, buttons: [] }, serverNow: "" }));
  assert.ok(!mk("javascript:alert(1)").includes("<img"));
  assert.ok(!mk("data:text/html,<script>1</script>").includes("<img"));
  assert.ok(mk("https://example.com/a.png").includes("<img"));
});

test("all 14 section types render without throwing", () => {
  const now = new Date().toISOString();
  const cfgs = {
    PRODUCT_GRID: [{ layout: "GRID_2" }, [{ id: "p", name: "<b>x</b>", price: "10", originalPrice: "10", inStock: true, stock: null, variants: [], cardLayout: "DEFAULT" }]],
    FEATURED_PRODUCTS: [{ layout: "CAROUSEL" }, [{ id: "p", name: "x", price: "10", originalPrice: "10", inStock: true, stock: 2 }]],
    PROMO_BANNER: [{ heading: "h", text: "t", tone: "BRAND" }, null], NOTICE: [{ heading: "h", text: "t", tone: "INFO" }, null], RICH_TEXT: [{ text: "t", align: "CENTER" }, null],
    IMAGE: [{ imageUrl: "https://e.com/a.png", alt: "", fit: "COVER", aspect: "1_1" }, null], BUTTON_GROUP: [{ layout: "ROW" }, null],
    CATEGORY_GRID: [{ columns: 2, showImages: true }, [{ id: "c", name: "C", slug: "c" }]], FAQ: [{}, [{ q: "q", a: "a" }]],
    HOW_IT_WORKS: [{ steps: [{ title: "a", text: "b" }] }, null], SUPPORT_INFO: [{ text: "t" }, { telegramUsername: "abcde" }], TERMS: [{ text: "t", collapsed: true }, null],
    COUNTDOWN: [{ endsAt: new Date(Date.now() + 1e6).toISOString(), label: "L" }, { serverNow: now }], EMPTY_STATE: [{ heading: "h" }, null],
  };
  assert.equal(Object.keys(cfgs).length, 14);
  for (const [type, [config, data]] of Object.entries(cfgs)) {
    const buttons = type === "BUTTON_GROUP" ? [{ id: "b", label: "Go", style: "PRIMARY", size: "MD", placement: "INLINE", nav: { kind: "route", path: "/wallet" }, confirm: null }] : [];
    assert.doesNotThrow(() => html(React.createElement(SectionView, { s: { id: type, type, title: "T", config, data, buttons }, serverNow: now })), type);
  }
});

test("category page renders with sections, notices and buttons", () => {
  const page = {
    category: { id: "c", name: "Cat", slug: "cat", purchasable: true, discountPercent: null }, settings: { layout: { showBreadcrumbs: true, showCover: true, showDefaultProductList: true, columns: 2, emptyMessage: "none" }, filters: { search: true, inStock: true }, sorting: { options: ["NEWEST"], default: "NEWEST" }, display: {} },
    breadcrumbs: [], children: [], buttons: [{ id: "b", label: "Wallet", style: "PRIMARY", size: "MD", placement: "TOP", nav: { kind: "route", path: "/wallet" }, confirm: null }],
    sections: [{ id: "s", type: "RICH_TEXT", config: { text: EVIL, align: "LEFT" }, buttons: [] }], list: { items: [], total: 0, page: 1, pages: 1 }, notices: [{ id: "n", title: EVIL, body: EVIL, type: "INFO", dismissible: true, buttons: [] }], faq: [], support: null, contact: null, serverNow: new Date().toISOString(),
  };
  const out = html(React.createElement(CategoryView, { page, readOnly: true }));
  assert.ok(!out.includes("<script"));
  assert.ok(out.includes("Wallet"));
});
