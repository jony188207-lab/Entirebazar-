"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect } from "react";
import { money, useApi, when } from "@/lib/api";
import { Announcements, Badge, ErrorBox, Loading } from "@/components/ui";

const COPY: Record<string, string> = {
  PENDING: "We are verifying your payment. This page updates automatically; your balance changes only after verification.",
  SUCCESSFUL: "Payment verified and added to your wallet.",
  FAILED: "This payment could not be completed.",
  EXPIRED: "This invoice expired before a payment was verified. If you already paid, contact support with your transaction ID.",
  REJECTED: "This payment was rejected after review.",
};

export default function DepositReceipt() {
  const { id } = useParams<{ id: string }>();
  const { data: d, error, loading, reload } = useApi<any>(`/deposits/${id}`);

  // Poll while pending. Status is always read from the backend, never from the client.
  useEffect(() => {
    if (d?.status !== "PENDING") return;
    const t = setInterval(reload, 8000);
    return () => clearInterval(t);
  }, [d?.status, reload]);

  if (loading && !d) return <Loading />;
  if (error || !d) return <ErrorBox msg={error ?? "Not found"} />;

  return (
    <div>
      <h1 className="text-2xl font-bold">Payment receipt</h1>
      <div className="card mt-3 space-y-2">
        <div className="flex items-center justify-between"><span className="text-3xl font-extrabold">{money(d.amount)}</span><Badge s={d.status} /></div>
        <p className="text-sm text-hint">{COPY[d.status]}</p>
        {d.failureReason && <p className="text-sm text-red-500">Reason: {d.failureReason}</p>}
        <dl className="grid grid-cols-2 gap-y-1 pt-2 text-sm">
          <dt className="text-hint">Invoice</dt><dd className="text-right font-mono">{d.invoiceNo}</dd>
          <dt className="text-hint">Method</dt><dd className="text-right">{d.provider.displayName}</dd>
          <dt className="text-hint">Transaction ID</dt><dd className="text-right font-mono">{d.providerTrxId ?? "—"}</dd>
          <dt className="text-hint">Created</dt><dd className="text-right">{when(d.createdAt)}</dd>
          {d.verifiedAt && (<><dt className="text-hint">Verified</dt><dd className="text-right">{when(d.verifiedAt)}</dd></>)}
        </dl>
      </div>
      <div className="mt-3"><Announcements items={d.notices} /></div>
      <div className="mt-4 grid grid-cols-2 gap-3">
        <Link href="/wallet" className="btn-ghost">Wallet</Link>
        <Link href="/support" className="btn-ghost">Need help?</Link>
      </div>
    </div>
  );
}
