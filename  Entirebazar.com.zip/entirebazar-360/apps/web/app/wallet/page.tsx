"use client";
import Link from "next/link";
import { useState } from "react";
import { money, useApi, when } from "@/lib/api";
import { Announcements, Badge, ErrorBox, Loading, Section } from "@/components/ui";

export default function Wallet() {
  const [kind, setKind] = useState<"all" | "deposits" | "spending">("all");
  const { data, error, loading } = useApi<any>(`/wallet?kind=${kind}`);
  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorBox msg={error ?? "Failed to load"} />;

  return (
    <div>
      <h1 className="text-2xl font-bold">Wallet</h1>
      <div className="card mt-3">
        <div className="text-sm text-hint">Available balance</div>
        <div className="text-3xl font-extrabold">{money(data.balance)}</div>
        <Link href="/wallet/add" className="btn mt-3 block">＋ Add Money</Link>
      </div>
      <div className="mt-3"><Announcements items={data.notices} /></div>

      <Section title="Deposits">
        <div className="space-y-2">
          {data.deposits.length === 0 && <p className="text-hint">No deposits yet.</p>}
          {data.deposits.map((d: any) => (
            <Link key={d.id} href={`/wallet/deposits/${d.id}`} className="card flex items-center justify-between">
              <div>
                <div className="font-semibold">{money(d.amount)} · {d.provider.displayName}</div>
                <div className="text-xs text-hint">{d.invoiceNo} · {when(d.createdAt)}</div>
              </div>
              <Badge s={d.status} />
            </Link>
          ))}
        </div>
      </Section>

      <Section title="Transactions">
        <div className="mb-2 flex gap-2 text-sm">
          {(["all", "deposits", "spending"] as const).map((k) => (
            <button key={k} onClick={() => setKind(k)} className={`rounded-full px-3 py-1 capitalize ${kind === k ? "bg-brand text-brandfg" : "bg-card"}`}>{k}</button>
          ))}
        </div>
        <div className="space-y-2">
          {data.entries.length === 0 && <p className="text-hint">Nothing here yet.</p>}
          {data.entries.map((e: any) => (
            <div key={e.id} className="card flex items-center justify-between">
              <div>
                <div className="font-semibold capitalize">{e.type.toLowerCase()}</div>
                <div className="text-xs text-hint">{e.note} · {when(e.createdAt)}</div>
              </div>
              <div className="text-right">
                <div className={e.direction === "CREDIT" ? "font-bold text-emerald-600" : "font-bold text-red-500"}>
                  {e.direction === "CREDIT" ? "+" : "−"}{money(e.amount)}
                </div>
                <div className="text-xs text-hint">Bal {money(e.balanceAfter)}</div>
              </div>
            </div>
          ))}
        </div>
      </Section>
    </div>
  );
}
