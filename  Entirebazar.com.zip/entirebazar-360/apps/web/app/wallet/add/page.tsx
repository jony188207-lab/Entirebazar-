"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { api, money, useApi } from "@/lib/api";
import { Announcements, ErrorBox, Loading } from "@/components/ui";

const PRESETS = [100, 200, 500, 1000, 2000, 5000];

export default function AddMoney() {
  const router = useRouter();
  const { data, error, loading } = useApi<any>("/payments/methods");
  const [method, setMethod] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [invoice, setInvoice] = useState<any>(null);
  const [trx, setTrx] = useState("");
  const [sender, setSender] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  if (loading) return <Loading />;
  if (error || !data) return <ErrorBox msg={error ?? "Failed to load"} />;

  async function createInvoice() {
    setBusy(true); setErr(null);
    try {
      setInvoice(await api("/deposits", { body: { provider: method, amount: Number(amount) } }));
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  }

  async function submitTrx() {
    setBusy(true); setErr(null);
    try {
      // The server decides the outcome; we only navigate to the receipt, which shows the backend's status.
      await api(`/deposits/${invoice.id}/submit`, { body: { trxId: trx, sender: sender || undefined } });
      router.replace(`/wallet/deposits/${invoice.id}`);
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  }

  if (invoice) {
    return (
      <div>
        <h1 className="text-2xl font-bold">Complete your payment</h1>
        <div className="card mt-3 space-y-1">
          <div className="text-sm text-hint">Invoice {invoice.invoiceNo}</div>
          <div className="text-3xl font-extrabold">{money(invoice.amount)}</div>
          <div className="text-sm">Method: <b>{invoice.provider.name}</b></div>
          {invoice.provider.receiverNumber && (
            <div className="mt-2 flex items-center justify-between rounded-xl bg-bg p-3">
              <div><div className="text-xs text-hint">Send to</div><div className="font-mono text-lg font-bold">{invoice.provider.receiverNumber}</div></div>
              <button className="btn-ghost !px-3 !py-1.5 text-sm" onClick={() => navigator.clipboard?.writeText(invoice.provider.receiverNumber)}>Copy</button>
            </div>
          )}
          {invoice.provider.instructions && <p className="whitespace-pre-line pt-2 text-sm text-hint">{invoice.provider.instructions}</p>}
          <p className="pt-2 text-xs text-hint">Send exactly {money(invoice.amount)}. Invoice expires {new Date(invoice.expiresAt).toLocaleTimeString()}.</p>
        </div>
        <div className="card mt-3 space-y-2">
          <label className="text-sm font-semibold">Transaction ID</label>
          <input className="input font-mono uppercase" value={trx} onChange={(e) => setTrx(e.target.value)} placeholder="e.g. 8N7A6D5EE7" />
          <label className="text-sm font-semibold">Your sending number (optional)</label>
          <input className="input" inputMode="tel" value={sender} onChange={(e) => setSender(e.target.value)} />
          <button className="btn w-full" disabled={busy || trx.trim().length < 6} onClick={submitTrx}>{busy ? "Submitting…" : "Submit for verification"}</button>
          <p className="text-xs text-hint">Your balance is only updated after we verify the payment. Submitting an ID does not add funds by itself.</p>
        </div>
        {err && <p className="mt-3 text-center text-sm text-red-500">{err}</p>}
      </div>
    );
  }

  const m = data.methods.find((x: any) => x.code === method);
  const n = Number(amount);
  const valid = m?.available && n > 0 && (!m.min || n >= Number(m.min)) && (!m.max || n <= Number(m.max));

  return (
    <div>
      <h1 className="text-2xl font-bold">Add money</h1>
      <div className="mt-3"><Announcements items={data.notices} /></div>
      <div className="mt-3 grid grid-cols-2 gap-3">
        {data.methods.map((x: any) => (
          <button key={x.code} disabled={!x.available} onClick={() => setMethod(x.code)}
            className={`card text-left ${method === x.code ? "ring-2 ring-brand" : ""} ${!x.available ? "opacity-50" : ""}`}>
            <div className="font-bold">{x.name}</div>
            <div className="text-xs text-hint">
              {x.isFuture ? "Coming soon" : !x.available ? "Unavailable" : x.manualReview ? "Manual review" : "Auto-verified"}
            </div>
          </button>
        ))}
      </div>
      <div className="card mt-3">
        <label className="text-sm font-semibold">Amount</label>
        <input className="input mt-1" inputMode="decimal" placeholder="Enter amount" value={amount} onChange={(e) => setAmount(e.target.value.replace(/[^0-9.]/g, ""))} />
        <div className="mt-2 flex flex-wrap gap-2">
          {PRESETS.map((p) => <button key={p} className="rounded-full bg-bg px-3 py-1 text-sm" onClick={() => setAmount(String(p))}>{money(p)}</button>)}
        </div>
        {m && (m.min || m.max) && <p className="mt-2 text-xs text-hint">Limits: {m.min ? money(m.min) : "—"} to {m.max ? money(m.max) : "—"}</p>}
      </div>
      <button className="btn mt-4 w-full" disabled={!valid || busy} onClick={createInvoice}>{busy ? "Creating…" : "Continue"}</button>
      {err && <p className="mt-3 text-center text-sm text-red-500">{err}</p>}
    </div>
  );
}
