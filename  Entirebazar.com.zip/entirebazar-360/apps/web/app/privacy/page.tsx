import { APP_NAME } from "@/lib/brand";

export default function Privacy() {
  return (
    <article className="space-y-3">
      <h1 className="text-2xl font-bold">Privacy Policy</h1>
      <p className="text-sm text-hint">How {APP_NAME} handles your information.</p>
      <p className="rounded-xl bg-amber-500/15 p-3 text-sm text-amber-700">
        Template text. Replace with a policy reviewed by a qualified lawyer for your jurisdiction before launch.
      </p>
      <h2 className="font-bold">Data we collect</h2>
      <p className="text-hint">Your Telegram ID, name, username and profile photo URL (from Telegram), wallet and order history, and payment transaction references you submit.</p>
      <h2 className="font-bold">How we use it</h2>
      <p className="text-hint">To run your account, verify payments, deliver products, prevent fraud, and send notifications you have enabled.</p>
      <h2 className="font-bold">Your choices</h2>
      <p className="text-hint">You can turn off Telegram notifications in Profile. Contact support to request account data changes.</p>
    </article>
  );
}
