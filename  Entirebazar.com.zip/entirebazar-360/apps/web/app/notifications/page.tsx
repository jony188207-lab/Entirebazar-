"use client";
import { useRouter } from "next/navigation";
import { api, useApi, when } from "@/lib/api";
import { Announcements, ErrorBox, Loading } from "@/components/ui";

const ICON: Record<string, string> = { PAYMENT: "💳", ORDER: "📦", DELIVERY: "🎁", REFUND: "↩️", SUPPORT: "💬", ANNOUNCEMENT: "📣", SYSTEM: "🔔" };

export default function Notifications() {
  const router = useRouter();
  const { data, error, loading, reload } = useApi<any>("/notifications");
  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorBox msg={error ?? "Failed to load"} />;

  async function open(n: any) {
    if (!n.readAt) await api("/notifications/read", { body: { ids: [n.id] } }).catch(() => {});
    // Only follow in-app paths.
    if (n.deepLink?.startsWith("/")) router.push(n.deepLink);
    else reload();
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Notifications {data.unread > 0 && <span className="text-base text-hint">({data.unread})</span>}</h1>
        {data.unread > 0 && (
          <button className="text-sm text-brand" onClick={async () => { await api("/notifications/read", { body: { all: true } }); reload(); }}>Mark all read</button>
        )}
      </div>
      <div className="mt-3"><Announcements items={data.notices} /></div>
      <div className="mt-3 space-y-2">
        {data.items.length === 0 && <p className="py-8 text-center text-hint">You&apos;re all caught up.</p>}
        {data.items.map((n: any) => (
          <button key={n.id} onClick={() => open(n)} className={`card flex w-full gap-3 text-left ${n.readAt ? "opacity-70" : "ring-1 ring-brand/40"}`}>
            <div className="text-2xl">{ICON[n.type] ?? "🔔"}</div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className="font-semibold">{n.title}</span>
                {!n.readAt && <span className="h-2 w-2 rounded-full bg-brand" />}
              </div>
              <div className="text-sm text-hint">{n.body}</div>
              <div className="mt-1 text-xs text-hint">{when(n.createdAt)}</div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
