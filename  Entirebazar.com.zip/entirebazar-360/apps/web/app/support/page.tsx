"use client";
import { useState } from "react";
import { api, useApi, when } from "@/lib/api";
import { Badge, Loading, Section } from "@/components/ui";

export default function Support() {
  const { data, loading, reload } = useApi<any[]>("/support");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  async function send() {
    setBusy(true); setErr(null);
    try {
      await api("/support", { body: { subject, message } });
      setSubject(""); setMessage(""); reload();
    } catch (e: any) { setErr(e.message); } finally { setBusy(false); }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold">Support</h1>
      <div className="card mt-3 space-y-2">
        <input className="input" placeholder="Subject" value={subject} onChange={(e) => setSubject(e.target.value)} />
        <textarea className="input" rows={4} placeholder="Describe your issue (include invoice/order numbers)" value={message} onChange={(e) => setMessage(e.target.value)} />
        <button className="btn w-full" disabled={busy || subject.length < 3 || message.length < 5} onClick={send}>Send</button>
        {err && <p className="text-sm text-red-500">{err}</p>}
      </div>
      <Section title="Your tickets">
        {loading ? <Loading /> : (
          <div className="space-y-2">
            {(data ?? []).length === 0 && <p className="text-hint">No tickets yet.</p>}
            {(data ?? []).map((t) => (
              <div key={t.id} className="card">
                <div className="flex items-center justify-between"><span className="font-semibold">{t.subject}</span><Badge s={t.status === "OPEN" ? "PENDING" : "SUCCESSFUL"} /></div>
                <p className="text-sm text-hint">{t.message}</p>
                {t.reply && <p className="mt-2 rounded-xl bg-bg p-2 text-sm"><b>Support:</b> {t.reply}</p>}
                <div className="mt-1 text-xs text-hint">{when(t.createdAt)}</div>
              </div>
            ))}
          </div>
        )}
      </Section>
    </div>
  );
}
