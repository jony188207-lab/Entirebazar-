"use client";
import Link from "next/link";
import { money, useApi } from "@/lib/api";
import { ErrorBox, Loading, Section } from "@/components/ui";
import { Banners, CategoryCards, Notices, ProductGrid, SupportInfo } from "@/components/blocks";
import { Bell } from "@/components/Shell";

export default function Home() {
  const { data, error, loading } = useApi<any>("/home");
  if (loading) return <Loading />;
  if (error || !data) return <ErrorBox msg={error ?? "Failed to load"} />;

  // The order and visibility of these blocks is configured by administrators (Settings → Homepage).
  const blocks: Record<string, React.ReactNode> = {
    BANNERS: data.banners?.length ? <div key="b" className="mt-4"><Banners items={data.banners} /></div> : null,
    NOTICES: data.announcements?.length ? <div key="n" className="mt-4"><Notices items={data.announcements} /></div> : null,
    FEATURED_CATEGORIES: data.featuredCategories?.length ? (
      <Section key="fc" title="Featured categories"><CategoryCards items={data.featuredCategories} /></Section>
    ) : null,
    FEATURED_PRODUCTS: data.featured?.length ? (
      <Section key="fp" title="Featured" action={<Link href="/shop?featured=true" className="text-sm text-brand">See all</Link>}>
        <ProductGrid items={data.featured.slice(0, 6)} />
      </Section>
    ) : null,
    BEST_SELLING: data.bestSelling?.length ? (
      <Section key="bs" title="Best selling" action={<Link href="/shop?sort=popular" className="text-sm text-brand">See all</Link>}>
        <ProductGrid items={data.bestSelling.slice(0, 6)} />
      </Section>
    ) : null,
    CATEGORY_GRID: data.categories?.length ? <Section key="cg" title="Browse categories"><CategoryCards items={data.categories} /></Section> : null,
  };

  return (
    <div className="pb-4">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="h-11 w-11 overflow-hidden rounded-full bg-line">
            {/* Telegram profile photo (https://t.me/...) is supplied by Telegram itself */}
            {data.user.photoUrl && <img src={data.user.photoUrl} alt="" className="h-full w-full object-cover" referrerPolicy="no-referrer" />}
          </div>
          <div>
            <div className="font-bold">{data.user.firstName ?? "Welcome"}</div>
            {data.user.username && <div className="text-sm text-hint">@{data.user.username}</div>}
          </div>
        </div>
        <Bell />
      </header>

      <div className="card mt-4">
        <div className="text-sm text-hint">Wallet balance</div>
        <div className="text-3xl font-extrabold">{money(data.balance)}</div>
        <div className="mt-3 grid grid-cols-3 gap-2">
          <Link href="/wallet/add" className="btn !px-2 !py-2 text-sm">＋ Add Money</Link>
          <Link href="/shop" className="btn-ghost !px-2 !py-2 text-sm">Shop</Link>
          <Link href="/orders" className="btn-ghost !px-2 !py-2 text-sm">My Orders</Link>
        </div>
      </div>

      {(data.layout as { id: string; enabled: boolean }[]).filter((b) => b.enabled).map((b) => blocks[b.id])}

      {data.contact && (data.contact.telegramUsername || data.contact.email || data.contact.phone) && (
        <div className="mt-6"><SupportInfo contact={data.contact} /></div>
      )}
    </div>
  );
}
