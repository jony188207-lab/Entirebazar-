"use client";
import { useState } from "react";
import { useParams } from "next/navigation";
import { useApi } from "@/lib/api";
import { ErrorBox, Loading } from "@/components/ui";
import { CategoryView, CategoryQuery } from "@/components/CategoryView";

export default function CategoryPage() {
  const { slug } = useParams<{ slug: string }>();
  const [query, setQuery] = useState<CategoryQuery>({ q: "", sort: "", inStock: false, page: 1 });
  const params = new URLSearchParams();
  if (query.q) params.set("q", query.q);
  if (query.sort) params.set("sort", query.sort.toLowerCase());
  if (query.inStock) params.set("inStock", "true");
  if (query.page > 1) params.set("page", String(query.page));
  const { data, error, loading } = useApi<any>(`/categories/${encodeURIComponent(slug)}?${params}`);

  if (loading && !data) return <Loading />;
  if (error || !data) return <ErrorBox msg={error ?? "Category not found"} />;
  return <CategoryView page={data} query={{ ...query, sort: query.sort || data.settings.sorting.default }} onQuery={(q) => setQuery((p) => ({ ...p, ...q }))} />;
}
