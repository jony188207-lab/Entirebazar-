"use client";
import { Suspense, useState } from "react";
import { useSearchParams } from "next/navigation";
import { useApi } from "@/lib/api";
import { ErrorBox, Loading } from "@/components/ui";
import { Notices, ProductGrid } from "@/components/blocks";

function ShopInner() {
  const sp = useSearchParams();
  const [q, setQ] = useState(sp.get("q") ?? "");
  const [category, setCategory] = useState(sp.get("category") ?? "");
  const [sort, setSort] = useState(sp.get("sort") ?? "new");
  const [inStock, setInStock] = useState(false);
  const featured = sp.get("featured") === "true";

  const params = new URLSearchParams({ sort });
  if (q) params.set("q", q);
  if (category) params.set("category", category);
  if (featured) params.set("featured", "true");
  if (inStock) params.set("inStock", "true");

  const cats = useApi<any[]>("/categories");
  const { data, error, loading } = useApi<any>(`/products?${params}`);
  const top = (cats.data ?? []).filter((c) => !c.parentId);

  return (
    <div>
      <h1 className="text-2xl font-bold">Shop</h1>
      <input className="input mt-3" placeholder="Search products…" value={q} onChange={(e) => setQ(e.target.value)} />
      <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
        {[{ slug: "", name: "All", icon: null }, ...top].map((c) => (
          <button key={c.slug} onClick={() => setCategory(c.slug)}
            className={`whitespace-nowrap rounded-full px-3 py-1.5 text-sm ${category === c.slug ? "bg-brand text-brandfg" : "bg-card"}`}>
            {c.icon ? `${c.icon} ` : ""}{c.name}
          </button>
        ))}
      </div>
      <div className="mt-3 flex items-center gap-3 text-sm">
        <select className="rounded-lg bg-card px-2 py-1.5" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="new">Newest</option>
          <option value="popular">Popular</option>
          <option value="price_asc">Price: low → high</option>
          <option value="price_desc">Price: high → low</option>
        </select>
        <label className="flex items-center gap-1.5"><input type="checkbox" checked={inStock} onChange={(e) => setInStock(e.target.checked)} /> In stock</label>
      </div>
      <div className="mt-3"><Notices items={data?.notices} /></div>
      {loading && !data ? <Loading /> : error ? <ErrorBox msg={error} /> : (
        <div className="mt-3">
          <ProductGrid items={data.items} />
          {data.items.length === 0 && <p className="py-8 text-center text-hint">No products found.</p>}
        </div>
      )}
    </div>
  );
}

export default function Shop() {
  return <Suspense fallback={<Loading />}><ShopInner /></Suspense>;
}
