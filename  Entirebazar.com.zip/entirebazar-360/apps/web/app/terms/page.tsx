import { APP_NAME } from "@/lib/brand";

export default function Terms() {
  return (
    <article className="space-y-3">
      <h1 className="text-2xl font-bold">Terms of Service</h1>
      <p className="text-sm text-hint">These terms apply to your use of {APP_NAME}.</p>
      <p className="rounded-xl bg-amber-500/15 p-3 text-sm text-amber-700">
        Template text. Replace with terms reviewed by a qualified lawyer for your jurisdiction before launch.
      </p>
      <h2 className="font-bold">1. Wallet</h2>
      <p className="text-hint">Wallet balance is credited only after a deposit is verified. Balances are recorded in an auditable ledger. Wallet funds are used for purchases on {APP_NAME}.</p>
      <h2 className="font-bold">2. Digital products</h2>
      <p className="text-hint">Products are delivered digitally after purchase. Delivered keys and files cannot be returned once used.</p>
      <h2 className="font-bold">3. Refunds</h2>
      <p className="text-hint">Refund requests are reviewed individually. Approved refunds are returned to your wallet.</p>
      <h2 className="font-bold">4. Account restrictions</h2>
      <p className="text-hint">We may restrict accounts involved in fraud, chargebacks, or abuse.</p>
    </article>
  );
}
