"use client";
import { Suspense, useEffect, useRef, useState } from "react";
import { useParams, useRouter, useSearchParams } from "next/navigation";
import { api, money, newRef, useApi } from "@/lib/api";
import { ErrorBox, Loading, Section } from "@/components/ui";
import { ActionButtons, FaqList, Md, Notices, Price, SafeImg, confirmAsk } from "@/components/blocks";

const TYPE_LABEL: Record<string, string> = {
  DIGITAL: "Digital product", SUBSCRIPTION: "Subscription", LICENSE_KEY: "License key", SERVICE_PACKAGE: "Service package", DOWNLOADABLE: "Downloadable", MANUAL: "Fulfilled by our team",
};

function ProductInner() {
  const { id } = useParams<{ id: string }>();
  const sp = useSearchParams();
  const router = useRouter();
  const { data: p, error, loading, reload } = useApi<any>(`/products/${id}`);
  const [qty, setQty] = useState(1);
  const [variantId, setVariantId] = useState<string | null>(sp.get("variant"));
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);
  const buyRef = useRef<HTMLDivElement>(null);
  // One idempotency key per distinct purchase intent: a double tap or network retry can never create two orders.
  const intent = useRef<{ sig: string; ref: string } | null>(null);

  useEffect(() => {
    if (p && !variantId && p.variants?.length === 1) setVariantId(p.variants[0].id);
  }, [p, variantId]);
  useEffect(() => {
    if (p && sp.get("buy") === "1") buyRef.current?.scrollIntoView({ block: "center" });
  }, [p, sp]);

  if (loading && !p) return <Loading />;
  if (error || !p) return <ErrorBox msg={error ?? "Not found"} />;

  const variant = p.variants?.find((v: any) => v.id === variantId) ?? null;
  const needVariant = p.variants?.length > 0;
  const unit = Number(variant ? variant.price : p.price);
  const inStock = variant ? variant.inStock : p.inStock;
  const stock = variant ? variant.stock : p.stock;
  const canBuy = p.purchasable && inStock && (!needVariant || !!variant) && (!p.inputLabel || input.trim().length > 0);

  async function buy() {
    if (!canBuy) return;
    const text = `Buy ${qty} × ${p.name}${variant ? ` (${variant.name})` : ""} for ${money(unit * qty)} from your wallet?`;
    if (!(await confirmAsk(text))) return;
    const sig = JSON.stringify([p.id, variantId, qty, input.trim()]);
    if (!intent.current || intent.current.sig !== sig) intent.current = { sig, ref: newRef() };
    setBusy(true);
    setMsg(null);
    try {
      const o = await api("/orders", { body: { items: [{ productId: p.id, variantId: variantId ?? undefined, quantity: qty, input: input.trim() || undefined }], clientRef: intent.current.ref } });
      router.push(`/orders/${o.id}`);
    } catch (e: any) {
      setMsg(e.message);
      reload();
    } finally {
      setBusy(false);
    }
  }

  async function toggleWish() {
    await api(`/products/${id}/wishlist`, { method: "POST", body: {} });
    reload();
  }

  return (
    <div className="pb-32">
      <div className="aspect-video overflow-hidden rounded-2xl bg-line"><SafeImg src={p.imageUrl} alt={p.name} className="h-full w-full object-cover" /></div>
      <div className="mt-3 flex items-start justify-between gap-3">
        <h1 className="text-2xl font-bold">{p.name}</h1>
        <button onClick={toggleWish} className="text-2xl" aria-label="Wishlist">{p.wishlisted ? "❤️" : "🤍"}</button>
      </div>
      <div className="text-xs text-hint">{TYPE_LABEL[p.productType] ?? ""}</div>
      <div className="mt-1 flex items-center gap-3">
        <Price p={variant ? { ...p, price: variant.price, originalPrice: variant.originalPrice, discounted: variant.discounted, hasVariants: false } : p} big />
        <span className={inStock ? "text-emerald-600" : "text-red-500"}>{inStock ? (stock === null ? "Available" : `${stock} in stock`) : "Out of stock"}</span>
      </div>
      {p.reviewCount > 0 && <div className="text-sm text-hint">★ {Number(p.rating).toFixed(1)} · {p.reviewCount} reviews</div>}
      {p.unavailableMessage && <div className="mt-3 rounded-xl bg-amber-500/15 p-3 text-sm text-amber-700">{p.unavailableMessage}</div>}
      <div className="mt-3"><Notices items={p.notices} /></div>
      {p.buttons?.length > 0 && <div className="mt-3"><ActionButtons buttons={p.buttons} /></div>}

      <div ref={buyRef}>
        {needVariant && (
          <Section title="Choose an option">
            <div className="grid gap-2">
              {p.variants.map((v: any) => (
                <button key={v.id} disabled={!v.inStock} onClick={() => setVariantId(v.id)}
                  className={`flex items-center justify-between rounded-xl border px-3 py-3 text-left ${variantId === v.id ? "border-brand bg-brand/10" : "border-line bg-card"} disabled:opacity-50`}>
                  <span className="font-medium">{v.name}{!v.inStock && " · sold out"}</span>
                  <span className="font-bold text-brand">{money(v.price)} {v.discounted && <s className="ml-1 text-xs font-normal text-hint">{money(v.originalPrice)}</s>}</span>
                </button>
              ))}
            </div>
          </Section>
        )}
        {p.inputLabel && (
          <Section title={p.inputLabel}>
            <input className="input" maxLength={200} value={input} onChange={(e) => setInput(e.target.value)} placeholder={`Enter your ${p.inputLabel.toLowerCase()}`} />
            <p className="mt-1 text-xs text-hint">Double-check this: our team uses it to complete your order.</p>
          </Section>
        )}
      </div>

      <Section title="Description"><Md text={p.description} className="text-hint" /></Section>
      {p.features?.length > 0 && <Section title="Features"><ul className="space-y-1">{p.features.map((f: string, i: number) => <li key={i}>✔️ {f}</li>)}</ul></Section>}
      {p.deliveryInstructions && <Section title="Delivery"><Md text={p.deliveryInstructions} className="text-sm text-hint" /></Section>}
      {p.faq?.length > 0 && <Section title="FAQ"><FaqList items={p.faq} /></Section>}

      <Section title="Reviews">
        {p.reviews.length === 0 ? <p className="text-hint">No reviews yet.</p> : (
          <div className="space-y-2">
            {p.reviews.map((r: any) => (
              <div key={r.id} className="card">
                <div className="text-sm font-semibold">{r.user.firstName ?? r.user.username ?? "Customer"} · {"★".repeat(r.rating)}</div>
                {r.comment && <p className="text-sm text-hint">{r.comment}</p>}
              </div>
            ))}
          </div>
        )}
      </Section>

      <div className="fixed inset-x-0 bottom-[calc(64px+env(safe-area-inset-bottom))] border-t border-line bg-card p-3">
        <div className="mx-auto flex max-w-xl items-center gap-3">
          <div className="flex items-center gap-2">
            <button className="btn-ghost !px-3 !py-2" onClick={() => setQty(Math.max(1, qty - 1))}>−</button>
            <span className="w-6 text-center font-bold">{qty}</span>
            <button className="btn-ghost !px-3 !py-2" onClick={() => setQty(Math.min(10, qty + 1))}>＋</button>
          </div>
          <button className="btn flex-1" disabled={busy || !canBuy} onClick={buy}>
            {busy ? "Processing…" : !p.purchasable ? "Unavailable" : !inStock ? "Out of stock" : needVariant && !variant ? "Choose an option" : p.inputLabel && !input.trim() ? `Enter ${p.inputLabel}` : `Buy Now · ${money(unit * qty)}`}
          </button>
        </div>
        {msg && <p className="mt-2 text-center text-sm text-red-500">{msg}</p>}
      </div>
    </div>
  );
}

export default function ProductPage() {
  return <Suspense fallback={<Loading />}><ProductInner /></Suspense>;
}
