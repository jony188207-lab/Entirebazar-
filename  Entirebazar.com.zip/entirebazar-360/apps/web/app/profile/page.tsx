"use client";
import Link from "next/link";
import { api, money, useApi } from "@/lib/api";
import { ErrorBox, Loading, Section } from "@/components/ui";

export default function Profile() {
  const { data: me, error, loading, reload } = useApi<any>("/me");
  if (loading && !me) return <Loading />;
  if (error || !me) return <ErrorBox msg={error ?? "Failed to load"} />;

  async function toggle(key: "payments" | "orders" | "promos") {
    await api("/me/preferences", { method: "PATCH", body: { [key]: !me.prefs[key] } });
    reload();
  }
  const Row = ({ k, label }: { k: "payments" | "orders" | "promos"; label: string }) => (
    <label className="flex items-center justify-between py-2">
      <span>{label}</span>
      <input type="checkbox" className="h-5 w-5" checked={me.prefs[k]} onChange={() => toggle(k)} />
    </label>
  );

  return (
    <div>
      <div className="card flex items-center gap-3">
        <div className="h-14 w-14 overflow-hidden rounded-full bg-line">{me.photoUrl && <img src={me.photoUrl} alt="" className="h-full w-full object-cover" />}</div>
        <div>
          <div className="text-lg font-bold">{[me.firstName, me.lastName].filter(Boolean).join(" ") || "Customer"}</div>
          {me.username && <div className="text-sm text-hint">@{me.username}</div>}
          <div className="text-xs text-hint">Telegram ID {me.telegramId}</div>
        </div>
      </div>
      {me.status !== "ACTIVE" && <div className="card mt-3 text-amber-600">Your account is {me.status.toLowerCase()}. Contact support.</div>}

      <div className="card mt-3 flex items-center justify-between">
        <div><div className="text-sm text-hint">Wallet balance</div><div className="text-2xl font-extrabold">{money(me.balance)}</div></div>
        <Link href="/wallet" className="btn-ghost !py-2">Open</Link>
      </div>
      <div className="mt-3 grid grid-cols-2 gap-3">
        <Link href="/orders" className="btn-ghost">Orders</Link>
        <Link href="/wallet" className="btn-ghost">Transactions</Link>
      </div>

      <Section title="Notification preferences">
        <div className="card divide-y divide-line">
          <Row k="payments" label="Payments & refunds" />
          <Row k="orders" label="Orders & delivery" />
          <Row k="promos" label="Announcements & promotions" />
        </div>
        <p className="mt-1 text-xs text-hint">In-app notifications are always kept; these control Telegram messages.</p>
      </Section>

      <Section title="More">
        <div className="card divide-y divide-line">
          <Link href="/support" className="block py-2">💬 Support</Link>
          <Link href="/terms" className="block py-2">📄 Terms of Service</Link>
          <Link href="/privacy" className="block py-2">🔒 Privacy Policy</Link>
        </div>
      </Section>
    </div>
  );
}
