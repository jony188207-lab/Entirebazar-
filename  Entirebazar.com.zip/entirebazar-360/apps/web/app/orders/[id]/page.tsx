"use client";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useState } from "react";
import { api, money, tg, useApi, when } from "@/lib/api";
import { Announcements, Badge, ErrorBox, Loading, Section } from "@/components/ui";

export default function OrderDetail() {
  const { id } = useParams<{ id: string }>();
  const { data: o, error, loading, reload } = useApi<any>(`/orders/${id}`);
  const [reason, setReason] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  if (loading && !o) return <Loading />;
  if (error || !o) return <ErrorBox msg={error ?? "Not found"} />;

  async function requestRefund() {
    try {
      await api(`/orders/${id}/refund-request`, { body: { reason } });
      setMsg("Refund requested. We'll notify you of the decision.");
      reload();
    } catch (e: any) { setMsg(e.message); }
  }
  const copy = (t: string) => { navigator.clipboard?.writeText(t); tg()?.HapticFeedback?.notificationOccurred("success"); };

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-mono text-xl font-bold">{o.orderNo}</h1>
        <Badge s={o.status} />
      </div>
      <div className="text-sm text-hint">{when(o.createdAt)} · Total {money(o.total)}</div>
      <div className="mt-3"><Announcements items={o.notices} /></div>

      <Section title="Items">
        <div className="space-y-2">
          {o.items.map((i: any) => (
            <div key={i.id} className="card">
              <div className="font-semibold">{i.quantity}× {i.productName ?? i.product.name}{i.variantName ? ` · ${i.variantName}` : ""}</div>
              {i.customerInput && <div className="text-xs text-hint">Your input: <span className="font-mono">{i.customerInput}</span></div>}
              {i.deliveredData ? (
                <div className="mt-2 rounded-xl bg-bg p-3">
                  <div className="text-xs text-hint">Your delivery</div>
                  <pre className="whitespace-pre-wrap break-all font-mono text-sm">{i.deliveredData}</pre>
                  {/^https:\/\/\S+$/.test(i.deliveredData) && (
                    <a className="btn mt-2 block text-center" href={i.deliveredData} target="_blank" rel="noopener noreferrer">Download</a>
                  )}
                  <button className="btn-ghost mt-2 !py-1.5 text-sm" onClick={() => copy(i.deliveredData)}>Copy</button>
                </div>
              ) : (
                <div className="mt-1 text-sm text-amber-600">{o.status === "PROCESSING" ? "Our team is preparing this order by hand. You'll be notified as soon as it's delivered." : "Being prepared — you'll be notified when it's delivered."}</div>
              )}
            </div>
          ))}
        </div>
      </Section>

      <Section title="Refund & support">
        {o.refundStatus !== "NONE" ? (
          <div className="card text-sm">Refund status: <b>{o.refundStatus}</b></div>
        ) : o.status !== "REFUNDED" && o.status !== "CANCELLED" ? (
          <div className="card space-y-2">
            <textarea className="input" rows={2} placeholder="Why are you requesting a refund?" value={reason} onChange={(e) => setReason(e.target.value)} />
            <button className="btn-ghost w-full" disabled={reason.trim().length < 3} onClick={requestRefund}>Request refund</button>
          </div>
        ) : null}
        {msg && <p className="mt-2 text-sm text-hint">{msg}</p>}
        <Link href="/support" className="btn-ghost mt-3 block">Contact support</Link>
      </Section>
    </div>
  );
}
