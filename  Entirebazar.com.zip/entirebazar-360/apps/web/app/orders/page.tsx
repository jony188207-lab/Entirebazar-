"use client";
import Link from "next/link";
import { money, useApi, when } from "@/lib/api";
import { Badge, ErrorBox, Loading } from "@/components/ui";

export default function Orders() {
  const { data, error, loading } = useApi<any[]>("/orders");
  if (loading) return <Loading />;
  if (error || !data) return <ErrorBox msg={error ?? "Failed to load"} />;
  return (
    <div>
      <h1 className="text-2xl font-bold">My orders</h1>
      <div className="mt-3 space-y-2">
        {data.length === 0 && <p className="py-8 text-center text-hint">No orders yet.</p>}
        {data.map((o) => (
          <Link key={o.id} href={`/orders/${o.id}`} className="card block">
            <div className="flex items-center justify-between">
              <span className="font-mono font-semibold">{o.orderNo}</span>
              <Badge s={o.status} />
            </div>
            <div className="mt-1 text-sm text-hint">{o.items.map((i: any) => `${i.quantity}× ${i.product.name}`).join(", ")}</div>
            <div className="mt-1 flex justify-between text-sm">
              <span className="font-bold">{money(o.total)}</span>
              <span className="text-hint">{when(o.createdAt)}</span>
            </div>
            {o.refundStatus !== "NONE" && <div className="mt-1 text-xs text-purple-600">Refund: {o.refundStatus}</div>}
          </Link>
        ))}
      </div>
    </div>
  );
}
