// Single source of truth for the app's visible name and brand colors.
export const APP_NAME = "EntireBazar 360";
export const APP_TAGLINE = "Your complete digital marketplace";
export const BRAND_NAVY = "#0B1B3A";
