"use client";
import { useCallback, useEffect, useState } from "react";

// Inlined at BUILD time. In production there is deliberately no localhost fallback (next.config.mjs fails the build if it is missing).
const API = (process.env.NEXT_PUBLIC_API_URL ?? (process.env.NODE_ENV === "production" ? "" : "http://localhost:4000")).replace(/\/+$/, "");

declare global {
  interface Window {
    Telegram?: { WebApp: any };
  }
}

export const tg = () => (typeof window !== "undefined" ? window.Telegram?.WebApp : undefined);
/** Uploaded images are `/uploads/<name>`; external images must be https. Anything else (javascript:, data:, relative junk) yields null. */
export const assetUrl = (u?: string | null) => {
  if (!u) return null;
  if (/^\/uploads\/[a-f0-9]{32}\.(png|jpg|webp)$/.test(u)) return API + u;
  if (/^https:\/\//i.test(u)) return u;
  return null;
};

// Tokens live in memory only (never localStorage): a fresh signed initData is exchanged on every launch.
const tokens: { user?: string; admin?: string } = {};

export class ApiError extends Error {
  constructor(message: string, public status: number, public code?: string, public details?: any) {
    super(message);
  }
}

/** Idempotency key for purchases: the server collapses retries carrying the same key into one order. */
export function newRef(): string {
  const c: Crypto | undefined = typeof crypto !== "undefined" ? crypto : undefined;
  if (c?.randomUUID) return c.randomUUID().replace(/-/g, "");
  return Array.from({ length: 32 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
}

/** Turns zod "details" from the API into a short readable list. */
export function fieldErrors(e: unknown): string[] {
  const d: any = (e as any)?.details;
  if (!d) return [];
  const out: string[] = [];
  for (const m of d.formErrors ?? []) out.push(String(m));
  for (const [k, v] of Object.entries<any>(d.fieldErrors ?? {})) for (const m of v ?? []) out.push(`${k}: ${m}`);
  return out;
}

async function login(kind: "user" | "admin") {
  const initData = tg()?.initData;
  if (!initData) throw new ApiError("Open this app from inside Telegram", 401);
  const res = await fetch(`${API}/api${kind === "admin" ? "/admin" : ""}/auth/telegram`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ initData }),
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(json.error ?? "Login failed", res.status);
  tokens[kind] = json.token;
}

export async function api<T = any>(
  path: string,
  opts: { method?: string; body?: unknown; admin?: boolean; retry?: boolean } = {}
): Promise<T> {
  const kind = opts.admin ? "admin" : "user";
  if (!tokens[kind]) await login(kind);
  const res = await fetch(`${API}/api${opts.admin ? "/admin" : ""}${path}`, {
    method: opts.method ?? (opts.body !== undefined ? "POST" : "GET"),
    headers: { "content-type": "application/json", authorization: `Bearer ${tokens[kind]}` },
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });
  if (res.status === 401 && !opts.retry && !path.startsWith("/auth/")) {
    tokens[kind] = undefined;
    return api<T>(path, { ...opts, retry: true });
  }
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(json.error ?? `Request failed (${res.status})`, res.status, json.code, json.details);
  return json as T;
}

export async function adminUpload(fd: FormData): Promise<{ url: string }> {
  if (!tokens.admin) await login("admin");
  const res = await fetch(`${API}/api/admin/upload`, { method: "POST", headers: { authorization: `Bearer ${tokens.admin}` }, body: fd });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(json.error ?? "Upload failed", res.status, json.code);
  return json;
}

export async function adminUploadFile(fd: FormData): Promise<{ ref: string }> {
  if (!tokens.admin) await login("admin");
  const res = await fetch(`${API}/api/admin/upload-file`, { method: "POST", headers: { authorization: `Bearer ${tokens.admin}` }, body: fd });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(json.error ?? "Upload failed", res.status, json.code);
  return json;
}

export async function publicApi<T = any>(path: string): Promise<T> {
  const res = await fetch(`${API}/api${path}`);
  return res.json();
}

export function useApi<T = any>(path: string | null, admin = false) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(!!path);
  const load = useCallback(async () => {
    if (!path) return;
    setLoading(true);
    try {
      setData(await api<T>(path, { admin }));
      setError(null);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [path, admin]);
  useEffect(() => {
    void load();
  }, [load]);
  return { data, error, loading, reload: load, setData };
}

export const money = (v: string | number | null | undefined) =>
  `৳${Number(v ?? 0).toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
export const when = (d: string) => new Date(d).toLocaleString();
