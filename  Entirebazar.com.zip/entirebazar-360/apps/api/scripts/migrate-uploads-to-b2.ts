/**
 * Moves legacy local uploads (UPLOAD_DIR/<32hex>.png|jpg|webp) to the public B2 bucket and (optionally) rewrites database references.
 *
 *   npx tsx scripts/migrate-uploads-to-b2.ts            # dry run: lists what would be uploaded
 *   npx tsx scripts/migrate-uploads-to-b2.ts --apply    # upload files (idempotent: same key, same bytes)
 *   npx tsx scripts/migrate-uploads-to-b2.ts --apply --rewrite   # also replace "/uploads/<name>" with the B2 URL in the database
 *
 * Old references keep working WITHOUT --rewrite: the API redirects /uploads/<name> to B2 once the object exists.
 * Take a database backup before --rewrite. Run with STORAGE_DRIVER=b2 and the B2_* variables set.
 */
import fs from "fs";
import path from "path";
import { prisma } from "../src/db";
import { config } from "../src/config";
import { sniffImage } from "../src/lib/upload";
import { publicUrl, b2Configured } from "../src/lib/storage";
import { presign, encodeKeyPath } from "../src/lib/s3sign";

const apply = process.argv.includes("--apply");
const rewrite = process.argv.includes("--rewrite");
const NAME = /^[a-f0-9]{32}\.(png|jpg|webp)$/;

async function upload(name: string, buf: Buffer, mime: string) {
  const b = config.b2;
  const url = presign({ method: "PUT", host: b.endpoint, path: `/${encodeURIComponent(b.publicBucket)}/${encodeKeyPath(`img/${name}`)}`, region: b.region, accessKeyId: b.keyId, secretAccessKey: b.appKey, expiresSeconds: 300 });
  const r = await fetch(url, { method: "PUT", body: new Uint8Array(buf), headers: { "Content-Type": mime, "Cache-Control": "public, max-age=31536000, immutable" } });
  if (!r.ok) throw new Error(`upload ${name} failed: HTTP ${r.status}`);
}

async function main() {
  if (apply && !b2Configured()) throw new Error("B2 is not configured (B2_S3_ENDPOINT, B2_REGION, B2_KEY_ID, B2_APPLICATION_KEY, B2_PUBLIC_BUCKET, B2_PUBLIC_BASE_URL)");
  const files = fs.existsSync(config.uploadDir) ? fs.readdirSync(config.uploadDir).filter((n) => NAME.test(n)) : [];
  console.log(`${files.length} legacy file(s) in ${config.uploadDir}`);
  let ok = 0, bad = 0;
  for (const name of files) {
    const buf = fs.readFileSync(path.join(config.uploadDir, name));
    const kind = sniffImage(buf);
    if (!kind) { console.warn(`skip ${name}: not a PNG/JPEG/WebP`); bad++; continue; }
    if (!apply) { console.log(`would upload ${name}`); continue; }
    await upload(name, buf, kind.mime);
    ok++;
  }
  console.log(apply ? `uploaded ${ok}, skipped ${bad}` : "dry run only (add --apply)");

  if (apply && rewrite) {
    const base = publicUrl("img/").replace(/\/$/, "");
    const like = "%/uploads/%";
    // String columns: only exact "/uploads/<hex>.<ext>" values are replaced.
    const exact = (col: string, tbl: string) =>
      prisma.$executeRawUnsafe(`UPDATE "${tbl}" SET "${col}" = $1 || '/' || substr("${col}", 10) WHERE "${col}" ~ '^/uploads/[a-f0-9]{32}\\.(png|jpg|webp)$'`, base);
    console.log("Category.imageUrl", await exact("imageUrl", "Category"));
    console.log("Category.coverUrl", await exact("coverUrl", "Category"));
    console.log("Product.imageUrl", await exact("imageUrl", "Product"));
    console.log("Announcement.imageUrl", await exact("imageUrl", "Announcement"));
    // JSON columns: replace the quoted path prefix inside text, then re-cast. Only matches the strict upload shape.
    for (const [tbl, col] of [["Category", "settings"], ["CategorySection", "config"], ["ActionButton", "target"], ["AppSetting", "value"]] as const) {
      const n = await prisma.$executeRawUnsafe(
        `UPDATE "${tbl}" SET "${col}" = regexp_replace("${col}"::text, '"/uploads/([a-f0-9]{32}\\.(png|jpg|webp))"', '"' || $1 || '/\\1"', 'g')::jsonb WHERE "${col}"::text LIKE $2`, base, like);
      console.log(`${tbl}.${col}`, n);
    }
  }
}
main().catch((e) => { console.error(e.message); process.exit(1); }).finally(() => prisma.$disconnect());
