import { Telegraf, Markup } from "telegraf";
import { config } from "../config";
import { prisma } from "../db";

/**
 * Bot process: `npm run bot -w apps/api`.
 * Outbound notifications (payments, orders, delivery, refunds, admin alerts) are sent by the API
 * via services/notify.ts; this process only handles inbound commands.
 */
const bot = new Telegraf(config.botToken);
const open = (path = "") => Markup.inlineKeyboard([[Markup.button.webApp(`Open ${config.appName}`, config.miniAppUrl.replace(/\/$/, "") + path)]]);

bot.start((ctx) =>
  ctx.reply(`Welcome to ${config.appName}! Browse digital products, top up your wallet, and track orders in the app.`, open())
);

bot.help((ctx) =>
  ctx.reply("Commands:\n/start – open the app\n/balance – wallet balance\n/orders – recent orders\n/support – contact support", open("/support"))
);

bot.command("support", (ctx) => ctx.reply("Open Support in the app to create a ticket:", open("/support")));

bot.command("balance", async (ctx) => {
  const u = await prisma.user.findUnique({ where: { telegramId: BigInt(ctx.from.id) }, include: { wallet: true } });
  if (!u?.wallet) return ctx.reply("Open the app once to create your wallet.", open());
  await ctx.reply(`Your balance: ${u.wallet.balance}`, open("/wallet"));
});

bot.command("orders", async (ctx) => {
  const u = await prisma.user.findUnique({ where: { telegramId: BigInt(ctx.from.id) } });
  if (!u) return ctx.reply("Open the app once to get started.", open());
  const orders = await prisma.order.findMany({ where: { userId: u.id }, orderBy: { createdAt: "desc" }, take: 5 });
  if (!orders.length) return ctx.reply("No orders yet.", open("/shop"));
  await ctx.reply(orders.map((o) => `${o.orderNo} • ${o.total} • ${o.status}`).join("\n"), open("/orders"));
});

// If a user blocks the bot, remember it so we stop pushing messages (in-app notifications continue).
bot.on("my_chat_member", async (ctx) => {
  const status = ctx.myChatMember.new_chat_member.status;
  if (ctx.chat.type !== "private") return;
  await prisma.user.updateMany({ where: { telegramId: BigInt(ctx.chat.id) }, data: { botBlocked: status === "kicked" } });
});

bot.catch((err) => console.error("[bot]", err));

// Optional: keep the bot's public display name/description in sync with the brand. Off by default;
// the bot USERNAME is never touched. Telegram rate-limits these calls, so failures are only logged.
async function syncProfile() {
  if (!config.syncBotProfile) return;
  try {
    await bot.telegram.setMyName(config.appName);
    await bot.telegram.setMyShortDescription(`${config.appName} — your complete digital marketplace`);
    await bot.telegram.setMyDescription(`${config.appName}: browse digital products, top up your wallet and get instant delivery.`);
  } catch (e) {
    console.warn("[bot] profile sync skipped:", (e as Error).message);
  }
}

bot.launch().then(() => console.log("Bot started"));
void syncProfile();
process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
