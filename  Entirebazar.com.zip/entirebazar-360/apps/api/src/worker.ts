import { runDepositMaintenance } from "./services/deposits";
import { runDueBroadcasts } from "./services/broadcast";

/** Run as a separate process: `npm run worker -w apps/api`. Safe to run one instance. */
async function tick(name: string, fn: () => Promise<void>) {
  try {
    await fn();
  } catch (e) {
    console.error(`[worker:${name}]`, e);
  }
}

setInterval(() => void tick("deposits", runDepositMaintenance), 60_000);
setInterval(() => void tick("broadcasts", runDueBroadcasts), 30_000);
console.log("Worker started");
