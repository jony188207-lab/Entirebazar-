import { PrismaClient } from "@prisma/client";

// Allow BigInt (telegramId) to be serialised in JSON responses.
(BigInt.prototype as any).toJSON = function () {
  return this.toString();
};

export const prisma = new PrismaClient();
