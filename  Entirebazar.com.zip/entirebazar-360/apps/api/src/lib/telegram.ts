import { config } from "../config";

export type SendResult =
  | { ok: true }
  | { ok: false; blocked: boolean; retryAfter?: number; error: string };

/** Thin wrapper over the documented Telegram Bot API sendMessage method. */
export async function sendTelegramMessage(
  chatId: string | number | bigint,
  text: string,
  openPath?: string
): Promise<SendResult> {
  const body: Record<string, unknown> = {
    chat_id: chatId.toString(),
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true,
  };
  if (openPath !== undefined && config.miniAppUrl) {
    body.reply_markup = {
      inline_keyboard: [[{ text: "Open", web_app: { url: config.miniAppUrl.replace(/\/$/, "") + openPath } }]],
    };
  }
  try {
    const res = await fetch(`https://api.telegram.org/bot${config.botToken}/sendMessage`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(body),
    });
    const json: any = await res.json().catch(() => ({}));
    if (res.ok && json.ok) return { ok: true };
    const desc: string = json.description ?? `HTTP ${res.status}`;
    const blocked =
      res.status === 403 || /bot was blocked|user is deactivated|chat not found/i.test(desc);
    return { ok: false, blocked, retryAfter: json.parameters?.retry_after, error: desc };
  } catch (e: any) {
    return { ok: false, blocked: false, error: e?.message ?? "network error" };
  }
}

export function escapeHtml(s: string): string {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
