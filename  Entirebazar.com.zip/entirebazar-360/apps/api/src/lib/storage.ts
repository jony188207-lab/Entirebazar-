import crypto from "crypto";
import fs from "fs";
import path from "path";
import { config } from "../config";
import { presign, encodeKeyPath } from "./s3sign";
import { sniffImage, MAX_UPLOAD_BYTES } from "./upload";

/**
 * Object storage on Backblaze B2 (S3-compatible API).
 *  - PUBLIC bucket  : images shown in the Mini App. Stored value is the full https URL.
 *  - PRIVATE bucket : paid downloads. Stored value is "b2://files/<32hex>/<name>"; the buyer only ever gets a short-lived presigned URL.
 * Credentials come from server env only. They never reach the browser, the database or logs.
 */
export const PRIVATE_REF = /^b2:\/\/files\/[a-f0-9]{32}\/[A-Za-z0-9._-]{1,100}$/;
export const MAX_FILE_BYTES = 25 * 1024 * 1024;

export class StorageError extends Error {}

export const b2Configured = () => {
  const b = config.b2;
  return !!(b.endpoint && b.region && b.keyId && b.appKey);
};

function call(bucket: string, key: string, method: "PUT" | "GET" | "DELETE" | "HEAD", expires = 120, query?: Record<string, string>) {
  const b = config.b2;
  if (!b2Configured()) throw new StorageError("Backblaze B2 is not configured on the server");
  if (!bucket) throw new StorageError("B2 bucket name is not configured");
  return presign({
    method, host: b.endpoint, path: `/${encodeURIComponent(bucket)}/${encodeKeyPath(key)}`,
    region: b.region, accessKeyId: b.keyId, secretAccessKey: b.appKey, expiresSeconds: expires, query,
  });
}

async function put(bucket: string, key: string, body: Buffer, contentType: string, cacheControl?: string) {
  const url = call(bucket, key, "PUT");
  const headers: Record<string, string> = { "Content-Type": contentType };
  if (cacheControl) headers["Cache-Control"] = cacheControl;
  const r = await fetch(url, { method: "PUT", body: new Uint8Array(body), headers, signal: AbortSignal.timeout(30_000) });
  if (!r.ok) throw new StorageError(`B2 upload failed (HTTP ${r.status})`); // response body is never echoed: it may contain request details
}

export async function deleteObject(bucket: string, key: string) {
  const r = await fetch(call(bucket, key, "DELETE"), { method: "DELETE", signal: AbortSignal.timeout(15_000) });
  if (!r.ok && r.status !== 404) throw new StorageError(`B2 delete failed (HTTP ${r.status})`);
}

/** Read-only connectivity check used by the API Integrations "Test connection" button. */
export async function testB2(): Promise<{ ok: boolean; message: string }> {
  try {
    const b = config.b2;
    for (const bucket of [b.publicBucket, b.privateBucket].filter(Boolean)) {
      const r = await fetch(call(bucket, "__healthcheck__", "HEAD"), { method: "HEAD", signal: AbortSignal.timeout(10_000) });
      if (r.status === 401 || r.status === 403) return { ok: false, message: `B2 rejected the credentials for bucket "${bucket}"` };
      if (r.status >= 500) return { ok: false, message: `B2 error (HTTP ${r.status})` };
    }
    return { ok: true, message: "B2 accepted the credentials" };
  } catch (e: any) {
    return { ok: false, message: e instanceof StorageError ? e.message : "Could not reach B2" };
  }
}

export const publicUrl = (key: string) => `${config.b2.publicBaseUrl.replace(/\/+$/, "")}/${encodeKeyPath(key)}`;

/** Stores a magic-byte verified image and returns the value to save in the database. */
export async function storeImage(buf: Buffer): Promise<string> {
  const kind = sniffImage(buf);
  if (!kind) throw new StorageError("Unsupported image. Upload a PNG, JPEG or WebP file.");
  if (buf.length > MAX_UPLOAD_BYTES) throw new StorageError("Image is larger than 2 MB.");
  const name = crypto.randomBytes(16).toString("hex") + kind.ext;
  if (config.storageDriver === "local") {
    if (config.isProd) throw new StorageError("Local uploads are disabled in production");
    fs.mkdirSync(config.uploadDir, { recursive: true });
    fs.writeFileSync(path.join(config.uploadDir, name), buf, { flag: "wx", mode: 0o644 });
    return `/uploads/${name}`;
  }
  if (!config.b2.publicBaseUrl) throw new StorageError("B2_PUBLIC_BASE_URL is not configured");
  await put(config.b2.publicBucket, `img/${name}`, buf, kind.mime, "public, max-age=31536000, immutable");
  return publicUrl(`img/${name}`);
}

const FILE_TYPES: { test: (b: Buffer) => boolean; ext: string; mime: string }[] = [
  { test: (b) => b.toString("ascii", 0, 5) === "%PDF-", ext: "pdf", mime: "application/pdf" },
  { test: (b) => b[0] === 0x50 && b[1] === 0x4b && b[2] === 0x03 && b[3] === 0x04, ext: "zip", mime: "application/zip" },
];

/** Stores a paid download (PDF or ZIP, checked by magic bytes) in the PRIVATE bucket. Returns "b2://files/<hex>/<safe-name>". */
export async function storePrivateFile(buf: Buffer, originalName: string): Promise<string> {
  if (config.storageDriver !== "b2") throw new StorageError("File uploads need Backblaze B2 (STORAGE_DRIVER=b2)");
  if (buf.length > MAX_FILE_BYTES) throw new StorageError("File is larger than 25 MB.");
  const t = FILE_TYPES.find((x) => x.test(buf));
  if (!t) throw new StorageError("Only PDF and ZIP files are accepted.");
  const base = originalName.replace(/\.[^.]*$/, "").replace(/[^A-Za-z0-9._-]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60) || "file";
  const key = `files/${crypto.randomBytes(16).toString("hex")}/${base}.${t.ext}`;
  await put(config.b2.privateBucket, key, buf, t.mime);
  return `b2://${key}`;
}

/** Short-lived download link for a private reference. Only call after the caller has been authorised for that order item. */
export function privateDownloadUrl(ref: string, seconds = 900): string {
  if (!PRIVATE_REF.test(ref)) throw new StorageError("Invalid file reference");
  const key = ref.slice("b2://".length);
  return call(config.b2.privateBucket, key, "GET", seconds, { "response-content-disposition": "attachment" });
}
