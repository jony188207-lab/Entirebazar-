/** Role-based admin permissions. Enforced server-side by requirePerm() on every admin route. */

export const PERMISSIONS = [
  "dashboard.view", "reports.view",
  "catalog.view", "catalog.edit", "catalog.publish", "catalog.delete",
  "products.view", "products.edit", "products.publish", "products.delete", "inventory.manage",
  "notices.manage", "buttons.manage",
  "orders.view", "orders.fulfil", "orders.refund",
  "deposits.view", "deposits.review", "ledger.view", "wallet.adjust",
  "users.view", "users.manage",
  "tickets.manage", "notify.send",
  "payments.configure",
  "integrations.view", "integrations.manage", "integrations.secrets",
  "settings.manage", "roles.manage", "audit.view",
] as const;
export type Permission = (typeof PERMISSIONS)[number];

/** Permissions that move money, change credentials or change who can do what. */
export const SENSITIVE: ReadonlySet<Permission> = new Set<Permission>([
  "wallet.adjust", "orders.refund", "deposits.review", "integrations.secrets", "integrations.manage", "roles.manage",
]);

const ADMIN_EXCLUDED: Permission[] = ["roles.manage", "integrations.secrets", "wallet.adjust"];

export const DEFAULT_ROLE_PERMISSIONS: Record<"OWNER" | "ADMIN" | "SUPPORT", Permission[]> = {
  OWNER: [...PERMISSIONS],
  ADMIN: PERMISSIONS.filter((p) => !ADMIN_EXCLUDED.includes(p)),
  SUPPORT: ["dashboard.view", "orders.view", "users.view", "tickets.manage", "deposits.view", "catalog.view", "products.view"],
};

export interface AdminLike {
  role: "OWNER" | "ADMIN" | "SUPPORT";
  disabled?: boolean;
  customRole?: { permissions: string[] } | null;
}

export function permissionsOf(a: AdminLike): Permission[] {
  if (a.disabled) return [];
  if (a.role === "OWNER") return [...PERMISSIONS];
  if (a.customRole) return PERMISSIONS.filter((p) => a.customRole!.permissions.includes(p));
  return DEFAULT_ROLE_PERMISSIONS[a.role];
}

export function hasPermission(a: AdminLike, p: Permission): boolean {
  return permissionsOf(a).includes(p);
}

export function isPermission(v: string): v is Permission {
  return (PERMISSIONS as readonly string[]).includes(v);
}

/** Human-readable grouping used by the Roles & Permissions screen. */
export const PERMISSION_GROUPS: { label: string; permissions: Permission[] }[] = [
  { label: "Overview", permissions: ["dashboard.view", "reports.view"] },
  { label: "Categories & pages", permissions: ["catalog.view", "catalog.edit", "catalog.publish", "catalog.delete", "buttons.manage"] },
  { label: "Products & inventory", permissions: ["products.view", "products.edit", "products.publish", "products.delete", "inventory.manage"] },
  { label: "Notices & notifications", permissions: ["notices.manage", "notify.send"] },
  { label: "Orders", permissions: ["orders.view", "orders.fulfil", "orders.refund"] },
  { label: "Money", permissions: ["deposits.view", "deposits.review", "ledger.view", "wallet.adjust", "payments.configure"] },
  { label: "People & support", permissions: ["users.view", "users.manage", "tickets.manage"] },
  { label: "System", permissions: ["integrations.view", "integrations.manage", "integrations.secrets", "settings.manage", "roles.manage", "audit.view"] },
];

/** Ready-made roles created by the seed script (editable, not deletable). OWNER/ADMIN/SUPPORT come from the AdminRole enum. */
export const SYSTEM_ROLES: { name: string; description: string; permissions: Permission[] }[] = [
  {
    name: "Catalog manager",
    description: "Builds categories, pages, products, notices and buttons. No money or user access.",
    permissions: [
      "dashboard.view", "catalog.view", "catalog.edit", "catalog.publish", "catalog.delete", "buttons.manage",
      "products.view", "products.edit", "products.publish", "products.delete", "inventory.manage", "notices.manage",
    ],
  },
  {
    name: "Finance",
    description: "Reviews deposits and refunds, reads the ledger and reports. Cannot edit the catalog.",
    permissions: ["dashboard.view", "reports.view", "orders.view", "orders.refund", "deposits.view", "deposits.review", "ledger.view", "users.view"],
  },
  {
    name: "Support agent",
    description: "Answers tickets and fulfils manual orders. Read-only elsewhere.",
    permissions: ["dashboard.view", "orders.view", "orders.fulfil", "users.view", "tickets.manage", "deposits.view", "catalog.view", "products.view"],
  },
];
