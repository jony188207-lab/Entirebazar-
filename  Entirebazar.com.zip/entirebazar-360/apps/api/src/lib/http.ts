import { Request, Response, NextFunction, RequestHandler } from "express";
import { ZodError } from "zod";
import { UserError } from "./errors";

/** Express 4 does not catch async rejections; wrap every async handler. */
export const wrap =
  (fn: (req: Request, res: Response, next: NextFunction) => Promise<unknown>): RequestHandler =>
  (req, res, next) => {
    fn(req, res, next).catch(next);
  };

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof UserError) return res.status(err.status).json({ error: err.message });
  if (err instanceof ZodError) return res.status(400).json({ error: "Invalid request", details: err.flatten() });
  console.error("[error]", err);
  // Never leak internals to the client.
  res.status(500).json({ error: "Internal server error" });
}

export function paging(q: Record<string, unknown>, max = 50) {
  const limit = Math.min(Math.max(Number(q.limit ?? 20) || 20, 1), max);
  const page = Math.max(Number(q.page ?? 1) || 1, 1);
  return { take: limit, skip: (page - 1) * limit, page, limit };
}
