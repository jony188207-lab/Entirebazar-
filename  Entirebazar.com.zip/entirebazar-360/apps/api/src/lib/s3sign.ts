import crypto from "crypto";

/**
 * AWS Signature V4 query-string presigning (the scheme Backblaze B2's S3-compatible API accepts).
 * Pure function: no network, no globals, so it can be tested against AWS's published test vector.
 */
export type PresignInput = {
  method: "GET" | "PUT" | "DELETE" | "HEAD";
  host: string; // e.g. s3.us-west-004.backblazeb2.com
  path: string; // already URI-encoded, starts with "/"
  region: string;
  accessKeyId: string;
  secretAccessKey: string;
  expiresSeconds: number;
  now?: Date;
  /** extra query parameters to sign (e.g. response-content-disposition) */
  query?: Record<string, string>;
};

const hmac = (key: Buffer | string, data: string) => crypto.createHmac("sha256", key).update(data, "utf8").digest();
const sha256hex = (s: string) => crypto.createHash("sha256").update(s, "utf8").digest("hex");
const enc = (s: string) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());

export function presign(i: PresignInput): string {
  if (i.expiresSeconds < 1 || i.expiresSeconds > 604800) throw new Error("expiresSeconds must be 1..604800");
  const now = i.now ?? new Date();
  const amzDate = now.toISOString().replace(/[:-]|\.\d{3}/g, ""); // 20130524T000000Z
  const day = amzDate.slice(0, 8);
  const scope = `${day}/${i.region}/s3/aws4_request`;
  const params: Record<string, string> = {
    ...(i.query ?? {}),
    "X-Amz-Algorithm": "AWS4-HMAC-SHA256",
    "X-Amz-Credential": `${i.accessKeyId}/${scope}`,
    "X-Amz-Date": amzDate,
    "X-Amz-Expires": String(i.expiresSeconds),
    "X-Amz-SignedHeaders": "host",
  };
  const canonicalQuery = Object.keys(params)
    .sort()
    .map((k) => `${enc(k)}=${enc(params[k])}`)
    .join("&");
  const canonicalRequest = [i.method, i.path, canonicalQuery, `host:${i.host}\n`, "host", "UNSIGNED-PAYLOAD"].join("\n");
  const stringToSign = ["AWS4-HMAC-SHA256", amzDate, scope, sha256hex(canonicalRequest)].join("\n");
  const kDate = hmac("AWS4" + i.secretAccessKey, day);
  const signingKey = hmac(hmac(hmac(kDate, i.region), "s3"), "aws4_request");
  const signature = crypto.createHmac("sha256", signingKey).update(stringToSign, "utf8").digest("hex");
  return `https://${i.host}${i.path}?${canonicalQuery}&X-Amz-Signature=${signature}`;
}

/** URI-encodes each path segment but keeps "/" separators. */
export const encodeKeyPath = (key: string) => key.split("/").map(enc).join("/");
