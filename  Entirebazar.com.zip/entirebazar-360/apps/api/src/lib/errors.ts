/** Errors safe to show to the end user / admin (message is returned verbatim with `status`). */
export class UserError extends Error {
  constructor(message: string, public status = 400) {
    super(message);
  }
}
