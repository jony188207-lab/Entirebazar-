import { z } from "zod";
import { LIMITS } from "./limits";
import { isSafeEmoji, isSafeImageRef, noMarkup, SLUG_RE, START_PARAM_RE, TELEGRAM_USERNAME_RE } from "./validate";

/* ---------- primitives ---------- */
export const text = (max: number, min = 0) =>
  z.string().trim().min(min).max(max).refine(noMarkup, "HTML or script markup is not allowed (plain text only)");
export const optText = (max: number) =>
  text(max).nullish().transform((v) => (v ? v : null));
export const imageRef = z.string().trim().max(500).refine(isSafeImageRef, "Use an uploaded image or an https image URL (png/jpg/webp)");
export const optImage = imageRef.nullish().transform((v) => (v ? v : null));
export const emoji = z.string().trim().refine(isSafeEmoji, "Use a short emoji/icon (max 8 characters)");
export const optEmoji = emoji.nullish().transform((v) => (v ? v : null));
export const id = z.string().min(1).max(40);
export const idList = (max: number) => z.array(id).max(max).default([]);
export const slug = z.string().trim().min(1).max(60).regex(SLUG_RE, "Lowercase letters, numbers and dashes only");

/* ---------- FAQ ---------- */
export const faqItems = z
  .array(z.object({ q: text(200, 1), a: text(1500, 1) }))
  .max(LIMITS.maxFaqItems)
  .default([]);

/* ---------- Page-builder sections ---------- */
export const SECTION_TYPES = [
  "PRODUCT_GRID", "FEATURED_PRODUCTS", "PROMO_BANNER", "NOTICE", "RICH_TEXT", "IMAGE", "BUTTON_GROUP",
  "CATEGORY_GRID", "FAQ", "HOW_IT_WORKS", "SUPPORT_INFO", "TERMS", "COUNTDOWN", "EMPTY_STATE",
] as const;
export type SectionType = (typeof SECTION_TYPES)[number];

export const SECTION_LABELS: Record<SectionType, string> = {
  PRODUCT_GRID: "Product grid", FEATURED_PRODUCTS: "Featured products", PROMO_BANNER: "Promotional banner",
  NOTICE: "Announcement / notice", RICH_TEXT: "Rich text", IMAGE: "Image", BUTTON_GROUP: "Custom button group",
  CATEGORY_GRID: "Category grid", FAQ: "FAQ", HOW_IT_WORKS: "How it works", SUPPORT_INFO: "Support information",
  TERMS: "Terms and conditions", COUNTDOWN: "Countdown promotion", EMPTY_STATE: "Empty-state message",
};

const sortEnum = z.enum(["MANUAL", "NEWEST", "POPULAR", "PRICE_ASC", "PRICE_DESC"]);
const gridLayout = z.enum(["GRID_2", "GRID_3", "LIST", "CAROUSEL"]);

export const sectionConfigSchemas = {
  PRODUCT_GRID: z.object({
    source: z.enum(["CATEGORY", "SUBTREE", "MANUAL"]).default("CATEGORY"),
    productIds: idList(LIMITS.maxProductsPerManualList),
    limit: z.number().int().min(1).max(48).default(12),
    layout: gridLayout.default("GRID_2"),
    sort: sortEnum.default("MANUAL"),
    showFilters: z.boolean().default(false),
  }),
  FEATURED_PRODUCTS: z.object({
    source: z.enum(["FLAGGED", "MANUAL"]).default("FLAGGED"),
    productIds: idList(LIMITS.maxProductsPerManualList),
    limit: z.number().int().min(1).max(24).default(6),
    layout: z.enum(["CAROUSEL", "GRID_2"]).default("CAROUSEL"),
  }),
  PROMO_BANNER: z.object({
    heading: text(120, 1),
    text: optText(500),
    imageUrl: optImage,
    tone: z.enum(["BRAND", "SUCCESS", "WARNING", "DARK"]).default("BRAND"),
  }),
  NOTICE: z.object({
    heading: text(120, 1),
    text: text(1000, 1),
    icon: optEmoji,
    tone: z.enum(["INFO", "PROMO", "WARNING", "MAINTENANCE"]).default("INFO"),
  }),
  RICH_TEXT: z.object({
    text: text(5000, 1),
    align: z.enum(["LEFT", "CENTER"]).default("LEFT"),
  }),
  IMAGE: z.object({
    imageUrl: imageRef,
    alt: text(120).default(""),
    caption: optText(200),
    fit: z.enum(["COVER", "CONTAIN"]).default("COVER"),
    aspect: z.enum(["16_9", "4_3", "1_1"]).default("16_9"),
  }),
  BUTTON_GROUP: z.object({
    layout: z.enum(["ROW", "STACK", "GRID"]).default("ROW"),
  }),
  CATEGORY_GRID: z.object({
    source: z.enum(["CHILDREN", "MANUAL", "FEATURED"]).default("CHILDREN"),
    categoryIds: idList(24),
    columns: z.union([z.literal(2), z.literal(3)]).default(2),
    showImages: z.boolean().default(true),
  }),
  FAQ: z.object({
    items: faqItems,
    useCategoryFaq: z.boolean().default(false),
  }),
  HOW_IT_WORKS: z.object({
    steps: z.array(z.object({ title: text(80, 1), text: text(300), icon: optEmoji })).min(1).max(8),
  }),
  SUPPORT_INFO: z.object({
    text: optText(1000),
    useGlobalContact: z.boolean().default(true),
  }),
  TERMS: z.object({
    text: text(8000, 1),
    collapsed: z.boolean().default(true),
  }),
  COUNTDOWN: z.object({
    endsAt: z.coerce.date(),
    label: text(120, 1),
    expiredMessage: optText(200),
    hideWhenExpired: z.boolean().default(false),
  }),
  EMPTY_STATE: z.object({
    icon: optEmoji,
    heading: text(120, 1),
    text: optText(300),
  }),
} satisfies Record<SectionType, z.ZodTypeAny>;

export function parseSectionConfig(type: SectionType, config: unknown) {
  return sectionConfigSchemas[type].safeParse(config ?? {});
}

/** Section sent to the editor. `config` is validated for the given type, then stored as plain JSON. */
export const sectionInput = z
  .object({
    type: z.enum(SECTION_TYPES),
    title: optText(120),
    enabled: z.boolean().default(true),
    startsAt: z.coerce.date().nullish().transform((v) => v ?? null),
    endsAt: z.coerce.date().nullish().transform((v) => v ?? null),
    config: z.record(z.unknown()).default({}),
  })
  .transform((v, ctx) => {
    const r = parseSectionConfig(v.type, v.config);
    if (!r.success) {
      for (const i of r.error.issues) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["config", ...i.path], message: i.message });
      return z.NEVER;
    }
    if (v.startsAt && v.endsAt && v.endsAt <= v.startsAt) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["endsAt"], message: "End must be after start" });
      return z.NEVER;
    }
    return { ...v, config: JSON.parse(JSON.stringify(r.data)) as Record<string, unknown> };
  });
export const sectionPatch = z.object({
  title: optText(120).optional(),
  enabled: z.boolean().optional(),
  startsAt: z.coerce.date().nullable().optional(),
  endsAt: z.coerce.date().nullable().optional(),
  config: z.record(z.unknown()).optional(),
});

/* ---------- Buttons ---------- */
export const BUTTON_ACTIONS = [
  "OPEN_CATEGORY", "OPEN_PRODUCT", "OPEN_PRODUCT_LIST", "OPEN_WALLET", "OPEN_ORDERS", "OPEN_SUPPORT",
  "OPEN_EXTERNAL", "OPEN_FAQ", "START_PURCHASE", "OPEN_TELEGRAM_BOT",
] as const;
export type ButtonAction = (typeof BUTTON_ACTIONS)[number];

export const BUTTON_ACTION_LABELS: Record<ButtonAction, string> = {
  OPEN_CATEGORY: "Open a category", OPEN_PRODUCT: "Open a product", OPEN_PRODUCT_LIST: "Open a product listing",
  OPEN_WALLET: "Open the wallet", OPEN_ORDERS: "Open order history", OPEN_SUPPORT: "Open support",
  OPEN_EXTERNAL: "Open an approved HTTPS link", OPEN_FAQ: "Open an FAQ", START_PURCHASE: "Start the purchase flow",
  OPEN_TELEGRAM_BOT: "Open a Telegram bot link",
};

export const buttonTargetSchemas = {
  OPEN_CATEGORY: z.object({ categoryId: id }),
  OPEN_PRODUCT: z.object({ productId: id }),
  OPEN_PRODUCT_LIST: z.object({
    categoryId: id.optional(),
    sort: sortEnum.optional(),
    featured: z.boolean().optional(),
    q: text(60).optional(),
  }),
  OPEN_WALLET: z.object({}),
  OPEN_ORDERS: z.object({}),
  OPEN_SUPPORT: z.object({}),
  OPEN_EXTERNAL: z.object({ url: z.string().trim().max(500) }), // host allow-list checked in the service layer
  OPEN_FAQ: z.object({ categoryId: id.optional() }),
  START_PURCHASE: z.object({ productId: id, variantId: id.optional() }),
  OPEN_TELEGRAM_BOT: z.object({
    username: z.string().trim().regex(TELEGRAM_USERNAME_RE, "Invalid Telegram username"),
    startParam: z.string().trim().regex(START_PARAM_RE, "Invalid start parameter").optional(),
  }),
} satisfies Record<ButtonAction, z.ZodTypeAny>;

export const visibilityRule = z.object({
  audience: z.enum(["ALL", "NEW_USERS", "RETURNING", "LOW_BALANCE", "HAS_BALANCE"]).default("ALL"),
  threshold: z.number().min(0).max(10_000_000).optional(),
});
export type VisibilityRule = z.infer<typeof visibilityRule>;

export const BUTTON_STYLES = ["PRIMARY", "SECONDARY", "OUTLINE", "DANGER", "LINK"] as const;
export const BUTTON_SIZES = ["SM", "MD", "LG"] as const;
export const BUTTON_PLACEMENTS = ["TOP", "BOTTOM", "STICKY", "INLINE"] as const;
export const OWNER_KEYS = ["categoryId", "sectionId", "productId", "noticeId"] as const;

export const buttonInput = z
  .object({
    categoryId: id.nullish(),
    sectionId: id.nullish(),
    productId: id.nullish(),
    noticeId: id.nullish(),
    label: text(40, 1),
    icon: optEmoji,
    style: z.enum(BUTTON_STYLES).default("PRIMARY"),
    size: z.enum(BUTTON_SIZES).default("MD"),
    placement: z.enum(BUTTON_PLACEMENTS).default("INLINE"),
    action: z.enum(BUTTON_ACTIONS),
    target: z.record(z.unknown()).default({}),
    confirmTitle: optText(80),
    confirmMessage: optText(300),
    visibility: visibilityRule.default({ audience: "ALL" }),
    enabled: z.boolean().default(true),
  })
  .transform((v, ctx) => {
    const owners = OWNER_KEYS.filter((k) => v[k]);
    if (owners.length !== 1) {
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["owner"], message: "A button must belong to exactly one category, section, product or notice" });
      return z.NEVER;
    }
    const r = buttonTargetSchemas[v.action].safeParse(v.target);
    if (!r.success) {
      for (const i of r.error.issues) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["target", ...i.path], message: i.message });
      return z.NEVER;
    }
    // Purchases and money-related pages are always behind confirmation unless the admin deliberately adds their own text.
    return { ...v, target: r.data as Record<string, unknown> };
  });

/** Parse target for an already-known action (used when re-validating stored buttons). */
export function parseButtonTarget(action: string, target: unknown) {
  if (!(BUTTON_ACTIONS as readonly string[]).includes(action)) return null;
  const r = buttonTargetSchemas[action as ButtonAction].safeParse(target ?? {});
  return r.success ? (r.data as Record<string, unknown>) : null;
}

/* ---------- Category ---------- */
export const SORT_OPTIONS = ["NEWEST", "POPULAR", "PRICE_ASC", "PRICE_DESC", "NAME"] as const;

export const categorySettingsSchema = z.object({
  layout: z
    .object({
      productCardLayout: z.enum(["DEFAULT", "COMPACT", "WIDE"]).default("DEFAULT"),
      columns: z.union([z.literal(1), z.literal(2), z.literal(3)]).default(2),
      showBreadcrumbs: z.boolean().default(true),
      showSubcategories: z.boolean().default(true),
      showCover: z.boolean().default(true),
      showProductCount: z.boolean().default(true),
      showDefaultProductList: z.boolean().default(true), // legacy-friendly: show the products tab list when no sections exist
      emptyMessage: text(200).default("No products here yet."),
    })
    .default({}),
  filters: z
    .object({
      search: z.boolean().default(true),
      priceRange: z.boolean().default(false),
      inStock: z.boolean().default(true),
      productTypes: z.boolean().default(false),
    })
    .default({}),
  sorting: z
    .object({
      options: z.array(z.enum(SORT_OPTIONS)).min(1).max(5).default(["NEWEST", "POPULAR", "PRICE_ASC", "PRICE_DESC"]),
      default: z.enum(SORT_OPTIONS).default("NEWEST"),
      pinnedFirst: z.boolean().default(true),
    })
    .default({}),
  pricing: z
    .object({
      showOriginalPrice: z.boolean().default(true),
      showDiscountBadge: z.boolean().default(true),
      badgeText: text(30).default("SALE"),
    })
    .default({}),
  seo: z
    .object({
      title: text(70).default(""),
      description: text(160).default(""),
      keywords: z.array(text(30, 1)).max(10).default([]),
    })
    .default({}),
  display: z
    .object({
      accentColor: z.string().regex(/^#[0-9a-fA-F]{6}$/).nullish().transform((v) => v ?? null),
      showInShopMenu: z.boolean().default(true),
      hideWhenEmpty: z.boolean().default(false),
    })
    .default({}),
});
export type CategorySettings = z.infer<typeof categorySettingsSchema>;
export const DEFAULT_CATEGORY_SETTINGS: CategorySettings = categorySettingsSchema.parse({});

const money2 = z.union([z.number(), z.string()]).transform((v) => Number(v)).refine((n) => Number.isFinite(n) && n >= 0, "Invalid amount");

export const categoryInput = z
  .object({
    name: text(80, 1),
    slug: slug.optional(),
    parentId: id.nullish().transform((v) => v ?? null),
    description: optText(1000),
    icon: optEmoji,
    imageUrl: optImage,
    coverUrl: optImage,
    visibility: z.enum(["PUBLIC", "UNLISTED"]).default("PUBLIC"),
    purchasable: z.boolean().default(true),
    unavailableMessage: optText(200),
    featured: z.boolean().default(false),
    featuredOrder: z.number().int().min(0).max(100000).default(0),
    publishAt: z.coerce.date().nullish().transform((v) => v ?? null),
    unpublishAt: z.coerce.date().nullish().transform((v) => v ?? null),
    supportLink: z.string().trim().max(500).nullish().transform((v) => v || null), // host allow-list checked in service layer
    settings: categorySettingsSchema.default({}),
    faq: faqItems,
    discountPercent: money2.refine((n) => n <= 90, "Max 90%").nullish().transform((v) => v ?? null),
    discountStartsAt: z.coerce.date().nullish().transform((v) => v ?? null),
    discountEndsAt: z.coerce.date().nullish().transform((v) => v ?? null),
  })
  .superRefine((v, ctx) => {
    if (v.publishAt && v.unpublishAt && v.unpublishAt <= v.publishAt)
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["unpublishAt"], message: "Unpublish date must be after the publish date" });
    if (v.discountStartsAt && v.discountEndsAt && v.discountEndsAt <= v.discountStartsAt)
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["discountEndsAt"], message: "Discount end must be after its start" });
  });
export const categoryPatch = z.object({}).passthrough(); // partial updates are merged with the stored row, then re-validated with categoryInput

/* ---------- Products ---------- */
export const PRODUCT_TYPES = ["DIGITAL", "SUBSCRIPTION", "LICENSE_KEY", "SERVICE_PACKAGE", "DOWNLOADABLE", "MANUAL"] as const;
const priceStr = z.union([z.number(), z.string()]).transform((v) => String(v)).refine((s) => /^\d{1,10}(\.\d{1,2})?$/.test(s) && Number(s) > 0, "Price must be a positive amount with up to 2 decimals");

export const productInput = z
  .object({
    name: text(120, 1),
    description: text(5000),
    features: z.array(text(200, 1)).max(20).default([]),
    imageUrl: optImage,
    price: priceStr,
    discountType: z.enum(["NONE", "PERCENT", "FIXED"]).default("NONE"),
    discountValue: z.union([z.number(), z.string()]).transform((v) => Number(v)).nullish().transform((v) => v ?? null),
    discountStartsAt: z.coerce.date().nullish().transform((v) => v ?? null),
    discountEndsAt: z.coerce.date().nullish().transform((v) => v ?? null),
    stock: z.number().int().min(0).max(10_000_000).nullish().transform((v) => v ?? null),
    featured: z.boolean().default(false),
    productType: z.enum(PRODUCT_TYPES).default("DIGITAL"),
    deliveryType: z.enum(["TEXT_KEYS", "FILE_URL", "MANUAL"]).default("TEXT_KEYS"),
    deliveryFileUrl: z.string().trim().max(1000).nullish().transform((v) => v || null), // validated as https in service layer
    deliveryInstructions: optText(2000),
    inputLabel: optText(60),
    cardLayout: z.enum(["DEFAULT", "COMPACT", "WIDE"]).default("DEFAULT"),
    faq: faqItems,
    categoryIds: idList(20),
    primaryCategoryId: id.nullish().transform((v) => v ?? null),
  })
  .superRefine((v, ctx) => {
    if (v.discountType !== "NONE") {
      if (v.discountValue === null || !(v.discountValue > 0)) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["discountValue"], message: "Enter a discount value" });
      else if (v.discountType === "PERCENT" && v.discountValue > 90) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["discountValue"], message: "Max 90%" });
      else if (v.discountType === "FIXED" && v.discountValue >= Number(v.price)) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["discountValue"], message: "Fixed discount must be lower than the price" });
    }
    if (v.discountStartsAt && v.discountEndsAt && v.discountEndsAt <= v.discountStartsAt)
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["discountEndsAt"], message: "Discount end must be after its start" });
    if (v.deliveryType === "FILE_URL" && !v.deliveryFileUrl)
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["deliveryFileUrl"], message: "A download link is required for file delivery" });
    if (v.primaryCategoryId && !v.categoryIds.includes(v.primaryCategoryId))
      ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["primaryCategoryId"], message: "Primary category must be one of the selected categories" });
  });

export const variantInput = z.object({
  name: text(80, 1),
  sku: optText(40),
  price: priceStr.nullish().transform((v) => v ?? null),
  stock: z.number().int().min(0).max(10_000_000).nullish().transform((v) => v ?? null),
  status: z.enum(["DRAFT", "PUBLISHED"]).default("PUBLISHED"),
});

/* ---------- Notices ---------- */
export const NOTICE_LOCATIONS = [
  "HOME_BANNER", "HOME_SECTION", "NOTIFICATION_CENTER", "SHOP", "CATEGORY_PAGE", "PRODUCT_DETAIL",
  "ADD_MONEY", "PAYMENT_RESULT", "WALLET", "ORDER_DETAIL", "MAINTENANCE",
] as const;

export const noticeInput = z
  .object({
    title: text(120, 1),
    body: text(2000, 1),
    imageUrl: optImage,
    icon: optEmoji,
    type: z.enum(["INFO", "PROMO", "WARNING", "MAINTENANCE", "PAYMENT", "ORDER", "UPDATE"]).default("INFO"),
    locations: z.array(z.enum(NOTICE_LOCATIONS)).min(1).max(NOTICE_LOCATIONS.length),
    audience: z.enum(["ALL", "CATEGORIES", "PRODUCTS"]).default("ALL"),
    categoryIds: idList(50),
    productIds: idList(50),
    priority: z.number().int().min(0).max(1000).default(0),
    dismissible: z.boolean().default(true),
    pinned: z.boolean().default(false),
    enabled: z.boolean().default(true),
    publishAt: z.coerce.date().optional(),
    expiresAt: z.coerce.date().nullish().transform((v) => v ?? null),
  })
  .superRefine((v, ctx) => {
    if (v.audience === "CATEGORIES" && v.categoryIds.length === 0) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["categoryIds"], message: "Select at least one category" });
    if (v.audience === "PRODUCTS" && v.productIds.length === 0) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["productIds"], message: "Select at least one product" });
    if (v.publishAt && v.expiresAt && v.expiresAt <= v.publishAt) ctx.addIssue({ code: z.ZodIssueCode.custom, path: ["expiresAt"], message: "End must be after start" });
  });

/* ---------- General settings ---------- */
export const HOME_BLOCKS = ["BANNERS", "FEATURED_CATEGORIES", "NOTICES", "FEATURED_PRODUCTS", "BEST_SELLING", "CATEGORY_GRID"] as const;
export const HOME_BLOCK_LABELS: Record<(typeof HOME_BLOCKS)[number], string> = {
  BANNERS: "Promotional banners", FEATURED_CATEGORIES: "Featured categories", NOTICES: "Announcements",
  FEATURED_PRODUCTS: "Featured products", BEST_SELLING: "Best-selling products", CATEGORY_GRID: "All categories",
};

export const generalSettingsSchema = z.object({
  maintenance: z.boolean().default(false),
  maintenanceMessage: text(300).default("We'll be back shortly."),
  contact: z
    .object({
      telegramUsername: z.string().trim().regex(TELEGRAM_USERNAME_RE).nullish().transform((v) => v ?? null),
      email: z.string().trim().email().max(120).nullish().transform((v) => v ?? null),
      phone: text(30).nullish().transform((v) => v ?? null),
      supportHours: text(80).nullish().transform((v) => v ?? null),
    })
    .default({}),
  allowedExternalHosts: z
    .array(z.string().trim().toLowerCase().regex(/^(\*\.)?([a-z0-9-]+\.)+[a-z]{2,}$/, "Enter a hostname like example.com or *.example.com"))
    .max(LIMITS.maxAllowedHosts)
    .default(["t.me", "telegram.org"]),
  homeLayout: z
    .array(z.object({ id: z.enum(HOME_BLOCKS), enabled: z.boolean().default(true) }))
    .max(HOME_BLOCKS.length)
    .default(HOME_BLOCKS.map((b) => ({ id: b, enabled: b !== "CATEGORY_GRID" }))),
  homeFeaturedProductIds: idList(24),
});
export type GeneralSettings = z.infer<typeof generalSettingsSchema>;
export const DEFAULT_GENERAL_SETTINGS: GeneralSettings = generalSettingsSchema.parse({});

/* ---------- Roles ---------- */
export const roleInput = z.object({
  name: text(40, 2),
  description: optText(200),
  permissions: z.array(z.string()).max(64),
});
