import crypto from "crypto";

/**
 * AES-256-GCM encryption for integration credentials stored in the database.
 * The key comes from the SECRETS_ENCRYPTION_KEY environment variable (32 bytes, hex or base64) and is never stored.
 * Each secret is bound to its (integration, name) via AAD so ciphertexts cannot be swapped between rows.
 */

export interface Sealed {
  ciphertext: string;
  iv: string;
  tag: string;
}

export function loadKey(raw: string | undefined): Buffer {
  if (!raw) throw new Error("SECRETS_ENCRYPTION_KEY is not set");
  const hex = /^[0-9a-fA-F]{64}$/.test(raw) ? Buffer.from(raw, "hex") : null;
  const key = hex ?? Buffer.from(raw, "base64");
  if (key.length !== 32) throw new Error("SECRETS_ENCRYPTION_KEY must decode to exactly 32 bytes (64 hex chars or base64)");
  return key;
}

export function seal(plain: string, key: Buffer, aad: string): Sealed {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv("aes-256-gcm", key, iv);
  c.setAAD(Buffer.from(aad));
  const enc = Buffer.concat([c.update(plain, "utf8"), c.final()]);
  return { ciphertext: enc.toString("base64"), iv: iv.toString("base64"), tag: c.getAuthTag().toString("base64") };
}

export function open(s: Sealed, key: Buffer, aad: string): string {
  const d = crypto.createDecipheriv("aes-256-gcm", key, Buffer.from(s.iv, "base64"));
  d.setAAD(Buffer.from(aad));
  d.setAuthTag(Buffer.from(s.tag, "base64"));
  return Buffer.concat([d.update(Buffer.from(s.ciphertext, "base64")), d.final()]).toString("utf8");
}

/** Removes anything that looks like a credential from text that will be logged or shown in the UI. */
export function sanitizeError(msg: unknown, secrets: string[] = []): string {
  let s = String(msg ?? "error");
  for (const sec of secrets) if (sec && sec.length >= 4) s = s.split(sec).join("[redacted]");
  s = s
    .replace(/(authorization|bearer|api[-_ ]?key|secret|token|password)\s*[:=]\s*\S+/gi, "$1=[redacted]")
    .replace(/[A-Za-z0-9+/=_-]{32,}/g, "[redacted]");
  return s.slice(0, 300);
}

/** Never reveal a credential: a fixed-width mask, with only the length class hinted ("set" vs "short"). */
export function maskSecret(s: string | null | undefined): string {
  return s ? "••••••••" : "";
}
