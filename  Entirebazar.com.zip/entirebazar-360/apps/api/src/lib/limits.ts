/** Reasonable system limits for admin-created content ("unlimited, subject to reasonable limits"). */
export const LIMITS = {
  maxCategories: 500,
  maxCategoryDepth: 4, // root = depth 1
  maxSectionsPerCategory: 40,
  maxButtonsPerOwner: 12,
  maxFaqItems: 50,
  maxVariantsPerProduct: 50,
  maxProductsPerManualList: 48,
  maxProductsPerCategory: 5000,
  maxKeysPerUpload: 1000,
  maxAllowedHosts: 50,
  maxNotices: 500,
} as const;
