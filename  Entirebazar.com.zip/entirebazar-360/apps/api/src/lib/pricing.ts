/**
 * Server-side price calculation in integer minor units (no floating-point money).
 * The same function drives displayed prices and checkout totals, so the UI can never show a price
 * the backend would not charge.
 */

export type DiscountInput = {
  type: "NONE" | "PERCENT" | "FIXED";
  value?: string | number | null;
  startsAt?: Date | null;
  endsAt?: Date | null;
  source: "PRODUCT" | "CATEGORY";
};

export function toMinor(v: string | number): number {
  const s = typeof v === "number" ? v.toFixed(2) : String(v).trim();
  if (!/^\d+(\.\d{1,2})?$/.test(s)) throw new Error(`Invalid money amount: ${s}`);
  const [whole, frac = ""] = s.split(".");
  return Number(whole) * 100 + Number((frac + "00").slice(0, 2));
}

export function fromMinor(n: number): string {
  const sign = n < 0 ? "-" : "";
  const abs = Math.abs(Math.round(n));
  return `${sign}${Math.floor(abs / 100)}.${String(abs % 100).padStart(2, "0")}`;
}

export function discountIsActive(d: DiscountInput, now: Date): boolean {
  if (d.type === "NONE" || d.value === null || d.value === undefined) return false;
  if (d.startsAt && now < d.startsAt) return false;
  if (d.endsAt && now >= d.endsAt) return false;
  return Number(d.value) > 0;
}

function applyMinor(baseMinor: number, d: DiscountInput): number {
  if (d.type === "PERCENT") {
    const pct = Math.min(Math.max(Number(d.value), 0), 90); // never more than 90% off
    const bp = Math.round(pct * 100);
    return Math.floor((baseMinor * (10000 - bp) + 5000) / 10000); // round half up
  }
  if (d.type === "FIXED") return baseMinor - toMinor(typeof d.value === "number" ? d.value : String(d.value));
  return baseMinor;
}

export interface EffectivePrice {
  base: string;
  final: string;
  discounted: boolean;
  percentOff: number;
  source: "NONE" | "PRODUCT" | "CATEGORY";
}

/** Picks the single discount that gives the customer the lowest price (discounts never stack). Floor: 0.01. */
export function effectivePrice(base: string | number, discounts: DiscountInput[], now = new Date()): EffectivePrice {
  const baseMinor = toMinor(base);
  let best = baseMinor;
  let source: EffectivePrice["source"] = "NONE";
  for (const d of discounts) {
    if (!discountIsActive(d, now)) continue;
    const next = Math.max(applyMinor(baseMinor, d), 1);
    if (next < best) {
      best = next;
      source = d.source;
    }
  }
  const percentOff = baseMinor > 0 ? Math.round(((baseMinor - best) / baseMinor) * 100) : 0;
  return { base: fromMinor(baseMinor), final: fromMinor(best), discounted: best < baseMinor, percentOff, source };
}

/** Line total in minor units. */
export function lineTotalMinor(unitFinal: string, quantity: number): number {
  if (!Number.isInteger(quantity) || quantity < 1) throw new Error("Invalid quantity");
  return toMinor(unitFinal) * quantity;
}
