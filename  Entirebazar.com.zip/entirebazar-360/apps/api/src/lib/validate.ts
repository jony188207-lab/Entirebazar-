/**
 * Dependency-free validation helpers for admin-supplied content.
 * Policy: admin content is stored and rendered as PLAIN TEXT. HTML/markup, scripts and uploaded code are rejected.
 */

export const SLUG_RE = /^[a-z0-9]+(?:-[a-z0-9]+)*$/;

export function slugify(input: string): string {
  const s = input
    .normalize("NFKD")
    .replace(/[̀-ͯ]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60)
    .replace(/-+$/g, "");
  return s || "item";
}

/** True when the text contains something that looks like an HTML tag / comment / doctype. */
export function hasMarkup(s: string): boolean {
  return /<\s*\/?\s*[a-zA-Z!?]/.test(s) || /javascript\s*:/i.test(s);
}
export const noMarkup = (s: string) => !hasMarkup(s);

/** Uploaded image path (server-generated name) or a plain https URL. */
export function isSafeImageRef(v: string): boolean {
  if (typeof v !== "string" || v.length === 0 || v.length > 500) return false;
  if (/^\/uploads\/[a-f0-9]{32}\.(png|jpg|webp)$/.test(v)) return true;
  try {
    const u = new URL(v);
    // Raster formats only (no SVG: it can carry scripts).
    return u.protocol === "https:" && !u.username && !u.password && !hasMarkup(v) && /\.(png|jpe?g|webp)$/i.test(u.pathname);
  } catch {
    return false;
  }
}

/** Short icon: emoji or a few characters, no markup or control characters. */
export function isSafeEmoji(v: string): boolean {
  if (typeof v !== "string" || v.length === 0 || v.length > 8) return false;
  // eslint-disable-next-line no-control-regex
  return !/[\u0000-\u001f\u007f<>"'`]/.test(v);
}

const IPV4 = /^\d{1,3}(\.\d{1,3}){3}$/;

export type UrlCheck = { ok: true; url: string } | { ok: false; reason: string };

/**
 * External links must be https, carry no credentials, avoid IPs/localhost, and point at an
 * administrator-approved host (exact match, or "*.example.com" for subdomains).
 */
export function validateExternalUrl(raw: string, allowedHosts: string[]): UrlCheck {
  if (typeof raw !== "string" || raw.length === 0 || raw.length > 500) return { ok: false, reason: "URL is empty or too long" };
  if (hasMarkup(raw)) return { ok: false, reason: "URL contains markup" };
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return { ok: false, reason: "Not a valid URL" };
  }
  if (u.protocol !== "https:") return { ok: false, reason: "Only https:// links are allowed" };
  if (u.username || u.password) return { ok: false, reason: "Links with embedded credentials are not allowed" };
  if (u.port && u.port !== "443") return { ok: false, reason: "Custom ports are not allowed" };
  const host = u.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal") || IPV4.test(host) || host.includes(":") || host.startsWith("[")) {
    return { ok: false, reason: "Private, local and IP-address hosts are not allowed" };
  }
  const allowed = allowedHosts.map((h) => h.trim().toLowerCase()).filter(Boolean);
  const match = allowed.some((a) => (a.startsWith("*.") ? host.endsWith(a.slice(1)) && host.length > a.length - 1 : host === a));
  if (!match) return { ok: false, reason: `Host "${host}" is not in the allowed external hosts list (Settings → Allowed link hosts)` };
  return { ok: true, url: u.toString() };
}

export const HOST_RE = /^(\*\.)?([a-z0-9-]+\.)+[a-z]{2,}$/;

export const TELEGRAM_USERNAME_RE = /^[A-Za-z][A-Za-z0-9_]{4,31}$/;
export const START_PARAM_RE = /^[A-Za-z0-9_-]{0,64}$/;

export function telegramBotLink(username: string, startParam?: string): UrlCheck {
  if (!TELEGRAM_USERNAME_RE.test(username)) return { ok: false, reason: "Invalid Telegram username" };
  if (startParam && !START_PARAM_RE.test(startParam)) return { ok: false, reason: "Invalid start parameter (A-Z a-z 0-9 _ - up to 64)" };
  return { ok: true, url: `https://t.me/${username}${startParam ? `?start=${startParam}` : ""}` };
}

/**
 * Provider API base URLs: https only, no credentials, no private/local hosts. Unlike validateExternalUrl() there is
 * no host allow-list, because the provider's host is only known from its own onboarding documentation.
 */
export function validateHttpsUrl(raw: string): UrlCheck {
  if (typeof raw !== "string" || raw.length === 0 || raw.length > 500) return { ok: false, reason: "URL is empty or too long" };
  if (hasMarkup(raw)) return { ok: false, reason: "URL contains markup" };
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return { ok: false, reason: "Not a valid URL" };
  }
  if (u.protocol !== "https:") return { ok: false, reason: "Only https:// URLs are allowed" };
  if (u.username || u.password) return { ok: false, reason: "URLs with embedded credentials are not allowed" };
  const host = u.hostname.toLowerCase();
  if (host === "localhost" || host.endsWith(".local") || host.endsWith(".internal") || IPV4.test(host) || host.includes(":") || host.startsWith("[")) {
    return { ok: false, reason: "Private, local and IP-address hosts are not allowed" };
  }
  return { ok: true, url: u.toString() };
}
