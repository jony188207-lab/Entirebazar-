export type ImageKind = { ext: ".png" | ".jpg" | ".webp"; mime: string };

/** Identify an image by its magic bytes. The client-declared MIME type / file name is never trusted. SVG is deliberately unsupported. */
export function sniffImage(buf: Buffer): ImageKind | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 && buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a) return { ext: ".png", mime: "image/png" };
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return { ext: ".jpg", mime: "image/jpeg" };
  if (buf.toString("ascii", 0, 4) === "RIFF" && buf.toString("ascii", 8, 12) === "WEBP") return { ext: ".webp", mime: "image/webp" };
  return null;
}

export const MAX_UPLOAD_BYTES = 2 * 1024 * 1024;
