import crypto from "crypto";
import express, { Router } from "express";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "../db";
import { config } from "../config";
import { attemptVerification } from "../services/deposits";

/**
 * Signed webhook for an AUTHORISED verification source (a provider that supports
 * signed callbacks, or an SMS-forwarding/verification service you operate or contract).
 *
 * Contract (defined by this app, not by any payment provider):
 *   Headers:  X-Timestamp: unix seconds,  X-Signature: hex HMAC-SHA256(secret, `${timestamp}.${rawBody}`)
 *   Body:     { provider, trxId, amount, sender?, receiver?, environment }
 * Replay window 5 minutes. Idempotent on (provider, trxId).
 */
const schema = z.object({
  provider: z.string().min(2).max(20),
  trxId: z.string().min(6).max(24),
  amount: z.union([z.string(), z.number()]),
  sender: z.string().max(20).optional(),
  receiver: z.string().max(20).optional(),
  environment: z.enum(["sandbox", "production"]),
});

export const webhookRouter = Router();

webhookRouter.post("/payments", express.raw({ type: "*/*", limit: "32kb" }), async (req, res) => {
  const secret = config.paymentWebhookSecret;
  if (!secret) return res.status(503).json({ error: "Webhook not configured" });

  const raw = req.body as Buffer;
  const ts = String(req.header("x-timestamp") ?? "");
  const sig = String(req.header("x-signature") ?? "");
  if (!ts || !sig || Math.abs(Date.now() / 1000 - Number(ts)) > 300) {
    return res.status(401).json({ error: "Invalid or stale signature" });
  }
  const expected = crypto.createHmac("sha256", secret).update(`${ts}.`).update(raw).digest("hex");
  const a = Buffer.from(expected, "hex");
  const b = Buffer.from(sig, "hex");
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return res.status(401).json({ error: "Invalid signature" });
  }

  let body: z.infer<typeof schema>;
  try {
    body = schema.parse(JSON.parse(raw.toString("utf8")));
  } catch {
    return res.status(400).json({ error: "Bad payload" });
  }
  // Sandbox and production must never mix.
  if (body.environment !== config.paymentEnv) {
    return res.status(409).json({ error: "Environment mismatch" });
  }

  const trxId = body.trxId.trim().toUpperCase();
  let amount: Prisma.Decimal;
  try {
    amount = new Prisma.Decimal(body.amount);
  } catch {
    return res.status(400).json({ error: "Bad amount" });
  }

  try {
    await prisma.transaction.create({
      data: {
        providerCode: body.provider,
        providerTrxId: trxId,
        amount,
        senderNumber: body.sender,
        receiverNumber: body.receiver,
        rawPayload: JSON.parse(raw.toString("utf8")),
        environment: body.environment,
      },
    });
  } catch (e: any) {
    if (e?.code === "P2002") return res.json({ ok: true, duplicate: true }); // idempotent
    throw e;
  }

  const dep = await prisma.deposit.findFirst({
    where: { providerTrxId: trxId, status: "PENDING", provider: { code: body.provider } },
  });
  await prisma.paymentEvent.create({
    data: { depositId: dep?.id, source: "webhook", kind: "received", payload: { provider: body.provider, trxId } },
  });
  if (dep) await attemptVerification(dep.id);
  res.json({ ok: true });
});
