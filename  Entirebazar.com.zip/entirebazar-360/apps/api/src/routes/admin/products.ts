import { Router } from "express";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "../../db";
import { wrap, paging } from "../../lib/http";
import { UserError } from "../../lib/errors";
import { LIMITS } from "../../lib/limits";
import multer from "multer";
import { audit, requirePerm } from "../../middleware/auth";
import { productInput, variantInput } from "../../lib/layoutSchema";
import { validateHttpsUrl } from "../../lib/validate";
import { PRIVATE_REF, storePrivateFile } from "../../lib/storage";

export const productsRouter = Router();
const idp = z.string().min(1).max(40);

function checkDelivery(b: z.output<typeof productInput>) {
  if (b.productType === "MANUAL" && b.deliveryType !== "MANUAL") throw new UserError("Manually fulfilled products must use the Manual delivery type");
  if (b.productType === "LICENSE_KEY" && b.deliveryType === "FILE_URL") throw new UserError("License-key products cannot use a download link as delivery");
  if (b.deliveryType === "MANUAL" && !b.deliveryInstructions && !b.inputLabel) {
    // allowed, but the buyer then gets no guidance; surfaced as a warning rather than an error
  }
  if (b.deliveryType === "FILE_URL") {
    if (b.deliveryFileUrl && b.deliveryFileUrl.startsWith("b2://")) {
      if (!PRIVATE_REF.test(b.deliveryFileUrl)) throw new UserError("Download file: invalid uploaded-file reference");
      return b.deliveryFileUrl;
    }
    const r = validateHttpsUrl(b.deliveryFileUrl ?? "");
    if (!r.ok) throw new UserError(`Download link: ${r.reason}`);
    return r.url;
  }
  return null;
}

async function checkCategories(ids: string[]) {
  if (!ids.length) return;
  const rows = await prisma.category.findMany({ where: { id: { in: ids } }, select: { id: true, status: true } });
  if (rows.length !== new Set(ids).size) throw new UserError("One or more categories do not exist");
  if (rows.some((r) => r.status === "ARCHIVED")) throw new UserError("Archived categories cannot be assigned");
}

function warningsFor(b: z.output<typeof productInput>): string[] {
  const w: string[] = [];
  if (b.deliveryType === "MANUAL") w.push("Orders for this product wait in Processing until you fulfil them from the Orders screen.");
  if (b.deliveryType === "MANUAL" && !b.inputLabel) w.push("No buyer input is requested. If you need an account or player ID, set \"Ask the buyer for\".");
  if (!b.categoryIds.length) w.push("Not assigned to any category: it will show in the general shop only.");
  return w;
}

const dataOf = (b: z.output<typeof productInput>, fileUrl: string | null) => ({
  name: b.name, description: b.description, features: b.features, imageUrl: b.imageUrl, price: new Prisma.Decimal(b.price),
  discountType: b.discountType, discountValue: b.discountType === "NONE" ? null : new Prisma.Decimal(b.discountValue!),
  discountStartsAt: b.discountStartsAt, discountEndsAt: b.discountEndsAt, stock: b.stock, featured: b.featured,
  productType: b.productType, deliveryType: b.deliveryType, deliveryFileUrl: fileUrl, deliveryInstructions: b.deliveryInstructions,
  inputLabel: b.inputLabel, cardLayout: b.cardLayout, faq: b.faq as any, categoryId: b.primaryCategoryId ?? b.categoryIds[0] ?? null,
});

async function syncAssignments(tx: Prisma.TransactionClient, productId: string, ids: string[]) {
  await tx.productCategory.deleteMany({ where: { productId, categoryId: { notIn: ids } } });
  const have = new Set((await tx.productCategory.findMany({ where: { productId }, select: { categoryId: true } })).map((r) => r.categoryId));
  const add = ids.filter((i) => !have.has(i));
  if (add.length) {
    const tails = await tx.productCategory.groupBy({ by: ["categoryId"], where: { categoryId: { in: add } }, _max: { sortOrder: true } });
    const next = new Map(tails.map((t) => [t.categoryId, (t._max.sortOrder ?? -1) + 1]));
    await tx.productCategory.createMany({ data: add.map((categoryId) => ({ productId, categoryId, sortOrder: next.get(categoryId) ?? 0 })) });
  }
}

/* ---------- list / detail ---------- */
productsRouter.get("/products", requirePerm("products.view"), wrap(async (req, res) => {
  const q = z.object({
    q: z.string().max(80).optional(), status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).optional(),
    categoryId: idp.optional(), type: z.string().max(30).optional(), lowStock: z.enum(["true"]).optional(),
    ids: z.string().max(2000).optional(),
  }).parse(req.query);
  const { take, skip, page } = paging(req.query, 100);
  const idList = q.ids ? q.ids.split(",").map((x) => x.trim()).filter(Boolean).slice(0, 100) : null;
  const where: Prisma.ProductWhereInput = {
    ...(idList ? { id: { in: idList } } : {}),
    status: idList ? undefined : q.status ?? { not: "ARCHIVED" },
    ...(q.q ? { OR: [{ name: { contains: q.q, mode: "insensitive" } }, { id: q.q }] } : {}),
    ...(q.categoryId ? { categories: { some: { categoryId: q.categoryId } } } : {}),
    ...(q.type ? { productType: q.type as any } : {}),
    ...(q.lowStock ? { stock: { lte: 5, not: null } } : {}),
  };
  const [total, rows] = await Promise.all([
    prisma.product.count({ where }),
    prisma.product.findMany({
      where, orderBy: { createdAt: "desc" }, take, skip,
      include: { categories: { include: { category: { select: { id: true, name: true } } } }, _count: { select: { keys: { where: { usedAt: null } }, variants: true, orderItems: true } } },
    }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items: rows.map((p) => ({ ...p, availableKeys: p._count.keys, variantCount: p._count.variants, orderCount: p._count.orderItems, _count: undefined })) });
}));

productsRouter.get("/products/:id", requirePerm("products.view"), wrap(async (req, res) => {
  const p = await prisma.product.findUnique({
    where: { id: req.params.id },
    include: {
      categories: { include: { category: { select: { id: true, name: true, status: true } } } },
      variants: { orderBy: { sortOrder: "asc" } },
      buttons: { orderBy: { sortOrder: "asc" } },
    },
  });
  if (!p) throw new UserError("Product not found", 404);
  const keyRows = await prisma.productKey.groupBy({ by: ["variantId"], where: { productId: p.id, usedAt: null }, _count: { _all: true } });
  const usedKeys = await prisma.productKey.count({ where: { productId: p.id, usedAt: { not: null } } });
  const notices = await prisma.announcement.findMany({ where: { audience: "PRODUCTS", productIds: { has: p.id } }, select: { id: true, title: true, enabled: true, expiresAt: true } });
  res.json({ ...p, keyStock: Object.fromEntries(keyRows.map((r) => [r.variantId ?? "_product", r._count._all])), usedKeys, notices });
}));

/* ---------- create / update ---------- */
productsRouter.post("/products", requirePerm("products.edit"), wrap(async (req, res) => {
  const b = productInput.parse(req.body);
  const fileUrl = checkDelivery(b);
  await checkCategories(b.categoryIds);
  const p = await prisma.$transaction(async (tx) => {
    const row = await tx.product.create({ data: { ...dataOf(b, fileUrl), status: "DRAFT" } });
    await syncAssignments(tx, row.id, b.categoryIds);
    return row;
  });
  await audit(req, "product.create", "Product", p.id, { name: p.name });
  res.status(201).json({ product: p, warnings: warningsFor(b) });
}));

productsRouter.put("/products/:id", requirePerm("products.edit"), wrap(async (req, res) => {
  const cur = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Product not found", 404);
  if (cur.status === "ARCHIVED") throw new UserError("Restore this product before editing it");
  const b = productInput.parse(req.body);
  const fileUrl = checkDelivery(b);
  await checkCategories(b.categoryIds);
  if (cur.deliveryType === "TEXT_KEYS" && b.deliveryType !== "TEXT_KEYS") {
    const open = await prisma.productKey.count({ where: { productId: cur.id, usedAt: null } });
    if (open > 0) throw new UserError(`${open} unsold keys exist. Remove them before changing the delivery type`);
  }
  const p = await prisma.$transaction(async (tx) => {
    const row = await tx.product.update({ where: { id: cur.id }, data: dataOf(b, fileUrl) });
    await syncAssignments(tx, cur.id, b.categoryIds);
    return row;
  });
  await audit(req, "product.update", "Product", p.id, { name: p.name, price: p.price.toString() });
  res.json({ product: p, warnings: warningsFor(b) });
}));

productsRouter.post("/products/:id/duplicate", requirePerm("products.edit"), wrap(async (req, res) => {
  const src = await prisma.product.findUnique({ where: { id: req.params.id }, include: { categories: true, variants: true } });
  if (!src) throw new UserError("Product not found", 404);
  const copy = await prisma.$transaction(async (tx) => {
    const { id, createdAt, updatedAt, salesCount, archivedAt, status, ...rest } = src as any;
    void id; void createdAt; void updatedAt; void salesCount; void archivedAt; void status;
    delete rest.categories; delete rest.variants;
    const p = await tx.product.create({ data: { ...rest, name: `${src.name} (copy)`.slice(0, 120), status: "DRAFT", featured: false, faq: src.faq as any } });
    if (src.categories.length) await tx.productCategory.createMany({ data: src.categories.map((c) => ({ productId: p.id, categoryId: c.categoryId, sortOrder: c.sortOrder })) });
    for (const v of src.variants) await tx.productVariant.create({ data: { productId: p.id, name: v.name, sku: null, price: v.price, stock: v.stock, sortOrder: v.sortOrder, status: v.status } });
    return p; // keys are never copied
  });
  await audit(req, "product.duplicate", "Product", copy.id, { from: src.id });
  res.status(201).json(copy);
}));

/* ---------- lifecycle ---------- */
productsRouter.post("/products/:id/publish", requirePerm("products.publish"), wrap(async (req, res) => {
  const p = await prisma.product.findUnique({ where: { id: req.params.id }, include: { variants: true } });
  if (!p) throw new UserError("Product not found", 404);
  if (p.status === "ARCHIVED") throw new UserError("Restore this product first");
  if (p.deliveryType === "FILE_URL" && !p.deliveryFileUrl) throw new UserError("Add a download link before publishing");
  const row = await prisma.product.update({ where: { id: p.id }, data: { status: "PUBLISHED" } });
  const warnings: string[] = [];
  if (p.deliveryType === "TEXT_KEYS") {
    const keys = await prisma.productKey.count({ where: { productId: p.id, usedAt: null } });
    if (keys === 0) warnings.push("No keys are in stock yet, so customers will see this product as sold out.");
  }
  await audit(req, "product.publish", "Product", p.id);
  res.json({ product: row, warnings });
}));
productsRouter.post("/products/:id/unpublish", requirePerm("products.publish"), wrap(async (req, res) => {
  const row = await prisma.product.update({ where: { id: req.params.id }, data: { status: "DRAFT" } });
  await audit(req, "product.unpublish", "Product", row.id);
  res.json({ product: row });
}));
productsRouter.post("/products/:id/archive", requirePerm("products.publish"), wrap(async (req, res) => {
  const row = await prisma.product.update({ where: { id: req.params.id }, data: { status: "ARCHIVED", archivedAt: new Date(), featured: false } });
  await audit(req, "product.archive", "Product", row.id);
  res.json({ product: row });
}));
productsRouter.post("/products/:id/restore", requirePerm("products.publish"), wrap(async (req, res) => {
  const cur = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!cur || cur.status !== "ARCHIVED") throw new UserError("Only archived products can be restored");
  const row = await prisma.product.update({ where: { id: cur.id }, data: { status: "DRAFT", archivedAt: null } });
  await audit(req, "product.restore", "Product", row.id);
  res.json({ product: row });
}));

// Products with order history are never hard-deleted (orders keep their snapshots, but the link must stay): they are archived instead.
productsRouter.delete("/products/:id", requirePerm("products.delete"), wrap(async (req, res) => {
  const cur = await prisma.product.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Product not found", 404);
  const orders = await prisma.orderItem.count({ where: { productId: cur.id } });
  if (orders > 0) {
    await prisma.product.update({ where: { id: cur.id }, data: { status: "ARCHIVED", archivedAt: new Date(), featured: false } });
    await audit(req, "product.archive", "Product", cur.id, { reason: "has orders" });
    return res.json({ ok: true, archivedInstead: true, message: `This product has ${orders} order line(s), so it was archived instead of deleted.` });
  }
  await prisma.product.delete({ where: { id: cur.id } });
  await audit(req, "product.delete", "Product", cur.id, { name: cur.name });
  res.json({ ok: true });
}));

/* ---------- variants ---------- */
productsRouter.post("/products/:id/variants", requirePerm("products.edit"), wrap(async (req, res) => {
  const b = variantInput.parse(req.body);
  const n = await prisma.productVariant.count({ where: { productId: req.params.id } });
  if (n >= LIMITS.maxVariantsPerProduct) throw new UserError(`At most ${LIMITS.maxVariantsPerProduct} variants per product`);
  const p = await prisma.product.findUnique({ where: { id: req.params.id }, select: { id: true } });
  if (!p) throw new UserError("Product not found", 404);
  const v = await prisma.productVariant.create({ data: { productId: p.id, name: b.name, sku: b.sku, price: b.price ? new Prisma.Decimal(b.price) : null, stock: b.stock, status: b.status, sortOrder: n } });
  await audit(req, "variant.create", "ProductVariant", v.id, { productId: p.id });
  res.status(201).json(v);
}));
productsRouter.put("/variants/:vid", requirePerm("products.edit"), wrap(async (req, res) => {
  const b = variantInput.parse(req.body);
  const v = await prisma.productVariant.update({ where: { id: req.params.vid }, data: { name: b.name, sku: b.sku, price: b.price ? new Prisma.Decimal(b.price) : null, stock: b.stock, status: b.status } });
  await audit(req, "variant.update", "ProductVariant", v.id);
  res.json(v);
}));
productsRouter.delete("/variants/:vid", requirePerm("products.edit"), wrap(async (req, res) => {
  const sold = await prisma.orderItem.count({ where: { variantId: req.params.vid } });
  if (sold > 0) {
    await prisma.productVariant.update({ where: { id: req.params.vid }, data: { status: "DRAFT" } });
    await audit(req, "variant.hide", "ProductVariant", req.params.vid, { reason: "has orders" });
    return res.json({ ok: true, hiddenInstead: true });
  }
  await prisma.productVariant.delete({ where: { id: req.params.vid } });
  await audit(req, "variant.delete", "ProductVariant", req.params.vid);
  res.json({ ok: true });
}));
productsRouter.post("/products/:id/variants/reorder", requirePerm("products.edit"), wrap(async (req, res) => {
  const { ids } = z.object({ ids: z.array(idp).min(1).max(LIMITS.maxVariantsPerProduct) }).parse(req.body);
  const rows = await prisma.productVariant.findMany({ where: { productId: req.params.id }, select: { id: true } });
  if (rows.length !== ids.length || !ids.every((i) => rows.some((r) => r.id === i))) throw new UserError("The list must contain every variant exactly once");
  await prisma.$transaction(ids.map((id, i) => prisma.productVariant.update({ where: { id }, data: { sortOrder: i } })));
  res.json({ ok: true });
}));

/* ---------- inventory (keys) ---------- */
productsRouter.post("/products/:id/keys", requirePerm("inventory.manage"), wrap(async (req, res) => {
  const b = z.object({ keys: z.array(z.string().trim().min(1).max(2000)).min(1).max(LIMITS.maxKeysPerUpload), variantId: idp.optional() }).parse(req.body);
  const p = await prisma.product.findUnique({ where: { id: req.params.id }, include: { variants: { select: { id: true } } } });
  if (!p) throw new UserError("Product not found", 404);
  if (p.deliveryType !== "TEXT_KEYS") throw new UserError("Keys can only be added to products that use key delivery");
  if (p.variants.length && !b.variantId) throw new UserError("Choose which variant these keys belong to");
  if (b.variantId && !p.variants.some((v) => v.id === b.variantId)) throw new UserError("Variant does not belong to this product");
  const unique = [...new Set(b.keys)];
  const r = await prisma.productKey.createMany({ data: unique.map((secret) => ({ productId: p.id, variantId: b.variantId ?? null, secret })) });
  await audit(req, "inventory.keys.add", "Product", p.id, { count: r.count, variantId: b.variantId ?? null }); // never log the keys themselves
  res.json({ added: r.count, duplicatesIgnored: b.keys.length - unique.length });
}));

productsRouter.get("/products/:id/keys", requirePerm("inventory.manage"), wrap(async (req, res) => {
  const { take, skip } = paging(req.query, 100);
  const rows = await prisma.productKey.findMany({ where: { productId: req.params.id, usedAt: null }, orderBy: { createdAt: "desc" }, take, skip, select: { id: true, variantId: true, createdAt: true, secret: true } });
  // Unsold keys are shown masked; the full value is never needed in the panel.
  res.json(rows.map((k) => ({ id: k.id, variantId: k.variantId, createdAt: k.createdAt, preview: k.secret.length > 6 ? `${k.secret.slice(0, 3)}••••${k.secret.slice(-2)}` : "••••" })));
}));

productsRouter.delete("/keys/:kid", requirePerm("inventory.manage"), wrap(async (req, res) => {
  const k = await prisma.productKey.findUnique({ where: { id: req.params.kid } });
  if (!k) throw new UserError("Key not found", 404);
  if (k.usedAt) throw new UserError("This key has already been delivered and cannot be removed");
  await prisma.productKey.delete({ where: { id: k.id } });
  await audit(req, "inventory.keys.remove", "Product", k.productId);
  res.json({ ok: true });
}));

/* ---------- related orders ---------- */
productsRouter.get("/products/:id/orders", requirePerm("products.view", "orders.view"), wrap(async (req, res) => {
  const { take, skip } = paging(req.query);
  const items = await prisma.orderItem.findMany({
    where: { productId: req.params.id }, orderBy: { order: { createdAt: "desc" } }, take, skip,
    select: { id: true, quantity: true, unitPrice: true, variantName: true, customerInput: true, deliveredAt: true, order: { select: { id: true, orderNo: true, status: true, createdAt: true, user: { select: { id: true, username: true, firstName: true } } } } },
  });
  res.json(items);
}));

// Paid-download upload (PDF/ZIP) into the PRIVATE B2 bucket. The product stores only the "b2://..." reference.
const fileUploader = multer({ storage: multer.memoryStorage(), limits: { fileSize: 25 * 1024 * 1024, files: 1 } });
productsRouter.post("/upload-file", requirePerm("products.edit"), fileUploader.single("file"), wrap(async (req, res) => {
  if (!req.file) throw new UserError("Choose a PDF or ZIP file (max 25 MB)");
  let ref: string;
  try {
    ref = await storePrivateFile(req.file.buffer, req.file.originalname || "file");
  } catch (e: any) {
    throw new UserError(e.message);
  }
  await audit(req, "upload.file", "Upload", ref.slice(-60));
  res.status(201).json({ ref });
}));
