import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "../../db";
import { config } from "../../config";
import { wrap, paging } from "../../lib/http";
import { UserError } from "../../lib/errors";
import { hasMarkup } from "../../lib/validate";
import { audit, requirePerm } from "../../middleware/auth";
import { finalizeDeposit, rejectDeposit } from "../../services/deposits";
import { refundOrder } from "../../services/orders";
import { notifyUser } from "../../services/notify";
import { InsufficientFunds, postEntry } from "../../services/ledger";
import { getAdapter } from "../../payments/providers";
import { integrationUsableForVerification, clearSecret, listIntegrations, replaceSecret, testIntegration, updateIntegration, viewOf } from "../../services/integrations";

export const moneyRouter = Router();
const limiter = rateLimit({ windowMs: 60_000, limit: 60 });
const idp = z.string().min(1).max(40);

/* ============================================================
 * Payment methods (personal MFS numbers + verification mode)
 * ============================================================ */
const providerSchema = z.object({
  displayName: z.string().trim().min(1).max(40).optional(),
  enabled: z.boolean().optional(),
  verificationMode: z.enum(["API", "MANUAL_REVIEW", "DISABLED"]).optional(),
  receiverNumber: z.string().trim().regex(/^[0-9+\- ]{6,20}$/, "Enter the number customers should pay, digits only").nullable().optional(),
  instructions: z.string().trim().max(2000).refine((s) => !hasMarkup(s), "Plain text only").nullable().optional(),
  minAmount: z.number().positive().max(10_000_000).nullable().optional(),
  maxAmount: z.number().positive().max(10_000_000).nullable().optional(),
  sortOrder: z.number().int().min(0).max(1000).optional(),
});

moneyRouter.get("/providers", requirePerm("payments.configure"), wrap(async (_req, res) => {
  const rows = await prisma.paymentProvider.findMany({ orderBy: { sortOrder: "asc" } });
  const out = [];
  for (const p of rows) {
    const a = getAdapter(p.code);
    out.push({
      ...p,
      adapterImplemented: a?.meta.implemented ?? false,
      adapterConfigured: a ? await a.isConfigured() : false,
      // True only when verification by API would really be attempted for this provider right now.
      apiVerificationReady: a ? (a.capabilities().apiVerification && (await integrationUsableForVerification(p.code))) : false,
    });
  }
  res.json(out);
}));

moneyRouter.patch("/providers/:code", requirePerm("payments.configure"), wrap(async (req, res) => {
  const body = providerSchema.parse(req.body);
  const cur = await prisma.paymentProvider.findUnique({ where: { code: req.params.code } });
  if (!cur) throw new UserError("Unknown payment method", 404);
  if (cur.isFuture && (body.enabled || (body.verificationMode && body.verificationMode !== "DISABLED"))) {
    throw new UserError("This provider is a future module and cannot be enabled yet");
  }
  const mode = body.verificationMode ?? cur.verificationMode;
  const enabled = body.enabled ?? cur.enabled;
  if (enabled && mode === "DISABLED") throw new UserError("Choose API verification or manual review before enabling");
  if (mode === "API") {
    const a = getAdapter(cur.code);
    if (!a || !a.capabilities().apiVerification || !(await integrationUsableForVerification(cur.code))) {
      throw new UserError("Automatic verification is not available for this provider: it needs an implemented adapter, saved credentials and a successful connection test on the API Integrations page. Use manual review instead.");
    }
  }
  const number = body.receiverNumber !== undefined ? body.receiverNumber : cur.receiverNumber;
  if (enabled && !number) throw new UserError("Set the receiving number before enabling this method");
  const min = body.minAmount !== undefined ? body.minAmount : cur.minAmount ? Number(cur.minAmount) : null;
  const max = body.maxAmount !== undefined ? body.maxAmount : cur.maxAmount ? Number(cur.maxAmount) : null;
  if (min !== null && max !== null && max < min) throw new UserError("Maximum amount must not be below the minimum");
  const p = await prisma.paymentProvider.update({ where: { code: cur.code }, data: body });
  await audit(req, "provider.update", "PaymentProvider", p.code, { ...body, receiverNumber: body.receiverNumber ? "changed" : undefined });
  res.json(p);
}));

/* ============================================================
 * Deposits (review queue)
 * ============================================================ */
moneyRouter.get("/deposits", requirePerm("deposits.view"), wrap(async (req, res) => {
  const q = z.object({ status: z.enum(["PENDING", "SUCCESSFUL", "FAILED", "EXPIRED", "REJECTED"]).optional(), needsReview: z.enum(["true"]).optional(), q: z.string().max(60).optional() }).parse(req.query);
  const { take, skip, page } = paging(req.query);
  const where: Prisma.DepositWhereInput = {
    status: q.status, ...(q.needsReview ? { needsReview: true } : {}),
    ...(q.q ? { OR: [{ invoiceNo: { contains: q.q, mode: "insensitive" } }, { providerTrxId: { contains: q.q.toUpperCase() } }] } : {}),
  };
  const [total, items] = await Promise.all([
    prisma.deposit.count({ where }),
    prisma.deposit.findMany({ where, orderBy: { createdAt: "desc" }, take, skip, include: { provider: { select: { displayName: true, code: true } }, user: { select: { id: true, username: true, firstName: true } } } }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items });
}));

moneyRouter.get("/deposits/:id", requirePerm("deposits.view"), wrap(async (req, res) => {
  const d = await prisma.deposit.findUnique({ where: { id: req.params.id }, include: { provider: true, transactions: true, events: { orderBy: { createdAt: "asc" } }, user: { select: { id: true, username: true, firstName: true } } } });
  if (!d) throw new UserError("Deposit not found", 404);
  res.json(d);
}));

// Manual-review approval: a human attests they saw this exact transaction in the merchant account. Fresh login + audited.
moneyRouter.post("/deposits/:id/approve", limiter, requirePerm("deposits.review"), wrap(async (req, res) => {
  const b = z.object({ confirmedAmount: z.union([z.number(), z.string()]), note: z.string().max(300).optional() }).parse(req.body);
  const d = await prisma.deposit.findUnique({ where: { id: req.params.id }, include: { provider: true } });
  if (!d) throw new UserError("Deposit not found", 404);
  if (d.provider.verificationMode !== "MANUAL_REVIEW") throw new UserError("Only manual-review payment methods can be approved by hand");
  if (!d.providerTrxId) throw new UserError("The customer has not submitted a transaction ID yet");
  // Reviewer must re-type the amount they saw in the merchant app: guards against approving the wrong row.
  if (!new Prisma.Decimal(b.confirmedAmount).equals(d.amount)) throw new UserError(`Amount mismatch: this deposit expects exactly ${d.amount}. Check the transaction in your merchant account.`);
  const result = await finalizeDeposit(d.id, { providerTrxId: d.providerTrxId, amount: d.amount.toString(), senderNumber: d.senderNumber ?? undefined, source: "admin" }, req.admin!.id);
  await audit(req, "deposit.approve", "Deposit", d.id, { result, note: b.note });
  res.json({ result });
}));

moneyRouter.post("/deposits/:id/reject", limiter, requirePerm("deposits.review"), wrap(async (req, res) => {
  const b = z.object({ reason: z.string().trim().min(3).max(300) }).parse(req.body);
  await rejectDeposit(req.params.id, req.admin!.id, b.reason);
  await audit(req, "deposit.reject", "Deposit", req.params.id, b);
  res.json({ ok: true });
}));

/* ============================================================
 * Ledger + audited wallet adjustments
 * ============================================================ */
moneyRouter.get("/ledger", requirePerm("ledger.view"), wrap(async (req, res) => {
  const q = z.object({ userId: idp.optional(), type: z.enum(["DEPOSIT", "PURCHASE", "REFUND", "ADJUSTMENT"]).optional() }).parse(req.query);
  const { take, skip, page } = paging(req.query, 100);
  const where: Prisma.LedgerEntryWhereInput = { type: q.type, ...(q.userId ? { wallet: { userId: q.userId } } : {}) };
  const [total, items] = await Promise.all([
    prisma.ledgerEntry.count({ where }),
    prisma.ledgerEntry.findMany({ where, orderBy: { createdAt: "desc" }, take, skip, include: { wallet: { select: { userId: true, user: { select: { username: true, firstName: true } } } } } }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items });
}));

moneyRouter.post("/users/:id/wallet-adjust", limiter, requirePerm("wallet.adjust"), wrap(async (req, res) => {
  const b = z.object({
    direction: z.enum(["CREDIT", "DEBIT"]),
    amount: z.union([z.number(), z.string()]).transform((v) => new Prisma.Decimal(v)).refine((d) => d.isFinite() && d.gt(0) && d.decimalPlaces() <= 2, "Enter a positive amount with up to 2 decimals"),
    reason: z.string().trim().min(8, "Give a clear reason (at least 8 characters)").max(300),
  }).parse(req.body);
  if (b.amount.gt(config.maxWalletAdjustment)) throw new UserError(`A single adjustment cannot exceed ${config.maxWalletAdjustment}`);
  const user = await prisma.user.findUnique({ where: { id: req.params.id } });
  if (!user) throw new UserError("User not found", 404);
  let adj;
  try {
    adj = await prisma.$transaction(async (tx) => {
      await tx.wallet.upsert({ where: { userId: user.id }, update: {}, create: { userId: user.id } });
      const a = await tx.walletAdjustment.create({ data: { userId: user.id, adminId: req.admin!.id, direction: b.direction, amount: b.amount, reason: b.reason } });
      await postEntry(tx, { userId: user.id, type: "ADJUSTMENT", direction: b.direction, amount: b.amount, refType: "adjustment", refId: a.id, note: `Admin adjustment: ${b.reason}`.slice(0, 300) });
      return a;
    });
  } catch (e) {
    if (e instanceof InsufficientFunds) throw new UserError("The debit is larger than the user's balance");
    throw e;
  }
  await audit(req, "wallet.adjust", "User", user.id, { adjustmentId: adj.id, direction: b.direction, amount: b.amount.toString(), reason: b.reason });
  await notifyUser(user.id, "PAYMENT", "Wallet updated", `Your wallet was ${b.direction === "CREDIT" ? "credited" : "debited"} ${b.amount} by support.`, "/wallet");
  res.status(201).json(adj);
}));

moneyRouter.get("/wallet-adjustments", requirePerm("ledger.view"), wrap(async (req, res) => {
  const { take, skip } = paging(req.query);
  res.json(await prisma.walletAdjustment.findMany({ orderBy: { createdAt: "desc" }, take, skip, include: { user: { select: { id: true, username: true, firstName: true } } } }));
}));

/* ============================================================
 * Orders: view, manual fulfilment, refunds
 * ============================================================ */
moneyRouter.get("/orders", requirePerm("orders.view"), wrap(async (req, res) => {
  const q = z.object({
    status: z.enum(["PENDING", "PAID", "PROCESSING", "DELIVERED", "CANCELLED", "REFUNDED"]).optional(),
    refunds: z.enum(["requested"]).optional(), q: z.string().max(60).optional(), manual: z.enum(["true"]).optional(),
  }).parse(req.query);
  const { take, skip, page } = paging(req.query);
  const where: Prisma.OrderWhereInput = {
    status: q.status, ...(q.refunds ? { refundStatus: "REQUESTED" } : {}),
    ...(q.manual ? { status: "PROCESSING" } : {}),
    ...(q.q ? { OR: [{ orderNo: { contains: q.q.toUpperCase() } }, { user: { username: { contains: q.q, mode: "insensitive" } } }] } : {}),
  };
  const [total, items] = await Promise.all([
    prisma.order.count({ where }),
    prisma.order.findMany({ where, orderBy: { createdAt: "desc" }, take, skip, include: { user: { select: { id: true, username: true, firstName: true } }, items: { select: { id: true, productId: true, productName: true, variantName: true, quantity: true, unitPrice: true, customerInput: true, deliveredAt: true } } } }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items });
}));

moneyRouter.get("/orders/:id", requirePerm("orders.view"), wrap(async (req, res) => {
  const o = await prisma.order.findUnique({ where: { id: req.params.id }, include: { user: { select: { id: true, username: true, firstName: true } }, items: { include: { product: { select: { name: true, deliveryType: true, deliveryInstructions: true, inputLabel: true } } } } } });
  if (!o) throw new UserError("Order not found", 404);
  const refund = await prisma.ledgerEntry.findFirst({ where: { refType: "refund", refId: o.id } });
  res.json({ ...o, refundLedgerEntry: refund });
}));

moneyRouter.post("/orders/:id/refund", limiter, requirePerm("orders.refund"), wrap(async (req, res) => {
  const o = await refundOrder(req.params.id, req.admin!.id);
  await audit(req, "order.refund", "Order", o.id, { total: o.total.toString() });
  res.json(o);
}));

moneyRouter.post("/orders/:id/refund-reject", requirePerm("orders.refund"), wrap(async (req, res) => {
  const b = z.object({ reason: z.string().trim().min(3).max(300).optional() }).parse(req.body ?? {});
  const cur = await prisma.order.findUnique({ where: { id: req.params.id } });
  if (!cur || cur.refundStatus !== "REQUESTED") throw new UserError("There is no pending refund request on this order");
  const o = await prisma.order.update({ where: { id: cur.id }, data: { refundStatus: "REJECTED" } });
  await notifyUser(o.userId, "REFUND", "Refund declined", `Your refund request for order ${o.orderNo} was declined.${b.reason ? " " + b.reason : ""}`, `/orders/${o.id}`);
  await audit(req, "order.refund_reject", "Order", o.id, b);
  res.json({ ok: true });
}));

// Manual fulfilment: the operator supplies what the buyer receives. The order completes only when every line is delivered.
moneyRouter.post("/orders/:id/deliver", requirePerm("orders.fulfil"), wrap(async (req, res) => {
  const b = z.object({ itemId: idp, data: z.string().trim().min(1).max(5000) }).parse(req.body);
  const item = await prisma.orderItem.findFirst({ where: { id: b.itemId, orderId: req.params.id }, include: { order: true } });
  if (!item) throw new UserError("Order line not found", 404);
  if (!["PAID", "PROCESSING"].includes(item.order.status)) throw new UserError(`An order in status ${item.order.status} cannot be fulfilled`);
  await prisma.orderItem.update({ where: { id: item.id }, data: { deliveredData: b.data, deliveredAt: new Date() } });
  const pending = await prisma.orderItem.count({ where: { orderId: item.orderId, deliveredAt: null } });
  if (pending === 0) {
    const o = await prisma.order.update({ where: { id: item.orderId }, data: { status: "DELIVERED" } });
    await notifyUser(o.userId, "DELIVERY", "Order delivered", `Your items for order ${o.orderNo} are ready.`, `/orders/${o.id}`);
  }
  await audit(req, "order.deliver", "Order", item.orderId, { itemId: item.id }); // the delivered content itself is not logged
  res.json({ ok: true, remaining: pending });
}));

moneyRouter.post("/orders/:id/note", requirePerm("orders.fulfil"), wrap(async (req, res) => {
  const b = z.object({ note: z.string().trim().max(1000) }).parse(req.body);
  await prisma.order.update({ where: { id: req.params.id }, data: { adminNote: b.note || null } });
  await audit(req, "order.note", "Order", req.params.id);
  res.json({ ok: true });
}));

/* ============================================================
 * API integrations (status is computed by the server; secrets never leave it)
 * ============================================================ */
const modeSchema = z.enum(["sandbox", "production"]);

moneyRouter.get("/integrations", requirePerm("integrations.view"), wrap(async (_req, res) => res.json(await listIntegrations())));
moneyRouter.get("/integrations/:code", requirePerm("integrations.view"), wrap(async (req, res) => res.json(await viewOf(req.params.code))));

moneyRouter.patch("/integrations/:code", requirePerm("integrations.manage"), wrap(async (req, res) => {
  const b = z.object({ enabled: z.boolean().optional(), mode: modeSchema.optional(), settings: z.record(z.string().max(4000)).optional() }).parse(req.body);
  const v = await updateIntegration(req.params.code, b, req.admin!.id);
  await audit(req, "integration.update", "Integration", req.params.code, { enabled: b.enabled, mode: b.mode, settingKeys: b.settings ? Object.keys(b.settings) : undefined });
  res.json(v);
}));

moneyRouter.put("/integrations/:code/secrets/:name", limiter, requirePerm("integrations.secrets"), wrap(async (req, res) => {
  const b = z.object({ mode: modeSchema, value: z.string().min(1).max(8000) }).parse(req.body);
  await replaceSecret(req.params.code, req.params.name, b.mode, b.value, req.admin!.id);
  await audit(req, "integration.secret.replace", "Integration", req.params.code, { name: req.params.name, mode: b.mode }); // value is never logged
  res.json(await viewOf(req.params.code));
}));

moneyRouter.delete("/integrations/:code/secrets/:name", requirePerm("integrations.secrets"), wrap(async (req, res) => {
  const b = z.object({ mode: modeSchema }).parse(req.query);
  await clearSecret(req.params.code, req.params.name, b.mode);
  await audit(req, "integration.secret.remove", "Integration", req.params.code, { name: req.params.name, mode: b.mode });
  res.json(await viewOf(req.params.code));
}));

moneyRouter.post("/integrations/:code/test", rateLimit({ windowMs: 60_000, limit: 10 }), requirePerm("integrations.manage"), wrap(async (req, res) => {
  const v = await testIntegration(req.params.code);
  await audit(req, "integration.test", "Integration", req.params.code, { state: v.status.state });
  res.json(v);
}));
