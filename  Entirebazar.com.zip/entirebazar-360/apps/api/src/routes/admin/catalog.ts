import { Router } from "express";
import multer from "multer";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "../../db";
import { config } from "../../config";
import { wrap } from "../../lib/http";
import { UserError } from "../../lib/errors";
import { LIMITS } from "../../lib/limits";
import { audit, requirePerm, requireAny } from "../../middleware/auth";
import {
  BUTTON_ACTIONS, BUTTON_ACTION_LABELS, BUTTON_PLACEMENTS, BUTTON_SIZES, BUTTON_STYLES, HOME_BLOCKS, HOME_BLOCK_LABELS,
  NOTICE_LOCATIONS, PRODUCT_TYPES, SECTION_LABELS, SECTION_TYPES, SORT_OPTIONS, buttonInput, categoryInput, parseSectionConfig,
  sectionInput, sectionPatch, SectionType,
} from "../../lib/layoutSchema";
import { validateExternalUrl } from "../../lib/validate";
import { MAX_UPLOAD_BYTES } from "../../lib/upload";
import { storeImage } from "../../lib/storage";
import { depthOf, isDescendant, loadIndex } from "../../services/catalog";
import { buildCategoryPage, makeViewer, readSettings } from "../../services/pages";
import { getGeneralSettings } from "../../services/settings";
import { assertButtonOwner, assertSectionRefs, uniqueCategorySlug, validateButtonTarget } from "../../services/cms";

export const catalogRouter = Router();
const idParam = z.string().min(1).max(40);
const reorderBody = z.object({ ids: z.array(idParam).min(1).max(500) });

/** Height of a subtree (1 = leaf), used to enforce the maximum depth when moving a branch. */
function subtreeHeight(children: Map<string, { id: string }[]>, id: string): number {
  const kids = children.get(id) ?? [];
  return 1 + (kids.length ? Math.max(...kids.map((k) => subtreeHeight(children, k.id))) : 0);
}

async function checkSupportLink(link: string | null) {
  if (!link) return null;
  const general = await getGeneralSettings();
  const r = validateExternalUrl(link, general.allowedExternalHosts);
  if (!r.ok) throw new UserError(`Support link: ${r.reason}`);
  return r.url;
}

async function checkParent(parentId: string | null, selfId?: string) {
  const idx = await loadIndex();
  if (!parentId) return idx;
  const parent = idx.all.get(parentId);
  if (!parent) throw new UserError("Parent category not found", 404);
  if (parent.status === "ARCHIVED") throw new UserError("Cannot place a category inside an archived category");
  if (selfId) {
    if (parentId === selfId || isDescendant(idx, parentId, selfId)) throw new UserError("A category cannot be moved inside itself");
    const h = subtreeHeight(idx.children as any, selfId);
    if (depthOf(idx, parentId) + h > LIMITS.maxCategoryDepth) throw new UserError(`Categories can be nested at most ${LIMITS.maxCategoryDepth} levels deep`);
  } else if (depthOf(idx, parentId) + 1 > LIMITS.maxCategoryDepth) {
    throw new UserError(`Categories can be nested at most ${LIMITS.maxCategoryDepth} levels deep`);
  }
  return idx;
}

/* ============================================================
 * Meta for the editors: types, defaults, options. Everything the UI offers comes from the server's own schema.
 * ============================================================ */
const SECTION_SAMPLES: Partial<Record<SectionType, Record<string, unknown>>> = {
  PROMO_BANNER: { heading: "Special offer" },
  NOTICE: { heading: "Notice", text: "Write your message here." },
  RICH_TEXT: { text: "Write your text here." },
  HOW_IT_WORKS: { steps: [{ title: "Choose a product", text: "" }, { title: "Pay from your wallet", text: "" }, { title: "Receive your order", text: "" }] },
  TERMS: { text: "Write your terms here." },
  COUNTDOWN: { label: "Offer ends in", endsAt: new Date(Date.now() + 7 * 864e5).toISOString() },
  EMPTY_STATE: { heading: "Nothing here yet" },
};

catalogRouter.get("/cms/meta", requireAny("catalog.view", "products.view", "notices.manage", "settings.manage"), wrap(async (_req, res) => {
  const sections = SECTION_TYPES.map((type) => {
    const sample = SECTION_SAMPLES[type] ?? {};
    const parsed = parseSectionConfig(type, sample);
    return { type, label: SECTION_LABELS[type], defaults: parsed.success ? JSON.parse(JSON.stringify(parsed.data)) : sample, needsInput: !parseSectionConfig(type, {}).success };
  });
  res.json({
    sections,
    buttons: { actions: BUTTON_ACTIONS.map((a) => ({ value: a, label: BUTTON_ACTION_LABELS[a] })), styles: BUTTON_STYLES, sizes: BUTTON_SIZES, placements: BUTTON_PLACEMENTS },
    noticeLocations: NOTICE_LOCATIONS,
    homeBlocks: HOME_BLOCKS.map((b) => ({ id: b, label: HOME_BLOCK_LABELS[b] })),
    productTypes: PRODUCT_TYPES,
    sortOptions: SORT_OPTIONS,
    limits: LIMITS,
  });
}));

/* ============================================================
 * Image upload (magic-byte verified, random names, SVG refused)
 * ============================================================ */
const uploader = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_UPLOAD_BYTES, files: 1 } });
catalogRouter.post("/upload", requireAny("catalog.edit", "products.edit", "notices.manage", "settings.manage"), uploader.single("file"), wrap(async (req, res) => {
  if (!req.file) throw new UserError("Choose an image to upload (PNG, JPEG or WebP, max 2 MB)");
  let url: string;
  try {
    url = await storeImage(req.file.buffer);
  } catch (e: any) {
    throw new UserError(e.message);
  }
  await audit(req, "upload.image", "Upload", url.slice(-60));
  res.status(201).json({ url });
}));

/* ============================================================
 * Categories
 * ============================================================ */
catalogRouter.get("/categories", requirePerm("catalog.view"), wrap(async (req, res) => {
  const q = z.object({ status: z.enum(["DRAFT", "PUBLISHED", "ARCHIVED"]).optional(), q: z.string().max(60).optional() }).parse(req.query);
  const rows = await prisma.category.findMany({
    where: {
      // archived rows are only listed when asked for
      status: q.status ?? { not: "ARCHIVED" },
      ...(q.q ? { OR: [{ name: { contains: q.q, mode: "insensitive" } }, { slug: { contains: q.q.toLowerCase() } }] } : {}),
    },
    orderBy: [{ parentId: "asc" }, { sortOrder: "asc" }, { name: "asc" }],
    include: { _count: { select: { products: true, sections: true, children: true, buttons: true } } },
  });
  const idx = await loadIndex();
  res.json(rows.map((c) => ({
    id: c.id, parentId: c.parentId, name: c.name, slug: c.slug, icon: c.icon, imageUrl: c.imageUrl, status: c.status,
    visibility: c.visibility, purchasable: c.purchasable, featured: c.featured, featuredOrder: c.featuredOrder, sortOrder: c.sortOrder,
    publishAt: c.publishAt, unpublishAt: c.unpublishAt, archivedAt: c.archivedAt, updatedAt: c.updatedAt,
    live: idx.live.has(c.id), // really visible to customers right now (ancestors + schedule considered)
    counts: { products: c._count.products, sections: c._count.sections, children: c._count.children, buttons: c._count.buttons },
  })));
}));

catalogRouter.post("/categories", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const b = categoryInput.parse(req.body);
  if ((await prisma.category.count()) >= LIMITS.maxCategories) throw new UserError(`The limit of ${LIMITS.maxCategories} categories has been reached`);
  await checkParent(b.parentId);
  const supportLink = await checkSupportLink(b.supportLink);
  const slug = b.slug ? await uniqueCategorySlug(b.slug) : await uniqueCategorySlug(b.name);
  if (b.slug && slug !== b.slug) throw new UserError(`The slug "${b.slug}" is already used`);
  const last = await prisma.category.aggregate({ _max: { sortOrder: true }, where: { parentId: b.parentId } });
  const c = await prisma.category.create({
    data: {
      ...b, slug, supportLink, status: "DRAFT", sortOrder: (last._max.sortOrder ?? -1) + 1,
      settings: b.settings as any, faq: b.faq as any,
    },
  });
  await audit(req, "category.create", "Category", c.id, { name: c.name, parentId: c.parentId });
  res.status(201).json(c);
}));

async function loadCategoryFull(id: string) {
  const c = await prisma.category.findUnique({
    where: { id },
    include: {
      sections: { orderBy: { sortOrder: "asc" }, include: { buttons: { orderBy: { sortOrder: "asc" } } } },
      buttons: { where: { sectionId: null }, orderBy: { sortOrder: "asc" } },
      products: { orderBy: [{ pinned: "desc" }, { sortOrder: "asc" }], include: { product: { select: { id: true, name: true, imageUrl: true, status: true, price: true } } } },
    },
  });
  if (!c) throw new UserError("Category not found", 404);
  return c;
}

catalogRouter.get("/categories/:id", requirePerm("catalog.view"), wrap(async (req, res) => {
  const c = await loadCategoryFull(req.params.id);
  const idx = await loadIndex();
  res.json({ ...c, settings: readSettings(c.settings), live: idx.live.has(c.id), depth: depthOf(idx, c.id) }); // settings come back with every default filled in for the editor
}));

// Full-form save from the editor. Archived categories must be restored before they can be edited.
catalogRouter.put("/categories/:id", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const cur = await prisma.category.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Category not found", 404);
  if (cur.status === "ARCHIVED") throw new UserError("Restore this category before editing it");
  const b = categoryInput.parse(req.body);
  if (b.parentId !== cur.parentId) await checkParent(b.parentId, cur.id);
  const supportLink = await checkSupportLink(b.supportLink);
  let slug = cur.slug;
  if (b.slug && b.slug !== cur.slug) {
    const free = await uniqueCategorySlug(b.slug, cur.id);
    if (free !== b.slug) throw new UserError(`The slug "${b.slug}" is already used`);
    slug = b.slug;
  }
  const moved = b.parentId !== cur.parentId;
  const last = moved ? await prisma.category.aggregate({ _max: { sortOrder: true }, where: { parentId: b.parentId } }) : null;
  const c = await prisma.category.update({
    where: { id: cur.id },
    data: { ...b, slug, supportLink, settings: b.settings as any, faq: b.faq as any, ...(moved ? { sortOrder: (last!._max.sortOrder ?? -1) + 1 } : {}) },
  });
  await audit(req, "category.update", "Category", c.id, { name: c.name, status: c.status, moved });
  res.json(c);
}));

catalogRouter.post("/categories/:id/duplicate", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const b = z.object({ withProducts: z.boolean().default(false) }).parse(req.body ?? {});
  if ((await prisma.category.count()) >= LIMITS.maxCategories) throw new UserError(`The limit of ${LIMITS.maxCategories} categories has been reached`);
  const src = await loadCategoryFull(req.params.id);
  const slug = await uniqueCategorySlug(`${src.slug}-copy`);
  const last = await prisma.category.aggregate({ _max: { sortOrder: true }, where: { parentId: src.parentId } });
  const copy = await prisma.$transaction(async (tx) => {
    const c = await tx.category.create({
      data: {
        parentId: src.parentId, name: `${src.name} (copy)`.slice(0, 80), slug, description: src.description, icon: src.icon,
        imageUrl: src.imageUrl, coverUrl: src.coverUrl, status: "DRAFT", visibility: src.visibility, purchasable: src.purchasable,
        unavailableMessage: src.unavailableMessage, featured: false, sortOrder: (last._max.sortOrder ?? -1) + 1,
        supportLink: src.supportLink, settings: src.settings as any, faq: src.faq as any, discountPercent: src.discountPercent,
        discountStartsAt: src.discountStartsAt, discountEndsAt: src.discountEndsAt,
      },
    });
    const btn = (x: (typeof src.buttons)[number], owner: Prisma.ActionButtonUncheckedCreateInput) => ({
      ...owner, label: x.label, icon: x.icon, style: x.style, size: x.size, placement: x.placement, action: x.action,
      target: x.target as any, confirmTitle: x.confirmTitle, confirmMessage: x.confirmMessage, visibility: x.visibility as any,
      enabled: x.enabled, sortOrder: x.sortOrder,
    });
    for (const x of src.buttons) await tx.actionButton.create({ data: btn(x, { categoryId: c.id } as any) });
    for (const s of src.sections) {
      const ns = await tx.categorySection.create({
        data: { categoryId: c.id, type: s.type, title: s.title, enabled: s.enabled, sortOrder: s.sortOrder, startsAt: s.startsAt, endsAt: s.endsAt, config: s.config as any },
      });
      for (const x of s.buttons) await tx.actionButton.create({ data: btn(x, { sectionId: ns.id } as any) });
    }
    if (b.withProducts && src.products.length) {
      await tx.productCategory.createMany({ data: src.products.map((p) => ({ categoryId: c.id, productId: p.productId, sortOrder: p.sortOrder, pinned: p.pinned })) });
    }
    return c;
  });
  await audit(req, "category.duplicate", "Category", copy.id, { from: src.id, withProducts: b.withProducts });
  res.status(201).json(copy);
}));

catalogRouter.post("/categories/:id/publish", requirePerm("catalog.publish"), wrap(async (req, res) => {
  const cur = await prisma.category.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Category not found", 404);
  if (cur.status === "ARCHIVED") throw new UserError("Restore this category before publishing it");
  const idx = await loadIndex();
  const warnings: string[] = [];
  let p = cur.parentId ? idx.all.get(cur.parentId) : undefined;
  while (p) {
    if (p.status !== "PUBLISHED") warnings.push(`Parent "${p.name}" is not published, so this category stays hidden until it is.`);
    p = p.parentId ? idx.all.get(p.parentId) : undefined;
  }
  if (cur.publishAt && cur.publishAt > new Date()) warnings.push(`Scheduled: it becomes visible on ${cur.publishAt.toISOString()}.`);
  const c = await prisma.category.update({ where: { id: cur.id }, data: { status: "PUBLISHED", archivedAt: null } });
  await audit(req, "category.publish", "Category", c.id);
  res.json({ category: c, warnings });
}));

catalogRouter.post("/categories/:id/unpublish", requirePerm("catalog.publish"), wrap(async (req, res) => {
  const cur = await prisma.category.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Category not found", 404);
  if (cur.status === "ARCHIVED") throw new UserError("This category is archived");
  const c = await prisma.category.update({ where: { id: cur.id }, data: { status: "DRAFT" } });
  await audit(req, "category.unpublish", "Category", c.id);
  res.json({ category: c });
}));

catalogRouter.post("/categories/:id/archive", requirePerm("catalog.publish"), wrap(async (req, res) => {
  const kids = await prisma.category.count({ where: { parentId: req.params.id, status: { not: "ARCHIVED" } } });
  if (kids > 0) throw new UserError("Archive or move the subcategories first");
  const c = await prisma.category.update({ where: { id: req.params.id }, data: { status: "ARCHIVED", archivedAt: new Date(), featured: false } });
  await audit(req, "category.archive", "Category", c.id);
  res.json({ category: c });
}));

catalogRouter.post("/categories/:id/restore", requirePerm("catalog.publish"), wrap(async (req, res) => {
  const cur = await prisma.category.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Category not found", 404);
  if (cur.status !== "ARCHIVED") throw new UserError("Only archived categories can be restored");
  if (cur.parentId) {
    const parent = await prisma.category.findUnique({ where: { id: cur.parentId } });
    if (!parent || parent.status === "ARCHIVED") throw new UserError("Restore the parent category first");
  }
  const c = await prisma.category.update({ where: { id: cur.id }, data: { status: "DRAFT", archivedAt: null } }); // restored as a draft: re-publish deliberately
  await audit(req, "category.restore", "Category", c.id);
  res.json({ category: c });
}));

catalogRouter.delete("/categories/:id", requirePerm("catalog.delete"), wrap(async (req, res) => {
  const cur = await prisma.category.findUnique({ where: { id: req.params.id }, include: { _count: { select: { children: true, products: true } } } });
  if (!cur) throw new UserError("Category not found", 404);
  if (cur.status !== "ARCHIVED") throw new UserError("Archive the category first; only archived categories can be deleted");
  if (cur._count.children > 0) throw new UserError("Delete or move the subcategories first");
  await prisma.$transaction([
    prisma.product.updateMany({ where: { categoryId: cur.id }, data: { categoryId: null } }),
    prisma.category.delete({ where: { id: cur.id } }), // sections, buttons and product links cascade; products themselves are kept
  ]);
  await audit(req, "category.delete", "Category", cur.id, { name: cur.name, productLinks: cur._count.products });
  res.json({ ok: true });
}));

// Reorder siblings. All ids must share the same parent.
catalogRouter.post("/categories/reorder", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const { ids } = reorderBody.parse(req.body);
  const rows = await prisma.category.findMany({ where: { id: { in: ids } }, select: { id: true, parentId: true } });
  if (rows.length !== new Set(ids).size) throw new UserError("Unknown category in the list");
  if (new Set(rows.map((r) => r.parentId)).size > 1) throw new UserError("Only categories with the same parent can be reordered together");
  await prisma.$transaction(ids.map((id, i) => prisma.category.update({ where: { id }, data: { sortOrder: i } })));
  await audit(req, "category.reorder", "Category", undefined, { count: ids.length });
  res.json({ ok: true });
}));

// Featured-on-homepage ordering.
catalogRouter.post("/categories/featured-order", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const { ids } = reorderBody.parse(req.body);
  await prisma.$transaction(ids.map((id, i) => prisma.category.update({ where: { id }, data: { featuredOrder: i } })));
  await audit(req, "category.featured_order", "Category", undefined, { count: ids.length });
  res.json({ ok: true });
}));

// Preview: renders exactly what customers would get, as an anonymous viewer, even for drafts. Never writes.
catalogRouter.get("/categories/:id/preview", requirePerm("catalog.view"), wrap(async (req, res) => {
  const q = z.object({ q: z.string().max(60).optional(), sort: z.string().max(20).optional(), page: z.coerce.number().int().min(1).optional() }).parse(req.query);
  const c = await prisma.category.findUnique({ where: { id: req.params.id } });
  if (!c) throw new UserError("Category not found", 404);
  const [idx, general] = await Promise.all([loadIndex(), getGeneralSettings()]);
  const page = await buildCategoryPage(c, { idx, viewer: makeViewer(undefined), general, query: q, preview: true });
  const live = idx.live.has(c.id);
  res.json({ page, status: c.status, live, note: live ? "This category is live." : "Draft preview: customers cannot see this category yet." });
}));

/* ---------- Product assignment ---------- */
catalogRouter.post("/categories/:id/products", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const b = z.object({ productIds: z.array(idParam).min(1).max(200) }).parse(req.body);
  const [cat, existing, found] = await Promise.all([
    prisma.category.findUnique({ where: { id: req.params.id } }),
    prisma.productCategory.count({ where: { categoryId: req.params.id } }),
    prisma.product.findMany({ where: { id: { in: b.productIds } }, select: { id: true } }),
  ]);
  if (!cat) throw new UserError("Category not found", 404);
  if (cat.status === "ARCHIVED") throw new UserError("This category is archived");
  if (found.length !== new Set(b.productIds).size) throw new UserError("One or more products do not exist");
  if (existing + found.length > LIMITS.maxProductsPerCategory) throw new UserError(`A category can hold at most ${LIMITS.maxProductsPerCategory} products`);
  const r = await prisma.productCategory.createMany({ data: found.map((p, i) => ({ categoryId: cat.id, productId: p.id, sortOrder: existing + i })), skipDuplicates: true });
  await audit(req, "category.products.add", "Category", cat.id, { added: r.count });
  res.json({ added: r.count });
}));

catalogRouter.delete("/categories/:id/products/:productId", requirePerm("catalog.edit"), wrap(async (req, res) => {
  await prisma.productCategory.deleteMany({ where: { categoryId: req.params.id, productId: req.params.productId } });
  await audit(req, "category.products.remove", "Category", req.params.id, { productId: req.params.productId });
  res.json({ ok: true });
}));

catalogRouter.patch("/categories/:id/products/:productId", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const b = z.object({ pinned: z.boolean().optional(), sortOrder: z.number().int().min(0).max(100000).optional() }).parse(req.body);
  const r = await prisma.productCategory.updateMany({ where: { categoryId: req.params.id, productId: req.params.productId }, data: b });
  if (r.count === 0) throw new UserError("Product is not in this category", 404);
  res.json({ ok: true });
}));

catalogRouter.put("/categories/:id/products/order", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const { ids } = reorderBody.parse(req.body);
  await prisma.$transaction(ids.map((productId, i) => prisma.productCategory.updateMany({ where: { categoryId: req.params.id, productId }, data: { sortOrder: i } })));
  await audit(req, "category.products.order", "Category", req.params.id);
  res.json({ ok: true });
}));

/* ============================================================
 * Sections
 * ============================================================ */
catalogRouter.post("/categories/:id/sections", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const b = sectionInput.parse(req.body);
  const cat = await prisma.category.findUnique({ where: { id: req.params.id }, select: { id: true, status: true } });
  if (!cat) throw new UserError("Category not found", 404);
  if (cat.status === "ARCHIVED") throw new UserError("This category is archived");
  const n = await prisma.categorySection.count({ where: { categoryId: cat.id } });
  if (n >= LIMITS.maxSectionsPerCategory) throw new UserError(`At most ${LIMITS.maxSectionsPerCategory} sections per category`);
  await assertSectionRefs(b.config);
  const s = await prisma.categorySection.create({ data: { ...b, config: b.config as any, categoryId: cat.id, sortOrder: n } });
  await audit(req, "section.create", "CategorySection", s.id, { type: s.type, categoryId: cat.id });
  res.status(201).json(s);
}));

catalogRouter.put("/sections/:sid", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const patch = sectionPatch.parse(req.body);
  const cur = await prisma.categorySection.findUnique({ where: { id: req.params.sid } });
  if (!cur) throw new UserError("Section not found", 404);
  // Merge then re-validate the WHOLE section so partial edits can never produce an invalid config.
  const merged = sectionInput.parse({
    type: cur.type,
    title: patch.title !== undefined ? patch.title : cur.title,
    enabled: patch.enabled ?? cur.enabled,
    startsAt: patch.startsAt !== undefined ? patch.startsAt : cur.startsAt,
    endsAt: patch.endsAt !== undefined ? patch.endsAt : cur.endsAt,
    config: patch.config ?? cur.config,
  });
  await assertSectionRefs(merged.config);
  const s = await prisma.categorySection.update({
    where: { id: cur.id },
    data: { title: merged.title, enabled: merged.enabled, startsAt: merged.startsAt, endsAt: merged.endsAt, config: merged.config as any },
  });
  await audit(req, "section.update", "CategorySection", s.id, { type: s.type, enabled: s.enabled });
  res.json(s);
}));

catalogRouter.post("/sections/:sid/duplicate", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const src = await prisma.categorySection.findUnique({ where: { id: req.params.sid }, include: { buttons: true } });
  if (!src) throw new UserError("Section not found", 404);
  const n = await prisma.categorySection.count({ where: { categoryId: src.categoryId } });
  if (n >= LIMITS.maxSectionsPerCategory) throw new UserError(`At most ${LIMITS.maxSectionsPerCategory} sections per category`);
  const copy = await prisma.$transaction(async (tx) => {
    const s = await tx.categorySection.create({
      data: { categoryId: src.categoryId, type: src.type, title: src.title ? `${src.title} (copy)`.slice(0, 120) : null, enabled: false, sortOrder: n, startsAt: src.startsAt, endsAt: src.endsAt, config: src.config as any },
    });
    for (const b of src.buttons) {
      await tx.actionButton.create({
        data: { sectionId: s.id, label: b.label, icon: b.icon, style: b.style, size: b.size, placement: b.placement, action: b.action, target: b.target as any, confirmTitle: b.confirmTitle, confirmMessage: b.confirmMessage, visibility: b.visibility as any, enabled: b.enabled, sortOrder: b.sortOrder },
      });
    }
    return s;
  });
  await audit(req, "section.duplicate", "CategorySection", copy.id, { from: src.id });
  res.status(201).json(copy);
}));

catalogRouter.delete("/sections/:sid", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const s = await prisma.categorySection.delete({ where: { id: req.params.sid } }).catch(() => null);
  if (!s) throw new UserError("Section not found", 404);
  await audit(req, "section.delete", "CategorySection", s.id, { type: s.type });
  res.json({ ok: true });
}));

catalogRouter.post("/categories/:id/sections/reorder", requirePerm("catalog.edit"), wrap(async (req, res) => {
  const { ids } = reorderBody.parse(req.body);
  const rows = await prisma.categorySection.findMany({ where: { categoryId: req.params.id }, select: { id: true } });
  if (rows.length !== ids.length || !ids.every((i) => rows.some((r) => r.id === i))) throw new UserError("The list must contain every section of this category exactly once");
  await prisma.$transaction(ids.map((id, i) => prisma.categorySection.update({ where: { id }, data: { sortOrder: i } })));
  await audit(req, "section.reorder", "Category", req.params.id);
  res.json({ ok: true });
}));

/* ============================================================
 * Buttons (category, section, product or notice owned)
 * ============================================================ */
const ownerFilter = z.object({ categoryId: idParam.optional(), sectionId: idParam.optional(), productId: idParam.optional(), noticeId: idParam.optional() });

catalogRouter.get("/buttons", requirePerm("buttons.manage"), wrap(async (req, res) => {
  const f = ownerFilter.parse(req.query);
  const where = Object.fromEntries(Object.entries(f).filter(([, v]) => v));
  res.json(await prisma.actionButton.findMany({ where, orderBy: { sortOrder: "asc" }, take: 200 }));
}));

catalogRouter.post("/buttons", requirePerm("buttons.manage"), wrap(async (req, res) => {
  const b = buttonInput.parse(req.body);
  const general = await getGeneralSettings();
  await assertButtonOwner(b);
  const target = await validateButtonTarget(b.action, b.target, general.allowedExternalHosts);
  const key = (["categoryId", "sectionId", "productId", "noticeId"] as const).find((k) => b[k])!;
  const n = await prisma.actionButton.count({ where: { [key]: b[key] } as any });
  const row = await prisma.actionButton.create({
    data: {
      categoryId: b.categoryId ?? null, sectionId: b.sectionId ?? null, productId: b.productId ?? null, noticeId: b.noticeId ?? null,
      label: b.label, icon: b.icon, style: b.style, size: b.size, placement: b.placement, action: b.action, target: target as any,
      confirmTitle: b.confirmTitle, confirmMessage: b.confirmMessage, visibility: b.visibility as any, enabled: b.enabled, sortOrder: n,
    },
  });
  await audit(req, "button.create", "ActionButton", row.id, { action: row.action, label: row.label });
  res.status(201).json(row);
}));

catalogRouter.put("/buttons/:id", requirePerm("buttons.manage"), wrap(async (req, res) => {
  const cur = await prisma.actionButton.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Button not found", 404);
  // The owner is fixed; the editor sends the whole button. We re-attach the stored owner to the validated body.
  const b = buttonInput.parse({ ...req.body, categoryId: cur.categoryId, sectionId: cur.sectionId, productId: cur.productId, noticeId: cur.noticeId });
  const general = await getGeneralSettings();
  const target = await validateButtonTarget(b.action, b.target, general.allowedExternalHosts);
  const row = await prisma.actionButton.update({
    where: { id: cur.id },
    data: { label: b.label, icon: b.icon, style: b.style, size: b.size, placement: b.placement, action: b.action, target: target as any, confirmTitle: b.confirmTitle, confirmMessage: b.confirmMessage, visibility: b.visibility as any, enabled: b.enabled },
  });
  await audit(req, "button.update", "ActionButton", row.id, { action: row.action, enabled: row.enabled });
  res.json(row);
}));

catalogRouter.post("/buttons/:id/duplicate", requirePerm("buttons.manage"), wrap(async (req, res) => {
  const cur = await prisma.actionButton.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Button not found", 404);
  await assertButtonOwner(cur as any);
  const key = (["categoryId", "sectionId", "productId", "noticeId"] as const).find((k) => cur[k])!;
  const n = await prisma.actionButton.count({ where: { [key]: cur[key] } as any });
  const { id, createdAt, updatedAt, ...rest } = cur as any;
  void id; void createdAt; void updatedAt;
  const row = await prisma.actionButton.create({ data: { ...rest, label: `${cur.label} (copy)`.slice(0, 40), enabled: false, sortOrder: n } });
  await audit(req, "button.duplicate", "ActionButton", row.id, { from: cur.id });
  res.status(201).json(row);
}));

catalogRouter.delete("/buttons/:id", requirePerm("buttons.manage"), wrap(async (req, res) => {
  const row = await prisma.actionButton.delete({ where: { id: req.params.id } }).catch(() => null);
  if (!row) throw new UserError("Button not found", 404);
  await audit(req, "button.delete", "ActionButton", row.id, { label: row.label });
  res.json({ ok: true });
}));

catalogRouter.post("/buttons/reorder", requirePerm("buttons.manage"), wrap(async (req, res) => {
  const { ids } = reorderBody.parse(req.body);
  const rows = await prisma.actionButton.findMany({ where: { id: { in: ids } }, select: { id: true, categoryId: true, sectionId: true, productId: true, noticeId: true } });
  if (rows.length !== new Set(ids).size) throw new UserError("Unknown button in the list");
  const owners = new Set(rows.map((r) => `${r.categoryId}|${r.sectionId}|${r.productId}|${r.noticeId}`));
  if (owners.size > 1) throw new UserError("Only buttons with the same owner can be reordered together");
  await prisma.$transaction(ids.map((id, i) => prisma.actionButton.update({ where: { id }, data: { sortOrder: i } })));
  res.json({ ok: true });
}));

