import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { prisma } from "../../db";
import { config } from "../../config";
import { wrap } from "../../lib/http";
import { validateInitData } from "../../lib/telegramAuth";
import { requireAdmin, signAdminToken } from "../../middleware/auth";
import { catalogRouter } from "./catalog";
import { productsRouter } from "./products";
import { moneyRouter } from "./money";
import { opsRouter } from "./ops";

export const adminRouter = Router();

// ---------- Auth: Telegram-verified, allow-listed, with a SHORT initData window (stricter than customers) ----------
adminRouter.post(
  "/auth/telegram",
  rateLimit({ windowMs: 60_000, limit: 10 }),
  wrap(async (req, res) => {
    const { initData } = z.object({ initData: z.string().max(4096) }).parse(req.body);
    let tg;
    try {
      tg = validateInitData(initData, config.adminInitDataMaxAge);
    } catch {
      return res.status(401).json({ error: "Your Telegram session is too old or invalid. Close and reopen the Mini App, then try again." });
    }
    let admin = await prisma.adminUser.findUnique({ where: { telegramId: BigInt(tg.id) } });
    // First sign-in of an ID listed in ADMIN_TELEGRAM_IDS bootstraps the owner account.
    if (!admin && config.adminTelegramIds.includes(String(tg.id))) {
      admin = await prisma.adminUser.create({ data: { telegramId: BigInt(tg.id), name: tg.first_name, role: "OWNER" } });
    }
    if (!admin || admin.disabled) {
      await prisma.auditLog.create({ data: { action: "admin.login_denied", targetType: "Telegram", targetId: String(tg.id) } }).catch(() => undefined);
      return res.status(403).json({ error: "This Telegram account is not an administrator" });
    }
    await prisma.auditLog.create({ data: { adminId: admin.id, action: "admin.login" } }).catch(() => undefined);
    res.json({ token: signAdminToken(admin.id), role: admin.role });
  })
);

adminRouter.use(requireAdmin);
adminRouter.use(rateLimit({ windowMs: 60_000, limit: 600 }));
adminRouter.use(catalogRouter);
adminRouter.use(productsRouter);
adminRouter.use(moneyRouter);
adminRouter.use(opsRouter);
