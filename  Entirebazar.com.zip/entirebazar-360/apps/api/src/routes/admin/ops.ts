import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "../../db";
import { wrap, paging } from "../../lib/http";
import { UserError } from "../../lib/errors";
import { LIMITS } from "../../lib/limits";
import { PERMISSIONS, PERMISSION_GROUPS, Permission, SYSTEM_ROLES, permissionsOf } from "../../lib/permissions";
import { generalSettingsSchema, noticeInput, roleInput } from "../../lib/layoutSchema";
import { audit, requirePerm } from "../../middleware/auth";
import { notifyUser } from "../../services/notify";
import { runBroadcast } from "../../services/broadcast";
import { getGeneralSettings, saveGeneralSettings } from "../../services/settings";

export const opsRouter = Router();
const idp = z.string().min(1).max(40);
const limiter = rateLimit({ windowMs: 60_000, limit: 30 });

/* ============================================================
 * Dashboard & reports
 * ============================================================ */
opsRouter.get("/dashboard", requirePerm("dashboard.view"), wrap(async (req, res) => {
  const can = (p: Permission) => req.perms!.has(p);
  const [users, sales, deposits, pendingDeposits, needsReview, successful, pendingOrders, manualQueue, openTickets, lowStock, liveCats, draftCats, recent] = await Promise.all([
    can("users.view") ? prisma.user.count() : null,
    can("orders.view") ? prisma.order.aggregate({ _sum: { total: true }, where: { status: { in: ["PAID", "PROCESSING", "DELIVERED"] } } }) : null,
    can("deposits.view") ? prisma.deposit.aggregate({ _sum: { amount: true }, where: { status: "SUCCESSFUL" } }) : null,
    can("deposits.view") ? prisma.deposit.count({ where: { status: "PENDING" } }) : null,
    can("deposits.view") ? prisma.deposit.count({ where: { status: "PENDING", needsReview: true } }) : null,
    can("deposits.view") ? prisma.deposit.count({ where: { status: "SUCCESSFUL" } }) : null,
    can("orders.view") ? prisma.order.count({ where: { status: { in: ["PENDING", "PROCESSING"] } } }) : null,
    can("orders.view") ? prisma.order.count({ where: { status: "PROCESSING" } }) : null,
    can("tickets.manage") ? prisma.supportTicket.count({ where: { status: "OPEN" } }) : null,
    can("products.view") ? prisma.product.count({ where: { status: "PUBLISHED", stock: { lte: 5, not: null } } }) : null,
    can("catalog.view") ? prisma.category.count({ where: { status: "PUBLISHED" } }) : null,
    can("catalog.view") ? prisma.category.count({ where: { status: "DRAFT" } }) : null,
    can("deposits.view") ? prisma.paymentEvent.findMany({ orderBy: { createdAt: "desc" }, take: 15 }) : [],
  ]);
  // Fields the admin may not see are returned as null so the UI can hide those cards.
  res.json({
    totalUsers: users, totalSales: sales ? sales._sum.total ?? "0" : null, totalDeposits: deposits ? deposits._sum.amount ?? "0" : null,
    pendingDeposits, depositsNeedingReview: needsReview, successfulPayments: successful, pendingOrders, manualFulfilmentQueue: manualQueue,
    openTickets, lowStockProducts: lowStock, publishedCategories: liveCats, draftCategories: draftCats, recentActivity: recent,
  });
}));

opsRouter.get("/reports", requirePerm("reports.view"), wrap(async (req, res) => {
  const { days } = z.object({ days: z.coerce.number().int().min(1).max(365).default(30) }).parse(req.query);
  const since = new Date(Date.now() - days * 864e5);
  const [sales, deposits, signups, byStatus, top] = await Promise.all([
    prisma.$queryRaw<{ d: string; n: number; total: string }[]>`
      SELECT to_char(date_trunc('day', "createdAt"), 'YYYY-MM-DD') AS d, COUNT(*)::int AS n, COALESCE(SUM(total), 0)::text AS total
      FROM "Order" WHERE "createdAt" >= ${since} AND status::text IN ('PAID','PROCESSING','DELIVERED') GROUP BY 1 ORDER BY 1`,
    prisma.$queryRaw<{ d: string; n: number; total: string }[]>`
      SELECT to_char(date_trunc('day', "createdAt"), 'YYYY-MM-DD') AS d, COUNT(*)::int AS n, COALESCE(SUM(amount), 0)::text AS total
      FROM "Deposit" WHERE "createdAt" >= ${since} AND status::text = 'SUCCESSFUL' GROUP BY 1 ORDER BY 1`,
    prisma.$queryRaw<{ d: string; n: number }[]>`
      SELECT to_char(date_trunc('day', "createdAt"), 'YYYY-MM-DD') AS d, COUNT(*)::int AS n FROM "User" WHERE "createdAt" >= ${since} GROUP BY 1 ORDER BY 1`,
    prisma.order.groupBy({ by: ["status"], where: { createdAt: { gte: since } }, _count: { _all: true } }),
    prisma.$queryRaw<{ productId: string; name: string; qty: number; revenue: string }[]>`
      SELECT oi."productId", COALESCE(MAX(oi."productName"), MAX(p.name)) AS name, SUM(oi.quantity)::int AS qty, SUM(oi.quantity * oi."unitPrice")::text AS revenue
      FROM "OrderItem" oi JOIN "Order" o ON o.id = oi."orderId" JOIN "Product" p ON p.id = oi."productId"
      WHERE o."createdAt" >= ${since} AND o.status::text IN ('PAID','PROCESSING','DELIVERED')
      GROUP BY oi."productId" ORDER BY SUM(oi.quantity * oi."unitPrice") DESC LIMIT 10`,
  ]);
  res.json({ days, sales, deposits, signups, ordersByStatus: byStatus.map((s) => ({ status: s.status, count: s._count._all })), topProducts: top });
}));

opsRouter.get("/audit", requirePerm("audit.view"), wrap(async (req, res) => {
  const q = z.object({ action: z.string().max(60).optional(), targetType: z.string().max(40).optional(), adminId: idp.optional() }).parse(req.query);
  const { take, skip, page } = paging(req.query, 100);
  const where: Prisma.AuditLogWhereInput = {
    ...(q.action ? { action: { startsWith: q.action } } : {}), ...(q.targetType ? { targetType: q.targetType } : {}), ...(q.adminId ? { adminId: q.adminId } : {}),
  };
  const [total, items] = await Promise.all([
    prisma.auditLog.count({ where }),
    prisma.auditLog.findMany({ where, orderBy: { createdAt: "desc" }, take, skip, include: { admin: { select: { name: true, telegramId: true } } } }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items });
}));

/* ============================================================
 * Notices & banners
 * ============================================================ */
async function checkNoticeRefs(b: z.output<typeof noticeInput>) {
  if (b.categoryIds.length && (await prisma.category.count({ where: { id: { in: b.categoryIds } } })) !== new Set(b.categoryIds).size) throw new UserError("One or more selected categories do not exist");
  if (b.productIds.length && (await prisma.product.count({ where: { id: { in: b.productIds } } })) !== new Set(b.productIds).size) throw new UserError("One or more selected products do not exist");
}

opsRouter.get("/notices", requirePerm("notices.manage"), wrap(async (req, res) => {
  const q = z.object({ q: z.string().max(60).optional(), location: z.string().max(30).optional(), enabled: z.enum(["true", "false"]).optional(), categoryId: idp.optional(), productId: idp.optional() }).parse(req.query);
  const { take, skip, page } = paging(req.query, 100);
  const where: Prisma.AnnouncementWhereInput = {
    ...(q.q ? { title: { contains: q.q, mode: "insensitive" } } : {}), ...(q.location ? { locations: { has: q.location } } : {}),
    ...(q.enabled ? { enabled: q.enabled === "true" } : {}),
    ...(q.categoryId ? { audience: "CATEGORIES" as const, categoryIds: { has: q.categoryId } } : {}),
    ...(q.productId ? { audience: "PRODUCTS" as const, productIds: { has: q.productId } } : {}),
  };
  const [total, items] = await Promise.all([
    prisma.announcement.count({ where }),
    prisma.announcement.findMany({ where, orderBy: [{ pinned: "desc" }, { priority: "desc" }, { createdAt: "desc" }], take, skip, include: { _count: { select: { buttons: true, dismissals: true } } } }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items });
}));

opsRouter.get("/notices/:id", requirePerm("notices.manage"), wrap(async (req, res) => {
  const n = await prisma.announcement.findUnique({ where: { id: req.params.id }, include: { buttons: { orderBy: { sortOrder: "asc" } } } });
  if (!n) throw new UserError("Notice not found", 404);
  res.json(n);
}));

opsRouter.post("/notices", requirePerm("notices.manage"), wrap(async (req, res) => {
  const b = noticeInput.parse(req.body);
  if ((await prisma.announcement.count()) >= LIMITS.maxNotices) throw new UserError(`The limit of ${LIMITS.maxNotices} notices has been reached; delete old ones first`);
  await checkNoticeRefs(b);
  const n = await prisma.announcement.create({ data: { ...b, publishAt: b.publishAt ?? new Date() } });
  await audit(req, "notice.create", "Announcement", n.id, { title: n.title, locations: n.locations });
  res.status(201).json(n);
}));

opsRouter.put("/notices/:id", requirePerm("notices.manage"), wrap(async (req, res) => {
  const b = noticeInput.parse(req.body);
  await checkNoticeRefs(b);
  const exists = await prisma.announcement.findUnique({ where: { id: req.params.id }, select: { id: true } });
  if (!exists) throw new UserError("Notice not found", 404);
  const n = await prisma.announcement.update({ where: { id: req.params.id }, data: { ...b, publishAt: b.publishAt ?? undefined } });
  await audit(req, "notice.update", "Announcement", n.id, { enabled: n.enabled });
  res.json(n);
}));

opsRouter.post("/notices/:id/duplicate", requirePerm("notices.manage"), wrap(async (req, res) => {
  const src = await prisma.announcement.findUnique({ where: { id: req.params.id }, include: { buttons: true } });
  if (!src) throw new UserError("Notice not found", 404);
  const copy = await prisma.$transaction(async (tx) => {
    const { id, createdAt, updatedAt, buttons, ...rest } = src as any;
    void id; void createdAt; void updatedAt;
    const n = await tx.announcement.create({ data: { ...rest, title: `${src.title} (copy)`.slice(0, 120), enabled: false } });
    for (const b of buttons) await tx.actionButton.create({ data: { noticeId: n.id, label: b.label, icon: b.icon, style: b.style, size: b.size, placement: b.placement, action: b.action, target: b.target, confirmTitle: b.confirmTitle, confirmMessage: b.confirmMessage, visibility: b.visibility, enabled: b.enabled, sortOrder: b.sortOrder } });
    return n;
  });
  await audit(req, "notice.duplicate", "Announcement", copy.id, { from: src.id });
  res.status(201).json(copy);
}));

opsRouter.delete("/notices/:id", requirePerm("notices.manage"), wrap(async (req, res) => {
  const n = await prisma.announcement.delete({ where: { id: req.params.id } }).catch(() => null);
  if (!n) throw new UserError("Notice not found", 404);
  await audit(req, "notice.delete", "Announcement", n.id, { title: n.title });
  res.json({ ok: true });
}));

// Also push a notice to users through the bot. Goes through the same broadcast pipeline: promo opt-outs and blocked users are respected.
opsRouter.post("/notices/:id/telegram", limiter, requirePerm("notices.manage", "notify.send"), wrap(async (req, res) => {
  const n = await prisma.announcement.findUnique({ where: { id: req.params.id } });
  if (!n) throw new UserError("Notice not found", 404);
  if (n.audience !== "ALL") throw new UserError("Only notices for all users can be sent through the bot. Use targeted messages for specific users.");
  const job = await prisma.broadcastJob.create({ data: { title: n.title, body: n.body.slice(0, 1500), audience: "all", userIds: [], createdBy: req.admin!.id } });
  await audit(req, "notice.telegram", "Announcement", n.id, { jobId: job.id });
  void runBroadcast(job.id).catch((e) => console.error(e));
  res.status(202).json(job);
}));

/* ============================================================
 * Users
 * ============================================================ */
opsRouter.get("/users", requirePerm("users.view"), wrap(async (req, res) => {
  const q = z.object({ q: z.string().trim().max(60).optional(), status: z.enum(["ACTIVE", "RESTRICTED", "BANNED"]).optional() }).parse(req.query);
  const { take, skip, page } = paging(req.query);
  const or: Prisma.UserWhereInput[] = q.q ? [{ username: { contains: q.q.replace(/^@/, ""), mode: "insensitive" } }, { firstName: { contains: q.q, mode: "insensitive" } }] : [];
  if (q.q && /^\d{3,15}$/.test(q.q)) or.push({ telegramId: BigInt(q.q) });
  const where: Prisma.UserWhereInput = { status: q.status, ...(or.length ? { OR: or } : {}) };
  const [total, items] = await Promise.all([
    prisma.user.count({ where }),
    prisma.user.findMany({ where, orderBy: { createdAt: "desc" }, take, skip, include: { wallet: { select: { balance: true } } } }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items });
}));

opsRouter.get("/users/:id", requirePerm("users.view"), wrap(async (req, res) => {
  const u = await prisma.user.findUnique({
    where: { id: req.params.id },
    include: {
      wallet: true,
      orders: { orderBy: { createdAt: "desc" }, take: 20 },
      deposits: { orderBy: { createdAt: "desc" }, take: 20, include: { provider: { select: { displayName: true } } } },
      adjustments: { orderBy: { createdAt: "desc" }, take: 10 },
    },
  });
  if (!u) throw new UserError("User not found", 404);
  res.json(u);
}));

opsRouter.patch("/users/:id/status", requirePerm("users.manage"), wrap(async (req, res) => {
  const b = z.object({ status: z.enum(["ACTIVE", "RESTRICTED", "BANNED"]), reason: z.string().trim().max(300).optional() }).parse(req.body);
  if (b.status !== "ACTIVE" && !b.reason) throw new UserError("Please give a reason for restricting or banning an account");
  const u = await prisma.user.update({ where: { id: req.params.id }, data: { status: b.status } });
  await audit(req, "user.status", "User", u.id, b);
  res.json({ id: u.id, status: u.status });
}));

/* ============================================================
 * Support tickets
 * ============================================================ */
opsRouter.get("/tickets", requirePerm("tickets.manage"), wrap(async (req, res) => {
  const q = z.object({ status: z.enum(["OPEN", "ANSWERED", "CLOSED"]).optional() }).parse(req.query);
  const { take, skip, page } = paging(req.query);
  const where = { status: q.status };
  const [total, items] = await Promise.all([
    prisma.supportTicket.count({ where }),
    prisma.supportTicket.findMany({ where, orderBy: { createdAt: "desc" }, take, skip, include: { user: { select: { id: true, username: true, firstName: true } } } }),
  ]);
  res.json({ total, page, pages: Math.max(1, Math.ceil(total / take)), items });
}));

opsRouter.post("/tickets/:id/reply", requirePerm("tickets.manage"), wrap(async (req, res) => {
  const b = z.object({ reply: z.string().trim().min(1).max(2000) }).parse(req.body);
  const t = await prisma.supportTicket.update({ where: { id: req.params.id }, data: { reply: b.reply, status: "ANSWERED" } });
  await notifyUser(t.userId, "SUPPORT", "Support replied", b.reply.slice(0, 300), "/support");
  await audit(req, "ticket.reply", "SupportTicket", t.id);
  res.json(t);
}));

opsRouter.post("/tickets/:id/close", requirePerm("tickets.manage"), wrap(async (req, res) => {
  const t = await prisma.supportTicket.update({ where: { id: req.params.id }, data: { status: "CLOSED" } });
  await audit(req, "ticket.close", "SupportTicket", t.id);
  res.json(t);
}));

/* ============================================================
 * Telegram notifications: broadcasts, targeted messages, templates, delivery errors
 * ============================================================ */
opsRouter.post("/broadcasts", limiter, requirePerm("notify.send"), wrap(async (req, res) => {
  const b = z.object({
    title: z.string().trim().min(1).max(100), body: z.string().trim().min(1).max(1500),
    audience: z.enum(["all", "selected", "one"]), userIds: z.array(idp).max(5000).default([]), scheduledAt: z.coerce.date().optional(),
  }).parse(req.body);
  if (b.audience !== "all" && b.userIds.length === 0) throw new UserError("Select at least one user");
  if (b.audience === "one" && b.userIds.length !== 1) throw new UserError("Exactly one user is required");
  if (b.scheduledAt && b.scheduledAt.getTime() < Date.now() - 60_000) throw new UserError("The scheduled time is in the past");
  if (b.audience !== "all") {
    const n = await prisma.user.count({ where: { id: { in: b.userIds } } });
    if (n !== new Set(b.userIds).size) throw new UserError("Some selected users no longer exist");
  }
  const job = await prisma.broadcastJob.create({ data: { ...b, userIds: b.audience === "all" ? [] : b.userIds, createdBy: req.admin!.id } });
  await audit(req, "broadcast.create", "BroadcastJob", job.id, { audience: b.audience, recipients: b.audience === "all" ? "all" : b.userIds.length });
  if (!b.scheduledAt || b.scheduledAt <= new Date()) void runBroadcast(job.id).catch((e) => console.error(e));
  res.status(201).json(job);
}));
opsRouter.get("/broadcasts", requirePerm("notify.send"), wrap(async (_req, res) => res.json(await prisma.broadcastJob.findMany({ orderBy: { createdAt: "desc" }, take: 50 }))));
opsRouter.get("/delivery-errors", requirePerm("notify.send"), wrap(async (_req, res) => {
  const [items, blockedUsers] = await Promise.all([
    prisma.notification.findMany({ where: { telegram: { in: ["FAILED", "BLOCKED"] } }, orderBy: { createdAt: "desc" }, take: 100, select: { id: true, userId: true, type: true, title: true, telegram: true, telegramError: true, createdAt: true } }),
    prisma.user.count({ where: { botBlocked: true } }),
  ]);
  res.json({ items, blockedUsers });
}));
opsRouter.get("/templates", requirePerm("notify.send"), wrap(async (_req, res) => res.json(await prisma.notificationTemplate.findMany({ orderBy: { name: "asc" } }))));
opsRouter.post("/templates", requirePerm("notify.send"), wrap(async (req, res) => {
  const b = z.object({ name: z.string().trim().min(1).max(60), title: z.string().trim().min(1).max(100), body: z.string().trim().min(1).max(1500) }).parse(req.body);
  res.status(201).json(await prisma.notificationTemplate.create({ data: b }));
}));
opsRouter.delete("/templates/:id", requirePerm("notify.send"), wrap(async (req, res) => { await prisma.notificationTemplate.delete({ where: { id: req.params.id } }); res.json({ ok: true }); }));

/* ============================================================
 * General settings (homepage, support links, maintenance, allowed hosts)
 * ============================================================ */
opsRouter.get("/settings", requirePerm("settings.manage"), wrap(async (_req, res) => res.json(await getGeneralSettings(true))));

opsRouter.put("/settings", requirePerm("settings.manage"), wrap(async (req, res) => {
  const s = generalSettingsSchema.parse(req.body);
  if (new Set(s.homeLayout.map((b) => b.id)).size !== s.homeLayout.length) throw new UserError("Each homepage block can appear only once");
  if (s.homeFeaturedProductIds.length) {
    const n = await prisma.product.count({ where: { id: { in: s.homeFeaturedProductIds } } });
    if (n !== new Set(s.homeFeaturedProductIds).size) throw new UserError("One or more featured products no longer exist");
  }
  await saveGeneralSettings(s);
  await audit(req, "settings.update", "AppSetting", "general", { maintenance: s.maintenance, hosts: s.allowedExternalHosts.length });
  res.json(s);
}));

/* ============================================================
 * Roles, permissions & administrators
 * ============================================================ */
opsRouter.get("/me", wrap(async (req, res) => {
  const a = req.admin!;
  res.json({ id: a.id, name: a.name, role: a.role, customRole: a.customRole?.name ?? null, permissions: [...req.perms!], groups: PERMISSION_GROUPS });
}));

opsRouter.get("/roles", requirePerm("roles.manage"), wrap(async (_req, res) => {
  const custom = await prisma.role.findMany({ orderBy: { name: "asc" }, include: { _count: { select: { admins: true } } } });
  res.json({ groups: PERMISSION_GROUPS, builtIn: (["OWNER", "ADMIN", "SUPPORT"] as const).map((r) => ({ name: r, permissions: permissionsOf({ role: r, disabled: false, customRole: null }) })), custom });
}));

/** An admin can never hand out a permission they do not hold themselves (no privilege escalation), unless they are OWNER. */
function assertGrantable(req: any, perms: string[]) {
  const unknown = perms.filter((p) => !(PERMISSIONS as readonly string[]).includes(p));
  if (unknown.length) throw new UserError(`Unknown permission: ${unknown[0]}`);
  if (req.admin.role !== "OWNER") {
    const over = perms.find((p) => !req.perms.has(p));
    if (over) throw new UserError(`You cannot grant "${over}" because you do not have it yourself`, 403);
  }
}

opsRouter.post("/roles", requirePerm("roles.manage"), wrap(async (req, res) => {
  const b = roleInput.parse(req.body);
  assertGrantable(req, b.permissions);
  const r = await prisma.role.create({ data: { name: b.name, description: b.description, permissions: [...new Set(b.permissions)] } }).catch((e) => {
    if (e?.code === "P2002") throw new UserError("A role with this name already exists");
    throw e;
  });
  await audit(req, "role.create", "Role", r.id, { name: r.name, permissions: r.permissions });
  res.status(201).json(r);
}));

opsRouter.put("/roles/:id", requirePerm("roles.manage"), wrap(async (req, res) => {
  const b = roleInput.parse(req.body);
  const cur = await prisma.role.findUnique({ where: { id: req.params.id } });
  if (!cur) throw new UserError("Role not found", 404);
  assertGrantable(req, b.permissions);
  const r = await prisma.role.update({ where: { id: cur.id }, data: { name: cur.system ? cur.name : b.name, description: b.description, permissions: [...new Set(b.permissions)] } });
  await audit(req, "role.update", "Role", r.id, { before: cur.permissions, after: r.permissions });
  res.json(r);
}));

opsRouter.delete("/roles/:id", requirePerm("roles.manage"), wrap(async (req, res) => {
  const cur = await prisma.role.findUnique({ where: { id: req.params.id }, include: { _count: { select: { admins: true } } } });
  if (!cur) throw new UserError("Role not found", 404);
  if (cur.system) throw new UserError("Built-in roles cannot be deleted");
  if (cur._count.admins > 0) throw new UserError(`${cur._count.admins} administrator(s) still use this role`);
  await prisma.role.delete({ where: { id: cur.id } });
  await audit(req, "role.delete", "Role", cur.id, { name: cur.name });
  res.json({ ok: true });
}));

opsRouter.get("/admins", requirePerm("roles.manage"), wrap(async (_req, res) => {
  const rows = await prisma.adminUser.findMany({ orderBy: { createdAt: "asc" }, include: { customRole: { select: { id: true, name: true } } } });
  res.json(rows.map((a) => ({ id: a.id, telegramId: a.telegramId.toString(), name: a.name, role: a.role, customRole: a.customRole, disabled: a.disabled, createdAt: a.createdAt })));
}));

const adminBody = z.object({ role: z.enum(["ADMIN", "SUPPORT", "OWNER"]).optional(), roleId: idp.nullable().optional(), disabled: z.boolean().optional(), name: z.string().trim().max(60).optional() });

async function assertOwnerSafety(req: any, targetId: string, next: { role?: string; disabled?: boolean }) {
  if (next.role === "OWNER" && req.admin.role !== "OWNER") throw new UserError("Only an owner can grant the Owner role", 403);
  const target = await prisma.adminUser.findUnique({ where: { id: targetId } });
  if (!target) throw new UserError("Administrator not found", 404);
  if (target.id === req.admin.id && (next.disabled || (next.role && next.role !== target.role))) throw new UserError("You cannot change your own role or disable yourself");
  if (target.role === "OWNER" && req.admin.role !== "OWNER") throw new UserError("Only an owner can change another owner", 403);
  if (target.role === "OWNER" && (next.disabled || (next.role && next.role !== "OWNER"))) {
    const owners = await prisma.adminUser.count({ where: { role: "OWNER", disabled: false } });
    if (owners <= 1) throw new UserError("There must always be at least one active owner");
  }
  return target;
}

opsRouter.post("/admins", requirePerm("roles.manage"), wrap(async (req, res) => {
  const b = adminBody.extend({ telegramId: z.string().regex(/^\d{3,15}$/, "Enter the numeric Telegram ID") }).parse(req.body);
  if (b.role === "OWNER" && req.admin!.role !== "OWNER") throw new UserError("Only an owner can grant the Owner role", 403);
  if (b.roleId) {
    const role = await prisma.role.findUnique({ where: { id: b.roleId } });
    if (!role) throw new UserError("Role not found", 404);
    assertGrantable(req, role.permissions);
  }
  const a = await prisma.adminUser.create({ data: { telegramId: BigInt(b.telegramId), name: b.name, role: b.role ?? "SUPPORT", roleId: b.roleId ?? null } }).catch((e) => {
    if (e?.code === "P2002") throw new UserError("This Telegram user is already an administrator");
    throw e;
  });
  await audit(req, "admin.create", "AdminUser", a.id, { telegramId: b.telegramId, role: a.role, roleId: a.roleId });
  res.status(201).json({ id: a.id });
}));

opsRouter.patch("/admins/:id", requirePerm("roles.manage"), wrap(async (req, res) => {
  const b = adminBody.parse(req.body);
  await assertOwnerSafety(req, req.params.id, b);
  if (b.roleId) {
    const role = await prisma.role.findUnique({ where: { id: b.roleId } });
    if (!role) throw new UserError("Role not found", 404);
    assertGrantable(req, role.permissions);
  }
  const a = await prisma.adminUser.update({ where: { id: req.params.id }, data: b });
  await audit(req, "admin.update", "AdminUser", a.id, b);
  res.json({ id: a.id });
}));

void SYSTEM_ROLES;
