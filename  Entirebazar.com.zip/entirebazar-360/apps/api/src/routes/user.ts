import { Router } from "express";
import rateLimit from "express-rate-limit";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "../db";
import { wrap, paging } from "../lib/http";
import { validateInitData } from "../lib/telegramAuth";
import { requireUser, requireActive, signUserToken } from "../middleware/auth";
import { createDeposit, submitTransaction, UserError } from "../services/deposits";
import { checkout } from "../services/orders";
import { PRIVATE_REF, privateDownloadUrl } from "../lib/storage";
import { notifyAdmins } from "../services/notify";
import { getGeneralSettings, publicSettings } from "../services/settings";
import {
  loadIndex, buildHome, buildCategoryPage, makeViewer, noticesFor, categoryCard, Viewer,
} from "../services/pages";
import { presentMany, visibleProductWhere, sortToOrderBy, subtreeIds, ancestorsOf, canPurchaseProduct } from "../services/catalog";
import { resolveButtons } from "../services/pages";
import { faqItems } from "../lib/layoutSchema";

export const userRouter = Router();

const authLimiter = rateLimit({ windowMs: 60_000, limit: 20 });
const moneyLimiter = rateLimit({ windowMs: 60_000, limit: 15 });

// ---------- Auth ----------
userRouter.post(
  "/auth/telegram",
  authLimiter,
  wrap(async (req, res) => {
    const { initData } = z.object({ initData: z.string().max(4096) }).parse(req.body);
    let tg;
    try {
      tg = validateInitData(initData);
    } catch {
      return res.status(401).json({ error: "Invalid Telegram session" });
    }
    const data = {
      username: tg.username ?? null,
      firstName: tg.first_name ?? null,
      lastName: tg.last_name ?? null,
      languageCode: tg.language_code ?? null,
      photoUrl: tg.photo_url ?? null,
    };
    const telegramId = BigInt(tg.id);
    let user = await prisma.user.findUnique({ where: { telegramId } });
    if (user) user = await prisma.user.update({ where: { id: user.id }, data: { ...data, botBlocked: false } });
    else {
      try {
        user = await prisma.user.create({ data: { telegramId, ...data } });
      } catch (e: any) {
        if (e?.code !== "P2002") throw e;
        user = await prisma.user.findUniqueOrThrow({ where: { telegramId } });
      }
    }
    await prisma.wallet.upsert({ where: { userId: user.id }, update: {}, create: { userId: user.id } });
    if (user.status === "BANNED") return res.status(403).json({ error: "Account unavailable" });
    res.json({ token: signUserToken(user.id) });
  })
);

// Public: maintenance state + maintenance notices (so the maintenance screen works pre-auth). No user data.
userRouter.get(
  "/status",
  wrap(async (_req, res) => {
    const general = await getGeneralSettings();
    const idx = await loadIndex();
    const notices = await noticesFor("MAINTENANCE", { idx, viewer: makeViewer(undefined), allowedHosts: general.allowedExternalHosts, limit: 3 });
    res.json({ maintenance: general.maintenance, message: general.maintenanceMessage, contact: general.contact, notices });
  })
);

// Public, non-sensitive site configuration (branding text, contact, home layout order).
userRouter.get("/settings", wrap(async (_req, res) => res.json(publicSettings(await getGeneralSettings()))));

userRouter.use(requireUser);

/** Everything a page needs to resolve notices/buttons for the signed-in viewer. */
async function pageCtx(req: any) {
  const [general, idx] = await Promise.all([getGeneralSettings(), loadIndex()]);
  const viewer: Viewer = makeViewer(req.user.id);
  return { general, idx, viewer, allowedHosts: general.allowedExternalHosts };
}

/** Maintenance blocks everything except the status endpoint and read-only account views. */
userRouter.use(
  wrap(async (req, res, next) => {
    const general = await getGeneralSettings();
    if (general.maintenance && req.method !== "GET") {
      return res.status(503).json({ error: general.maintenanceMessage || "We are under maintenance. Please try again soon.", maintenance: true });
    }
    next();
  })
);

// ---------- Profile ----------
userRouter.get(
  "/me",
  wrap(async (req, res) => {
    const u = req.user!;
    const [wallet, unread] = await Promise.all([
      prisma.wallet.findUnique({ where: { userId: u.id } }),
      prisma.notification.count({ where: { userId: u.id, readAt: null } }),
    ]);
    res.json({
      id: u.id, username: u.username, firstName: u.firstName, lastName: u.lastName,
      photoUrl: u.photoUrl, status: u.status, createdAt: u.createdAt,
      prefs: { payments: u.notifyPayments, orders: u.notifyOrders, promos: u.notifyPromos },
      balance: wallet?.balance ?? "0", unread,
    });
  })
);

userRouter.patch(
  "/me/preferences",
  wrap(async (req, res) => {
    const b = z.object({ payments: z.boolean().optional(), orders: z.boolean().optional(), promos: z.boolean().optional() }).parse(req.body);
    await prisma.user.update({ where: { id: req.user!.id }, data: { notifyPayments: b.payments, notifyOrders: b.orders, notifyPromos: b.promos } });
    res.json({ ok: true });
  })
);

// ---------- Home (layout, banners, featured categories/products come from admin settings) ----------
userRouter.get(
  "/home",
  wrap(async (req, res) => {
    const u = req.user!;
    const { general, idx, viewer } = await pageCtx(req);
    const [wallet, unread, home] = await Promise.all([
      prisma.wallet.findUnique({ where: { userId: u.id } }),
      prisma.notification.count({ where: { userId: u.id, readAt: null } }),
      buildHome({ idx, viewer, general }),
    ]);
    res.json({
      user: { firstName: u.firstName, username: u.username, photoUrl: u.photoUrl },
      balance: wallet?.balance ?? "0",
      unread,
      ...home,
    });
  })
);

// Dismiss a notice (only dismissible ones; persistent notices cannot be hidden by a client).
userRouter.post(
  "/notices/:id/dismiss",
  wrap(async (req, res) => {
    const n = await prisma.announcement.findUnique({ where: { id: req.params.id } });
    if (!n) throw new UserError("Notice not found", 404);
    if (!n.dismissible) throw new UserError("This notice cannot be dismissed", 400);
    await prisma.noticeDismissal.upsert({
      where: { userId_noticeId: { userId: req.user!.id, noticeId: n.id } },
      update: {},
      create: { userId: req.user!.id, noticeId: n.id },
    });
    res.json({ ok: true });
  })
);

// ---------- Shop ----------
userRouter.get(
  "/categories",
  wrap(async (req, res) => {
    const { idx } = await pageCtx(req);
    const list = [...idx.live.values()].filter((c) => c.visibility === "PUBLIC").sort((a, b) => a.sortOrder - b.sortOrder);
    res.json(list.map((c) => ({ ...categoryCard(c), parentId: c.parentId })));
  })
);

userRouter.get(
  "/categories/:slug",
  wrap(async (req, res) => {
    const q = z.object({
      q: z.string().max(60).optional(), sort: z.string().max(20).optional(),
      inStock: z.enum(["true", "false"]).optional(), min: z.coerce.number().min(0).optional(), max: z.coerce.number().min(0).optional(),
      type: z.string().max(30).optional(), page: z.coerce.number().int().min(1).max(500).optional(),
    }).parse(req.query);
    const { general, idx, viewer } = await pageCtx(req);
    // Only LIVE categories are reachable (UNLISTED ones by direct link); drafts/archived/scheduled-out are 404.
    const category = [...idx.live.values()].find((c) => c.slug === req.params.slug);
    if (!category) throw new UserError("Category not found", 404);
    res.json(await buildCategoryPage(category, { idx, viewer, general, query: { ...q, inStock: q.inStock === "true" } }));
  })
);

userRouter.get(
  "/products",
  wrap(async (req, res) => {
    const q = z.object({
      q: z.string().max(100).optional(), category: z.string().max(80).optional(),
      sort: z.enum(["new", "popular", "price_asc", "price_desc"]).default("new"),
      featured: z.enum(["true", "false"]).optional(),
      min: z.coerce.number().min(0).optional(), max: z.coerce.number().min(0).optional(),
      inStock: z.enum(["true", "false"]).optional(),
    }).parse(req.query);
    const { take, skip } = paging(req.query);
    const { general, idx, viewer } = await pageCtx(req);

    const and: Prisma.ProductWhereInput[] = [visibleProductWhere(idx)];
    if (q.q) and.push({ OR: [{ name: { contains: q.q, mode: "insensitive" } }, { description: { contains: q.q, mode: "insensitive" } }] });
    if (q.category) {
      const cat = [...idx.live.values()].find((c) => c.slug === q.category);
      if (!cat) return res.json({ items: [], notices: [] });
      and.push({ categories: { some: { categoryId: { in: subtreeIds(idx, cat.id, true) } } } });
    }
    if (q.featured === "true") and.push({ featured: true });
    if (q.min !== undefined || q.max !== undefined) and.push({ price: { gte: q.min, lte: q.max } });
    let items = await presentMany({ AND: and }, idx, { orderBy: sortToOrderBy(q.sort), take, skip });
    if (q.inStock === "true") items = items.filter((p) => p.inStock);
    const notices = skip === 0 ? await noticesFor("SHOP", { idx, viewer, allowedHosts: general.allowedExternalHosts }) : [];
    res.json({ items, notices });
  })
);

userRouter.get(
  "/products/:id",
  wrap(async (req, res) => {
    const { general, idx, viewer } = await pageCtx(req);
    const [p] = await presentMany({ AND: [visibleProductWhere(idx), { id: req.params.id }] }, idx, { take: 1 });
    if (!p) throw new UserError("Product not found", 404);
    const raw = await prisma.product.findUniqueOrThrow({ where: { id: p.id }, include: { categories: true, buttons: { where: { enabled: true }, orderBy: { sortOrder: "asc" } } } });
    const purchasable = canPurchaseProduct(raw, idx);
    const catIds = raw.categories.flatMap((c) => [c.categoryId, ...ancestorsOf(idx, idx.all.get(c.categoryId)!).map((a) => a.id)]);
    const ctx = { idx, viewer, allowedHosts: general.allowedExternalHosts };
    const [notices, reviews, wished, resolved] = await Promise.all([
      noticesFor("PRODUCT_DETAIL", { ...ctx, categoryIds: catIds, productIds: [p.id] }),
      prisma.review.findMany({ where: { productId: p.id }, orderBy: { createdAt: "desc" }, take: 20, include: { user: { select: { firstName: true, username: true } } } }),
      prisma.wishlist.findUnique({ where: { userId_productId: { userId: req.user!.id, productId: p.id } } }),
      resolveButtons(raw.buttons, ctx),
    ]);
    const faqParsed = faqItems.safeParse(raw.faq ?? []);
    // Why purchase might be blocked is explained, but the server still re-checks at checkout.
    const blocking = raw.categories.length && !purchasable ? idx.live.get(raw.categories[0].categoryId)?.unavailableMessage ?? "Purchases are temporarily unavailable." : null;
    res.json({
      ...p,
      purchasable,
      unavailableMessage: blocking,
      faq: faqParsed.success ? faqParsed.data : [],
      buttons: raw.buttons.map((b) => resolved.get(b.id)).filter(Boolean),
      reviews, wishlisted: !!wished, notices,
    });
  })
);

userRouter.post(
  "/products/:id/wishlist",
  wrap(async (req, res) => {
    const key = { userId: req.user!.id, productId: req.params.id };
    const ex = await prisma.wishlist.findUnique({ where: { userId_productId: key } });
    if (ex) await prisma.wishlist.delete({ where: { userId_productId: key } });
    else {
      const p = await prisma.product.findFirst({ where: { id: key.productId, status: "PUBLISHED" } });
      if (!p) throw new UserError("Product not found", 404);
      await prisma.wishlist.create({ data: key });
    }
    res.json({ wishlisted: !ex });
  })
);

userRouter.get("/wishlist", wrap(async (req, res) => {
  const { idx } = await pageCtx(req);
  const rows = await prisma.wishlist.findMany({ where: { userId: req.user!.id }, select: { productId: true }, orderBy: { createdAt: "desc" } });
  const ids = rows.map((r) => r.productId);
  res.json(await presentMany({ AND: [visibleProductWhere(idx), { id: { in: ids } }] }, idx, { ids }));
}));

userRouter.post(
  "/products/:id/reviews",
  wrap(async (req, res) => {
    const b = z.object({ rating: z.number().int().min(1).max(5), comment: z.string().max(1000).optional() }).parse(req.body);
    const bought = await prisma.orderItem.findFirst({
      where: { productId: req.params.id, order: { userId: req.user!.id, status: { in: ["PAID", "PROCESSING", "DELIVERED"] } } },
    });
    if (!bought) throw new UserError("Only buyers can review this product", 403);
    const r = await prisma.review.upsert({
      where: { userId_productId: { userId: req.user!.id, productId: req.params.id } },
      update: { rating: b.rating, comment: b.comment },
      create: { userId: req.user!.id, productId: req.params.id, rating: b.rating, comment: b.comment },
    });
    res.json(r);
  })
);

/** Notices for a named page, used by wallet/payment/order screens. */
async function pageNotices(req: any, location: string) {
  const { idx, viewer, allowedHosts } = await pageCtx(req);
  return noticesFor(location, { idx, viewer, allowedHosts });
}

// ---------- Wallet ----------
userRouter.get(
  "/wallet",
  wrap(async (req, res) => {
    const kind = z.enum(["all", "deposits", "spending"]).default("all").parse(req.query.kind ?? "all");
    const { take, skip } = paging(req.query);
    const wallet = await prisma.wallet.findUniqueOrThrow({ where: { userId: req.user!.id } });
    const where: Prisma.LedgerEntryWhereInput = {
      walletId: wallet.id,
      ...(kind === "deposits" ? { type: "DEPOSIT" } : kind === "spending" ? { type: "PURCHASE" } : {}),
    };
    const [entries, deposits, notices] = await Promise.all([
      prisma.ledgerEntry.findMany({ where, orderBy: { createdAt: "desc" }, take, skip }),
      prisma.deposit.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: "desc" }, take: 20, include: { provider: { select: { displayName: true, code: true } } } }),
      pageNotices(req, "WALLET"),
    ]);
    res.json({ balance: wallet.balance, entries, deposits, notices });
  })
);

// ---------- Deposits ----------
userRouter.get(
  "/payments/methods",
  wrap(async (req, res) => {
    const rows = await prisma.paymentProvider.findMany({ orderBy: { sortOrder: "asc" } });
    res.json({
      methods: rows.map((p) => ({
        code: p.code, name: p.displayName, isFuture: p.isFuture,
        // Disabled / unconfigured providers are shown as unavailable, never as working.
        available: p.enabled && !p.isFuture && p.verificationMode !== "DISABLED",
        manualReview: p.verificationMode === "MANUAL_REVIEW",
        receiverNumber: p.enabled ? p.receiverNumber : null,
        instructions: p.enabled ? p.instructions : null,
        min: p.minAmount, max: p.maxAmount,
      })),
      notices: await pageNotices(req, "ADD_MONEY"),
    });
  })
);

userRouter.post(
  "/deposits",
  moneyLimiter,
  requireActive,
  wrap(async (req, res) => {
    const b = z.object({ provider: z.string().max(20), amount: z.union([z.number(), z.string()]) }).parse(req.body);
    const d = await createDeposit(req.user!.id, b.provider, b.amount);
    res.status(201).json({
      id: d.id, invoiceNo: d.invoiceNo, amount: d.amount, status: d.status, expiresAt: d.expiresAt,
      provider: { code: d.provider.code, name: d.provider.displayName, receiverNumber: d.provider.receiverNumber, instructions: d.provider.instructions },
    });
  })
);

userRouter.post(
  "/deposits/:id/submit",
  moneyLimiter,
  requireActive,
  wrap(async (req, res) => {
    const b = z.object({ trxId: z.string().max(40), sender: z.string().max(20).optional() }).parse(req.body);
    const d = await submitTransaction(req.user!.id, req.params.id, b.trxId, b.sender);
    // Status comes only from the backend; the client must display exactly this.
    res.json({ id: d.id, status: d.status, needsReview: d.needsReview });
  })
);

userRouter.get("/deposits", wrap(async (req, res) => {
  const { take, skip } = paging(req.query);
  res.json(await prisma.deposit.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: "desc" }, take, skip, include: { provider: { select: { displayName: true, code: true } } } }));
}));

userRouter.get(
  "/deposits/:id",
  wrap(async (req, res) => {
    const d = await prisma.deposit.findFirst({
      where: { id: req.params.id, userId: req.user!.id },
      include: { provider: { select: { displayName: true, code: true, receiverNumber: true, instructions: true } } },
    });
    if (!d) throw new UserError("Deposit not found", 404);
    const { reviewedBy, ...safe } = d;
    void reviewedBy;
    res.json({ ...safe, notices: await pageNotices(req, "PAYMENT_RESULT") });
  })
);

// ---------- Orders ----------
userRouter.post(
  "/orders",
  moneyLimiter,
  requireActive,
  wrap(async (req, res) => {
    const b = z.object({
      items: z.array(z.object({
        productId: z.string().max(40), variantId: z.string().max(40).optional(),
        quantity: z.number().int().min(1).max(10), input: z.string().max(200).optional(),
      })).min(1).max(20),
      clientRef: z.string().min(8).max(64).regex(/^[A-Za-z0-9_-]+$/).optional(),
    }).parse(req.body);
    const o = await checkout(req.user!.id, b.items, b.clientRef);
    res.status(201).json({ id: o.id, orderNo: o.orderNo, status: o.status, total: o.total });
  })
);

userRouter.get("/orders", wrap(async (req, res) => {
  const { take, skip } = paging(req.query);
  res.json(await prisma.order.findMany({
    where: { userId: req.user!.id }, orderBy: { createdAt: "desc" }, take, skip,
    include: { items: { include: { product: { select: { name: true, imageUrl: true, productType: true } } } } },
  }));
}));

userRouter.get(
  "/orders/:id",
  wrap(async (req, res) => {
    const o = await prisma.order.findFirst({
      where: { id: req.params.id, userId: req.user!.id },
      include: { items: { include: { product: { select: { name: true, imageUrl: true, productType: true } } } } },
    });
    if (!o) throw new UserError("Order not found", 404);
    // Private uploaded files are turned into a 15-minute download link only here, for the order's owner.
    const items = o.items.map((it) => ({
      ...it,
      deliveredData: it.deliveredData && PRIVATE_REF.test(it.deliveredData) ? privateDownloadUrl(it.deliveredData) : it.deliveredData,
    }));
    res.json({ ...o, items, notices: await pageNotices(req, "ORDER_DETAIL") });
  })
);

userRouter.post(
  "/orders/:id/refund-request",
  wrap(async (req, res) => {
    const b = z.object({ reason: z.string().min(3).max(500) }).parse(req.body);
    const o = await prisma.order.findFirst({ where: { id: req.params.id, userId: req.user!.id } });
    if (!o) throw new UserError("Order not found", 404);
    if (o.refundStatus !== "NONE") throw new UserError("A refund was already requested");
    if (o.status === "REFUNDED" || o.status === "CANCELLED") throw new UserError("Order cannot be refunded");
    await prisma.order.update({ where: { id: o.id }, data: { refundStatus: "REQUESTED", refundReason: b.reason } });
    await notifyAdmins(`Refund requested for order ${o.orderNo}`, "/admin/refunds");
    res.json({ ok: true });
  })
);

// ---------- Notifications ----------
userRouter.get("/notifications", wrap(async (req, res) => {
  const { take, skip } = paging(req.query);
  const [items, unread, notices] = await Promise.all([
    prisma.notification.findMany({
      where: { userId: req.user!.id }, orderBy: { createdAt: "desc" }, take, skip,
      select: { id: true, type: true, title: true, body: true, deepLink: true, readAt: true, createdAt: true },
    }),
    prisma.notification.count({ where: { userId: req.user!.id, readAt: null } }),
    pageNotices(req, "NOTIFICATION_CENTER"),
  ]);
  res.json({ items, unread, notices });
}));

userRouter.get("/notifications/unread-count", wrap(async (req, res) => {
  res.json({ unread: await prisma.notification.count({ where: { userId: req.user!.id, readAt: null } }) });
}));

userRouter.post("/notifications/read", wrap(async (req, res) => {
  const b = z.object({ ids: z.array(z.string()).max(100).optional(), all: z.boolean().optional() }).parse(req.body);
  await prisma.notification.updateMany({
    where: { userId: req.user!.id, readAt: null, ...(b.all ? {} : { id: { in: b.ids ?? [] } }) },
    data: { readAt: new Date() },
  });
  res.json({ ok: true });
}));

// ---------- Support ----------
userRouter.post("/support", wrap(async (req, res) => {
  const b = z.object({ subject: z.string().min(3).max(120), message: z.string().min(5).max(2000) }).parse(req.body);
  const t = await prisma.supportTicket.create({ data: { userId: req.user!.id, ...b } });
  await notifyAdmins(`New support ticket: ${b.subject}`, "/admin/tickets");
  res.status(201).json(t);
}));
userRouter.get("/support", wrap(async (req, res) => {
  res.json(await prisma.supportTicket.findMany({ where: { userId: req.user!.id }, orderBy: { createdAt: "desc" }, take: 50 }));
}));
