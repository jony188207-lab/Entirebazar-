import { AdapterMeta, PaymentProviderAdapter, VerifyInput, VerifyResult } from "./types";
import { getSecret, getSetting } from "../services/secrets";

/**
 * IMPORTANT: no provider endpoints or request formats are invented here.
 *
 * Each adapter below is an integration SLOT. To make one operational you must
 *  (1) have merchant approval and credentials from that provider,
 *  (2) implement `verifyTransaction` and `testConnection` against the provider's OFFICIAL documentation,
 *  (3) set `implemented: true` in its meta and `capabilities().apiVerification` to true.
 * See docs/INTEGRATIONS.md for the step-by-step.
 *
 * Until then a provider can still be used via MANUAL_REVIEW mode (an admin confirms each deposit in
 * their merchant dashboard) or the signed webhook endpoint (/webhooks/payments) fed by an authorised
 * verification service. The admin panel reports these slots as "Not implemented" — never as connected.
 */
abstract class SlotAdapter implements PaymentProviderAdapter {
  abstract readonly meta: AdapterMeta;
  get code() {
    return this.meta.code;
  }

  async isConfigured(): Promise<boolean> {
    for (const f of this.meta.secrets) {
      if (f.required !== false && !(await getSecret(this.code, f.key))) return false;
    }
    for (const f of this.meta.settings) {
      if (f.required !== false && !(await getSetting(this.code, f.key))) return false;
    }
    return this.meta.secrets.length + this.meta.settings.length > 0;
  }

  capabilities() {
    return { apiVerification: false };
  }

  async verifyTransaction(_input: VerifyInput): Promise<VerifyResult> {
    return {
      status: "unsupported",
      reason: `${this.code}: API verification is not implemented. Implement it from the provider's official docs after merchant approval, or use manual review / signed webhook.`,
    };
  }

  async testConnection() {
    return {
      ok: false,
      message: `${this.meta.name}: no adapter is implemented, so there is nothing to test. Credentials being present does not mean the provider is connected.`,
    };
  }
}

const COMMON_STEPS = [
  "Get merchant/API access approved by the provider and obtain credentials for BOTH sandbox and production.",
  "Implement verifyTransaction() and testConnection() in apps/api/src/payments/providers.ts strictly from the provider's official documentation.",
  "Set meta.implemented = true and capabilities().apiVerification = true only after testing against the provider's sandbox.",
  "Store credentials via the secure fields on this page (needs SECRETS_ENCRYPTION_KEY) or as server environment variables — never in code or the frontend.",
  "Use the Test connection button; the provider is shown as Connected only after a successful server-side test.",
];

class BkashAdapter extends SlotAdapter {
  meta: AdapterMeta = {
    code: "bkash", name: "bKash", kind: "payment", implemented: false, requiresApproval: true,
    summary: "bKash merchant API verification. Requires an approved bKash merchant/API account.",
    secrets: [
      { key: "APP_KEY", label: "App key" }, { key: "APP_SECRET", label: "App secret" },
      { key: "USERNAME", label: "API username" }, { key: "PASSWORD", label: "API password" },
    ],
    settings: [{ key: "BASE_URL", label: "API base URL", placeholder: "https://… (from your bKash onboarding docs)" }],
    instructions: COMMON_STEPS,
  };
}
class NagadAdapter extends SlotAdapter {
  meta: AdapterMeta = {
    code: "nagad", name: "Nagad", kind: "payment", implemented: false, requiresApproval: true,
    summary: "Nagad merchant API verification. Requires an approved Nagad merchant account.",
    secrets: [{ key: "PRIVATE_KEY", label: "Merchant private key" }],
    settings: [
      { key: "BASE_URL", label: "API base URL", placeholder: "https://… (from your Nagad onboarding docs)" },
      { key: "MERCHANT_ID", label: "Merchant ID" },
      { key: "PUBLIC_KEY", label: "Provider public key" },
    ],
    instructions: COMMON_STEPS,
  };
}
class RocketAdapter extends SlotAdapter {
  meta: AdapterMeta = {
    code: "rocket", name: "Rocket", kind: "payment", implemented: false, requiresApproval: true,
    summary: "No public verification API is assumed. Use manual review or an approved aggregator / verification service.",
    secrets: [{ key: "API_KEY", label: "API key (aggregator)" }],
    settings: [],
    instructions: [
      "No public API is assumed for Rocket. Use the Manual review mode in Payment Management, or contract an authorised aggregator.",
      ...COMMON_STEPS,
    ],
  };
}
class UpayAdapter extends SlotAdapter {
  meta: AdapterMeta = {
    code: "upay", name: "Upay", kind: "payment", implemented: false, requiresApproval: true,
    summary: "No public verification API is assumed. Use manual review or an approved aggregator / verification service.",
    secrets: [{ key: "API_KEY", label: "API key (aggregator)" }],
    settings: [],
    instructions: [
      "No public API is assumed for Upay. Use the Manual review mode in Payment Management, or contract an authorised aggregator.",
      ...COMMON_STEPS,
    ],
  };
}
/** Future module: add a Bitcoin processor adapter (invoice + confirmations) without touching the wallet. */
class BitcoinAdapter extends SlotAdapter {
  meta: AdapterMeta = {
    code: "bitcoin", name: "Bitcoin (future)", kind: "payment", implemented: false, requiresApproval: true,
    summary: "Planned. A compatible Bitcoin payment processor adapter can be added later without changing the wallet/ledger.",
    secrets: [], settings: [],
    instructions: [
      "Choose a payment processor that offers signed webhooks and confirmation counts.",
      "Implement an adapter that creates invoices and reports confirmed payments to finalizeDeposit() (the only function that credits a wallet).",
      "Add its credential fields to this adapter's meta, then follow the standard steps below.",
      ...COMMON_STEPS,
    ],
  };
  async isConfigured() {
    return false;
  }
}
/** Placeholder for future digital-service fulfillment APIs (e.g. top-up / delivery providers). */
class DigitalServiceAdapter extends SlotAdapter {
  meta: AdapterMeta = {
    code: "digital_service", name: "Digital service API (future)", kind: "service", implemented: false, requiresApproval: false,
    summary: "Placeholder for automatic fulfillment providers. Each real provider needs its own adapter.",
    secrets: [], settings: [],
    instructions: [
      "A new provider is NOT enabled by entering a URL and API key. Write a backend adapter for it (see docs/INTEGRATIONS.md).",
      "Fulfillment must be idempotent and must only mark an order delivered after the provider confirms success.",
      ...COMMON_STEPS,
    ],
  };
  async isConfigured() {
    return false;
  }
}

const list: PaymentProviderAdapter[] = [
  new BkashAdapter(), new NagadAdapter(), new RocketAdapter(), new UpayAdapter(), new BitcoinAdapter(), new DigitalServiceAdapter(),
];
const adapters: Record<string, PaymentProviderAdapter> = Object.fromEntries(list.map((a) => [a.code, a]));

export function getAdapter(code: string): PaymentProviderAdapter | undefined {
  return adapters[code];
}
export function listAdapters(): PaymentProviderAdapter[] {
  return list;
}
