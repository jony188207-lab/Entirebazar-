/**
 * Payment / integration provider contract.
 *
 * A provider adapter may ONLY report "verified" when an approved, authenticated
 * source (the provider's merchant API, or a signed webhook from an authorised
 * verification service) confirms the transaction. Adapters must never guess,
 * simulate or fabricate a result.
 */
export interface VerifyInput {
  trxId: string;
  expectedAmount: string; // decimal string
  receiverNumber?: string | null;
  senderNumber?: string | null;
}

export type VerifyResult =
  | {
      status: "verified";
      trxId: string;
      amount: string;
      senderNumber?: string;
      receiverNumber?: string;
      raw?: unknown;
    }
  | { status: "not_found" } // provider has no such transaction (yet)
  | { status: "unsupported"; reason: string } // no approved API configured
  | { status: "error"; reason: string }; // transient failure, retry later

export interface FieldSpec {
  key: string; // e.g. "APP_KEY" (env var = <PROVIDER>_<KEY>)
  label: string;
  placeholder?: string;
  required?: boolean; // default true
}

/** Static description of an integration, shown in the admin API Integrations page. */
export interface AdapterMeta {
  code: string;
  name: string;
  kind: "payment" | "service";
  /** True only when verifyTransaction/testConnection really talk to the provider. */
  implemented: boolean;
  requiresApproval: boolean;
  summary: string;
  secrets: FieldSpec[];
  settings: FieldSpec[];
  instructions: string[];
}

export interface PaymentProviderAdapter {
  readonly code: string;
  readonly meta: AdapterMeta;
  /** True only when every required credential/setting is present for the ACTIVE environment. */
  isConfigured(): Promise<boolean>;
  /** What this adapter can do. */
  capabilities(): { apiVerification: boolean };
  verifyTransaction(input: VerifyInput): Promise<VerifyResult>;
  /** Safe, read-only server-side connectivity/credential test. Never moves money. */
  testConnection(): Promise<{ ok: boolean; message: string }>;
}
