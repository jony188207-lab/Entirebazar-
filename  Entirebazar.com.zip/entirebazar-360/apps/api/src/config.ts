import path from "path";
function req(name: string, fallback?: string): string {
  const v = process.env[name] ?? fallback;
  if (v === undefined || v === "") throw new Error(`Missing required env var ${name}`);
  return v;
}

const nodeEnv = process.env.NODE_ENV ?? "development";

export const config = {
  nodeEnv,
  isProd: nodeEnv === "production",
  port: Number(process.env.PORT ?? 4000),
  botToken: req("BOT_TOKEN"),
  // Display name only. The actual bot username (BOT_USERNAME) is configured in @BotFather and is not changed here.
  appName: process.env.APP_NAME ?? "EntireBazar 360",
  syncBotProfile: process.env.SYNC_BOT_PROFILE === "true",
  botUsername: process.env.BOT_USERNAME ?? "",
  miniAppUrl: process.env.MINI_APP_URL ?? "",
  initDataMaxAge: Number(process.env.INIT_DATA_MAX_AGE ?? 3600),
  // Administrators must have launched the Mini App very recently to sign in, and sensitive actions
  // (money, credentials, roles) additionally require a token issued within ADMIN_FRESH_SECONDS.
  uploadDir: path.resolve(process.env.UPLOAD_DIR ?? "uploads"),
  adminInitDataMaxAge: Number(process.env.ADMIN_INIT_DATA_MAX_AGE ?? 600),
  adminFreshSeconds: Number(process.env.ADMIN_FRESH_SECONDS ?? 1800),
  maxWalletAdjustment: Number(process.env.MAX_WALLET_ADJUSTMENT ?? 50000),
  // "b2" in production. "local" only for development without credentials.
  storageDriver: (process.env.STORAGE_DRIVER ?? (nodeEnv === "production" ? "b2" : "local")) as "b2" | "local",
  b2: {
    endpoint: process.env.B2_S3_ENDPOINT ?? "", // e.g. s3.us-west-004.backblazeb2.com (host only)
    region: process.env.B2_REGION ?? "", // e.g. us-west-004
    keyId: process.env.B2_KEY_ID ?? "",
    appKey: process.env.B2_APPLICATION_KEY ?? "",
    publicBucket: process.env.B2_PUBLIC_BUCKET ?? "",
    privateBucket: process.env.B2_PRIVATE_BUCKET ?? "",
    publicBaseUrl: process.env.B2_PUBLIC_BASE_URL ?? "", // e.g. https://f004.backblazeb2.com/file/<public-bucket> or your CDN domain
  },
  jwtSecret: req("JWT_SECRET"),
  adminJwtSecret: req("ADMIN_JWT_SECRET"),
  webOrigin: process.env.WEB_ORIGIN ?? "http://localhost:3000",
  adminTelegramIds: (process.env.ADMIN_TELEGRAM_IDS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),
  adminAlertChatId: process.env.ADMIN_ALERT_CHAT_ID ?? "",
  paymentEnv: (process.env.PAYMENT_ENV ?? "sandbox") as "sandbox" | "production",
  paymentWebhookSecret: process.env.PAYMENT_WEBHOOK_SECRET ?? "",
  deposit: {
    min: Number(process.env.DEPOSIT_MIN ?? 50),
    max: Number(process.env.DEPOSIT_MAX ?? 25000),
    expiryMinutes: Number(process.env.DEPOSIT_EXPIRY_MINUTES ?? 30),
  },
};

if (config.isProd && config.paymentEnv !== "production") {
  console.warn("[config] NODE_ENV=production but PAYMENT_ENV is not 'production'");
}
if (config.isProd && (config.jwtSecret.length < 32 || config.adminJwtSecret.length < 32)) {
  throw new Error("JWT secrets must be at least 32 characters in production");
}
if (config.storageDriver === "b2" && config.isProd) {
  const b = config.b2;
  const missing = Object.entries({ B2_S3_ENDPOINT: b.endpoint, B2_REGION: b.region, B2_KEY_ID: b.keyId, B2_APPLICATION_KEY: b.appKey, B2_PUBLIC_BUCKET: b.publicBucket, B2_PUBLIC_BASE_URL: b.publicBaseUrl })
    .filter(([, v]) => !v).map(([k]) => k);
  if (missing.length) throw new Error(`STORAGE_DRIVER=b2 needs: ${missing.join(", ")}`);
  if (!/^https:\/\//.test(b.publicBaseUrl)) throw new Error("B2_PUBLIC_BASE_URL must be an https URL");
}
if (config.isProd && config.storageDriver === "local") throw new Error("STORAGE_DRIVER=local is not allowed in production");
