import fs from "fs";
import path from "path";
import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import { config } from "./config";
import { webhookRouter } from "./routes/webhooks";
import { userRouter } from "./routes/user";
import { adminRouter } from "./routes/admin";
import { errorHandler } from "./lib/http";
import { publicUrl } from "./lib/storage";

export const UPLOAD_DIR = config.uploadDir;

const app = express();
app.set("trust proxy", 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors({ origin: config.webOrigin, credentials: false }));
app.use(rateLimit({ windowMs: 60_000, limit: 300 }));

// Webhooks need the RAW body for signature verification, so mount before express.json().
app.use("/webhooks", webhookRouter);

app.use(express.json({ limit: "100kb" }));
// Legacy references: images saved before the move to Backblaze B2 are "/uploads/<32hex>.ext" in the database.
// They keep working: a copy still on local disk is served (dev), otherwise the request is redirected to the migrated B2 object.
app.get("/uploads/:name", (req, res) => {
  const name = req.params.name;
  if (!/^[a-f0-9]{32}\.(png|jpg|webp)$/.test(name)) return res.status(404).end();
  const file = path.join(UPLOAD_DIR, name);
  if (fs.existsSync(file)) return res.sendFile(file, { dotfiles: "deny" });
  if (config.b2.publicBaseUrl) return res.redirect(301, publicUrl(`img/${name}`));
  res.status(404).end();
});
app.get("/health", (_req, res) => res.json({ ok: true, paymentEnv: config.paymentEnv }));
app.use("/api", userRouter);
app.use("/api/admin", adminRouter);
app.use(errorHandler);

app.listen(config.port, () => console.log(`API listening on :${config.port} (payments: ${config.paymentEnv})`));
