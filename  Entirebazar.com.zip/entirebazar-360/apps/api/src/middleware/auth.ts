import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import { User, AdminUser, Role } from "@prisma/client";
import { prisma } from "../db";
import { config } from "../config";
import { Permission, SENSITIVE, permissionsOf } from "../lib/permissions";

declare global {
  namespace Express {
    interface Request {
      user?: User;
      admin?: AdminUser & { customRole: Role | null };
      perms?: Set<Permission>;
      adminTokenIssuedAt?: number;
    }
  }
}

function bearer(req: Request): string | null {
  const h = req.headers.authorization;
  return h && h.startsWith("Bearer ") ? h.slice(7) : null;
}

export async function requireUser(req: Request, res: Response, next: NextFunction) {
  try {
    const token = bearer(req);
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    const p = jwt.verify(token, config.jwtSecret) as { sub: string; k: string };
    if (p.k !== "user") return res.status(401).json({ error: "Unauthorized" });
    const user = await prisma.user.findUnique({ where: { id: p.sub } });
    if (!user || user.status === "BANNED") return res.status(403).json({ error: "Account unavailable" });
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: "Unauthorized" });
  }
}

/** Like requireUser but never fails: anonymous visitors get req.user === undefined (used for the public maintenance/status data). */
export async function optionalUser(req: Request, _res: Response, next: NextFunction) {
  try {
    const token = bearer(req);
    if (token) {
      const p = jwt.verify(token, config.jwtSecret) as { sub: string; k: string };
      if (p.k === "user") {
        const user = await prisma.user.findUnique({ where: { id: p.sub } });
        if (user && user.status !== "BANNED") req.user = user;
      }
    }
  } catch {
    /* anonymous */
  }
  next();
}

/** Blocks RESTRICTED accounts from money-moving actions. */
export function requireActive(req: Request, res: Response, next: NextFunction) {
  if (req.user?.status !== "ACTIVE") return res.status(403).json({ error: "Account restricted" });
  next();
}

/** Authenticates an administrator and loads their effective permissions from the database on every request. */
export async function requireAdmin(req: Request, res: Response, next: NextFunction) {
  try {
    const token = bearer(req);
    if (!token) return res.status(401).json({ error: "Unauthorized" });
    const p = jwt.verify(token, config.adminJwtSecret) as { sub: string; k: string; iat: number };
    if (p.k !== "admin") return res.status(401).json({ error: "Unauthorized" });
    const admin = await prisma.adminUser.findUnique({ where: { id: p.sub }, include: { customRole: true } });
    if (!admin || admin.disabled) return res.status(403).json({ error: "Forbidden" });
    req.admin = admin;
    req.perms = new Set(permissionsOf(admin));
    req.adminTokenIssuedAt = p.iat;
    next();
  } catch {
    res.status(401).json({ error: "Unauthorized" });
  }
}

/**
 * Server-side authorisation for every admin route. The admin must hold ALL of the listed permissions.
 * Sensitive permissions (money, credentials, roles) additionally require a recently issued session token,
 * so a stale/stolen session cannot move money; the admin re-authenticates by reopening the Mini App.
 */
export function requirePerm(...needed: Permission[]) {
  return async (req: Request, res: Response, next: NextFunction) => {
    const have = req.perms;
    const missing = needed.filter((p) => !have?.has(p));
    if (missing.length) {
      await prisma.auditLog
        .create({ data: { adminId: req.admin?.id, action: "permission.denied", targetType: "Route", targetId: `${req.method} ${req.baseUrl}${req.path}`.slice(0, 200), meta: { missing } } })
        .catch(() => undefined);
      return res.status(403).json({ error: "You do not have permission to do this", missing });
    }
    if (needed.some((p) => SENSITIVE.has(p))) {
      const age = Date.now() / 1000 - (req.adminTokenIssuedAt ?? 0);
      if (age > config.adminFreshSeconds) {
        return res.status(403).json({ error: "For your security, reopen the Mini App to re-authenticate before doing this.", code: "REAUTH_REQUIRED" });
      }
    }
    next();
  };
}

/** Passes when the admin holds AT LEAST ONE of the listed permissions (e.g. uploads used by several editors). */
export function requireAny(...any: Permission[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (any.some((p) => req.perms?.has(p))) return next();
    res.status(403).json({ error: "You do not have permission to do this" });
  };
}

export function signUserToken(userId: string) {
  return jwt.sign({ sub: userId, k: "user" }, config.jwtSecret, { expiresIn: "6h" });
}
export function signAdminToken(adminId: string) {
  return jwt.sign({ sub: adminId, k: "admin" }, config.adminJwtSecret, { expiresIn: "2h" });
}

export async function audit(
  req: Request,
  action: string,
  targetType?: string,
  targetId?: string,
  meta?: Record<string, unknown>
) {
  await prisma.auditLog.create({
    data: { adminId: req.admin?.id, action, targetType, targetId, meta: (meta ?? undefined) as any },
  });
}
