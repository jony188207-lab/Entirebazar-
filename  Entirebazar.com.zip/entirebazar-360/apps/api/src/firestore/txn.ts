/**
 * Minimal transaction surface used by the Firestore money core.
 * firebase-admin's `Transaction` is adapted to this in `adminAdapter.ts`; tests use an in-memory implementation.
 * Same rules as Firestore: ALL reads must happen before the first write, `create` fails if the document exists,
 * and the whole function is re-run if a document it read changed before commit.
 */
export type Doc = Record<string, any>;

export interface TxLike {
  get(path: string): Promise<Doc | undefined>;
  /** Fails the commit with ALREADY_EXISTS when the document exists. This is how unique constraints are enforced. */
  create(path: string, data: Doc): void;
  set(path: string, data: Doc): void;
  update(path: string, data: Doc): void;
  newId(): string;
}

export type RunTx = <T>(fn: (tx: TxLike) => Promise<T>) => Promise<T>;

export class AlreadyExists extends Error {
  constructor(public path: string) {
    super(`Document already exists: ${path}`);
  }
}
