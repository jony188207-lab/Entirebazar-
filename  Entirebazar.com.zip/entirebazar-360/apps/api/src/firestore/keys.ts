import { TxLike } from "./txn";

/**
 * Firestore replacement for `SELECT … FOR UPDATE SKIP LOCKED` licence-key claiming.
 * The caller queries up to `quantity` unused key documents (query happens through the SDK transaction adapter, which
 * supplies the candidates), then this function marks them used. If another transaction claimed the same key first, Firestore
 * retries this transaction and the candidate list is re-queried, so a key is never delivered twice.
 * Throws OutOfStock when fewer than `quantity` candidates exist.
 */
export class OutOfStock extends Error {
  constructor() { super("Out of stock"); }
}
export async function claimKeys(tx: TxLike, candidates: { path: string }[], quantity: number, orderItemId: string, now: Date): Promise<string[]> {
  if (candidates.length < quantity) throw new OutOfStock();
  const chosen = candidates.slice(0, quantity);
  const docs = await Promise.all(chosen.map((c) => tx.get(c.path)));
  docs.forEach((d) => { if (!d || d.usedAt) throw new OutOfStock(); });
  chosen.forEach((c) => tx.update(c.path, { usedAt: now, orderItemId }));
  return docs.map((d) => d!.secret as string);
}
