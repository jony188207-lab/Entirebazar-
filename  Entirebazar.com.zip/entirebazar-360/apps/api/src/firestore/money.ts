/** Money is stored as INTEGER minor units (paisa). Never a float: Firestore numbers are doubles. */
export function toMinor(v: string | number): number {
  const s = typeof v === "number" ? v.toFixed(2) : v.trim();
  if (!/^-?\d+(\.\d{1,2})?$/.test(s)) throw new Error("Invalid money amount");
  const neg = s.startsWith("-");
  const [i, f = ""] = s.replace("-", "").split(".");
  const n = Number(i) * 100 + Number((f + "00").slice(0, 2));
  if (!Number.isSafeInteger(n)) throw new Error("Money amount out of range");
  return neg ? -n : n;
}
export function fromMinor(n: number): string {
  if (!Number.isSafeInteger(n)) throw new Error("Invalid minor amount");
  const neg = n < 0, a = Math.abs(n);
  return `${neg ? "-" : ""}${Math.floor(a / 100)}.${String(a % 100).padStart(2, "0")}`;
}
