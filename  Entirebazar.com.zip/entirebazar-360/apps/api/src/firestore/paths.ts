/** Single source of truth for Firestore paths and deterministic document IDs. Never build paths by hand elsewhere. */
export const P = {
  user: (uid: string) => `users/${uid}`,
  wallet: (uid: string) => `wallets/${uid}`,
  ledger: (uid: string, refType: string, refId: string, direction: "CREDIT" | "DEBIT") =>
    `wallets/${uid}/ledger/${ledgerId(refType, refId, direction)}`,
  deposit: (id: string) => `deposits/${id}`,
  depositEvent: (depositId: string, eventId: string) => `deposits/${depositId}/events/${eventId}`,
  /** Unique constraint (providerCode, providerTrxId): one document per provider transaction reference. */
  trxKey: (providerCode: string, providerTrxId: string) => `trxKeys/${safeId(`${providerCode}__${providerTrxId}`)}`,
  provider: (code: string) => `paymentProviders/${code}`,
  orderIdem: (uid: string, clientRef: string) => `orderIdem/${safeId(`${uid}__${clientRef}`)}`,
  order: (id: string) => `orders/${id}`,
  product: (id: string) => `products/${id}`,
  key: (productId: string, keyId: string) => `products/${productId}/keys/${keyId}`,
  audit: (id: string) => `auditLogs/${id}`,
};

export const ledgerId = (refType: string, refId: string, direction: string) => safeId(`${refType}__${refId}__${direction}`);

/** Firestore IDs cannot contain "/" and must not be "." or "..". Keep them reversible-ish and collision-free. */
export function safeId(raw: string): string {
  if (!raw || raw.length > 400) throw new Error("Invalid id");
  return encodeURIComponent(raw).replace(/\./g, "%2E");
}
