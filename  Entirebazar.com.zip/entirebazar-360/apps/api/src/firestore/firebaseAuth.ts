import { firebase } from "./adminAdapter";

/**
 * Firebase Authentication for a Telegram user. Telegram stays the identity provider: the API first validates
 * Telegram initData (lib/telegramAuth.ts), and only then mints a Firebase custom token for uid = "tg_<telegramId>".
 * Admin rights are NEVER taken from the token: they are re-read from the database on every request (middleware/auth.ts).
 * NOT WIRED / NOT TESTED (firebase-admin unavailable when this was written).
 */
export async function mintFirebaseToken(telegramId: string): Promise<string> {
  if (!/^\d{1,15}$/.test(telegramId)) throw new Error("Invalid Telegram id");
  return firebase().auth.createCustomToken(`tg_${telegramId}`, { provider: "telegram" });
}
