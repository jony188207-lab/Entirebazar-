/**
 * firebase-admin glue. NOT WIRED into the running API yet and NOT TESTED: `firebase-admin` could not be installed
 * in the environment that produced this code (npm registry blocked), so this file has never been compiled against it.
 * It is loaded lazily so the API still builds and starts without the package.
 *
 * Credentials (server only): FIREBASE_PROJECT_ID + FIREBASE_CLIENT_EMAIL + FIREBASE_PRIVATE_KEY, or GOOGLE_APPLICATION_CREDENTIALS.
 * Local development: set FIRESTORE_EMULATOR_HOST=127.0.0.1:8080 and no credentials are needed.
 */
import { TxLike, RunTx } from "./txn";

let cached: { db: any; auth: any } | null = null;

export function firebase(): { db: any; auth: any } {
  if (cached) return cached;
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const app = require("firebase-admin/app");
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { getFirestore } = require("firebase-admin/firestore");
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { getAuth } = require("firebase-admin/auth");
  const { FIREBASE_PROJECT_ID: projectId, FIREBASE_CLIENT_EMAIL: clientEmail } = process.env;
  const privateKey = process.env.FIREBASE_PRIVATE_KEY?.replace(/\\n/g, "\n");
  if (!app.getApps().length) {
    app.initializeApp(
      projectId && clientEmail && privateKey
        ? { credential: app.cert({ projectId, clientEmail, privateKey }), projectId }
        : { projectId } // falls back to GOOGLE_APPLICATION_CREDENTIALS / the emulator
    );
  }
  const db = getFirestore();
  db.settings({ ignoreUndefinedProperties: false }); // an undefined field is a bug; fail loudly instead of dropping it
  cached = { db, auth: getAuth() };
  return cached;
}

/** Adapts a firebase-admin Transaction to TxLike. Firestore itself enforces reads-before-writes and retries on contention. */
export const runTransaction: RunTx = (fn) => {
  const { db } = firebase();
  return db.runTransaction(async (t: any) => {
    const tx: TxLike = {
      get: async (path) => {
        const snap = await t.get(db.doc(path));
        return snap.exists ? snap.data() : undefined;
      },
      create: (path, data) => t.create(db.doc(path), data),
      set: (path, data) => t.set(db.doc(path), data),
      update: (path, data) => t.update(db.doc(path), data),
      newId: () => db.collection("_ids").doc().id,
    };
    return fn(tx);
  }, { maxAttempts: 10 });
};
