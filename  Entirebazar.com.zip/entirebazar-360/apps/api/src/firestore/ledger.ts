import { TxLike } from "./txn";
import { P } from "./paths";

export class InsufficientFunds extends Error {
  constructor() { super("Insufficient wallet balance"); }
}

export interface PostEntryInput {
  userId: string;
  type: "DEPOSIT" | "PURCHASE" | "REFUND" | "ADJUSTMENT";
  direction: "CREDIT" | "DEBIT";
  amountMinor: number;
  refType: string;
  refId: string;
  note?: string;
  now: Date;
}

/**
 * Firestore equivalent of services/ledger.ts `postEntry`.
 *  - Prisma: wallet row FOR UPDATE + unique (refType, refId, direction).
 *  - Firestore: the wallet document is read inside the transaction (optimistic lock: a concurrent change makes the
 *    transaction retry) and the ledger entry id IS (refType, refId, direction), so a second post is detected by reading it.
 * Performs its READS first; call it before any other write in the same transaction.
 */
export async function postEntry(tx: TxLike, p: PostEntryInput): Promise<{ duplicate: boolean; balanceAfterMinor: number }> {
  if (!Number.isSafeInteger(p.amountMinor) || p.amountMinor <= 0) throw new Error("Ledger amount must be a positive integer");
  const walletPath = P.wallet(p.userId);
  const entryPath = P.ledger(p.userId, p.refType, p.refId, p.direction);
  const wallet = await tx.get(walletPath);
  if (!wallet) throw new Error("Wallet not found");
  const existing = await tx.get(entryPath);
  if (existing) return { duplicate: true, balanceAfterMinor: existing.balanceAfterMinor };

  const next = p.direction === "CREDIT" ? wallet.balanceMinor + p.amountMinor : wallet.balanceMinor - p.amountMinor;
  if (next < 0) throw new InsufficientFunds();
  if (!Number.isSafeInteger(next)) throw new Error("Balance overflow");
  tx.create(entryPath, {
    userId: p.userId, type: p.type, direction: p.direction, amountMinor: p.amountMinor, balanceAfterMinor: next,
    refType: p.refType, refId: p.refId, note: p.note ?? null, createdAt: p.now,
  });
  tx.update(walletPath, { balanceMinor: next, version: (wallet.version ?? 0) + 1, updatedAt: p.now });
  return { duplicate: false, balanceAfterMinor: next };
}
