import { TxLike } from "./txn";
import { P } from "./paths";
import { postEntry } from "./ledger";

export interface VerifiedTrx {
  providerTrxId: string;
  amountMinor: number;
  senderNumber?: string;
  receiverNumber?: string;
  source: string; // "api" | "webhook" | "admin"
}
export type FinalizeResult = "credited" | "already" | "not_pending" | "missing" | "mismatch" | "trx_mismatch" | "receiver_mismatch" | "duplicate";

/**
 * Firestore equivalent of services/deposits.ts `finalizeDeposit`: the ONLY place a deposit becomes SUCCESSFUL and the wallet is credited.
 * All reads first, then writes. Every business rule is the same as the Prisma version:
 *  - only PENDING deposits; SUCCESSFUL is reported as "already" (idempotent)
 *  - paid amount must equal the invoice amount exactly, receiver must match the provider's receiver number
 *  - a provider transaction reference can belong to one deposit only (trxKeys/<provider>__<trxId> created atomically)
 *  - the ledger credit is idempotent (document id = deposit/<id>/CREDIT)
 */
export async function finalizeDepositTx(tx: TxLike, depositId: string, trx: VerifiedTrx, now: Date, adminId?: string): Promise<FinalizeResult> {
  const depPath = P.deposit(depositId);
  const dep = await tx.get(depPath);
  if (!dep) return "missing";
  if (dep.status === "SUCCESSFUL") return "already";
  if (dep.status !== "PENDING") return "not_pending";
  const provider = await tx.get(P.provider(dep.providerCode));
  if (!provider) return "missing";
  const trxKeyPath = P.trxKey(dep.providerCode, trx.providerTrxId);
  const trxKey = await tx.get(trxKeyPath);
  // postEntry reads wallet + ledger entry; do it BEFORE any write below.
  const walletPath = P.wallet(dep.userId);
  const wallet = await tx.get(walletPath);
  if (!wallet) throw new Error("Wallet not found");

  const flag = (kind: string, payload: Record<string, any>) => {
    tx.update(depPath, { needsReview: true });
    tx.create(P.depositEvent(depositId, tx.newId()), { source: trx.source, kind, payload, createdAt: now });
  };

  if (trx.amountMinor !== dep.amountMinor) { flag("amount_mismatch", { expectedMinor: dep.amountMinor, gotMinor: trx.amountMinor }); return "mismatch"; }
  if (dep.providerTrxId && dep.providerTrxId !== trx.providerTrxId) return "trx_mismatch";
  if (trx.receiverNumber && provider.receiverNumber && trx.receiverNumber !== provider.receiverNumber) {
    flag("receiver_mismatch", {}); return "receiver_mismatch";
  }
  if (trxKey && trxKey.depositId !== depositId) return "duplicate";

  // postEntry does its remaining READ (the ledger entry) and then its writes, so it must run before any other write here.
  const posted = await postEntryAfterReads(tx, dep, trx, now);
  if (!trxKey) {
    tx.create(trxKeyPath, {
      depositId, providerCode: dep.providerCode, providerTrxId: trx.providerTrxId, amountMinor: trx.amountMinor,
      senderNumber: trx.senderNumber ?? null, receiverNumber: trx.receiverNumber ?? null, createdAt: now,
    });
  }
  tx.update(depPath, { status: "SUCCESSFUL", verifiedAt: now, needsReview: false, reviewedBy: adminId ?? null });
  tx.create(P.depositEvent(depositId, tx.newId()), { source: trx.source, kind: "credited", payload: { trxId: trx.providerTrxId, adminId: adminId ?? null, duplicateLedger: posted.duplicate }, createdAt: now });
  return "credited";
}

// postEntry performs its own reads (cached by the transaction), which is safe here because the wallet doc was already read above and no write has happened yet.
async function postEntryAfterReads(tx: TxLike, dep: any, trx: VerifiedTrx, now: Date) {
  return postEntry(tx, {
    userId: dep.userId, type: "DEPOSIT", direction: "CREDIT", amountMinor: dep.amountMinor,
    refType: "deposit", refId: dep.id, note: `${dep.providerCode} ${trx.providerTrxId}`, now,
  });
}
