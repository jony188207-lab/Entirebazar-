import { NotificationType } from "@prisma/client";
import { prisma } from "../db";
import { config } from "../config";
import { sendTelegramMessage, escapeHtml } from "../lib/telegram";

const PREF: Partial<Record<NotificationType, "notifyPayments" | "notifyOrders" | "notifyPromos">> = {
  PAYMENT: "notifyPayments",
  REFUND: "notifyPayments",
  ORDER: "notifyOrders",
  DELIVERY: "notifyOrders",
  ANNOUNCEMENT: "notifyPromos",
};

/**
 * Always stores an in-app notification. Also pushes to Telegram unless the user
 * opted out or blocked the bot. Failures are recorded, never thrown.
 */
export async function notifyUser(
  userId: string,
  type: NotificationType,
  title: string,
  body: string,
  deepLink?: string
) {
  const user = await prisma.user.findUnique({ where: { id: userId } });
  if (!user) return null;

  const prefKey = PREF[type];
  const wantsTelegram = !user.botBlocked && (prefKey ? user[prefKey] : true);

  const n = await prisma.notification.create({
    data: {
      userId,
      type,
      title,
      body,
      deepLink,
      telegram: wantsTelegram ? "PENDING" : "NOT_REQUIRED",
    },
  });
  if (!wantsTelegram) return n;

  const text = `<b>${escapeHtml(title)}</b>\n${escapeHtml(body)}`;
  let res = await sendTelegramMessage(user.telegramId, text, deepLink);
  if (!res.ok && res.retryAfter && res.retryAfter <= 5) {
    const waitSeconds = res.retryAfter;
    await new Promise((r) => setTimeout(r, waitSeconds * 1000));
    res = await sendTelegramMessage(user.telegramId, text, deepLink);
  }
  if (res.ok) {
    await prisma.notification.update({ where: { id: n.id }, data: { telegram: "SENT" } });
  } else {
    if (res.blocked) await prisma.user.update({ where: { id: userId }, data: { botBlocked: true } });
    await prisma.notification.update({
      where: { id: n.id },
      data: { telegram: res.blocked ? "BLOCKED" : "FAILED", telegramError: res.error.slice(0, 300) },
    });
  }
  return n;
}

export async function notifyAdmins(text: string, openPath?: string) {
  const targets = new Set<string>();
  if (config.adminAlertChatId) targets.add(config.adminAlertChatId);
  if (targets.size === 0) config.adminTelegramIds.forEach((id) => targets.add(id));
  for (const chat of targets) {
    const r = await sendTelegramMessage(chat, escapeHtml(text), openPath);
    if (!r.ok) console.error("[notifyAdmins] failed:", r.error);
  }
}
