import { prisma } from "../db";
import { config } from "../config";
import { UserError } from "../lib/errors";
import { validateHttpsUrl } from "../lib/validate";
import { sanitizeError } from "../lib/secretbox";
import { getAdapter, listAdapters } from "../payments/providers";
import { Mode, SecretStatus, deleteSecret, getSecret, secretStatus, secretsKeyState, setSecret } from "./secrets";

/**
 * A provider is shown as CONNECTED only when ALL of these hold:
 *   adapter implemented  AND  credentials present  AND  enabled  AND  mode matches the server's PAYMENT_ENV
 *   AND  a server-side connection test succeeded recently.
 * A saved form is never treated as proof of connectivity.
 */
export type IntegrationState =
  | "NOT_IMPLEMENTED" | "MISSING_CREDENTIALS" | "DISABLED" | "MODE_MISMATCH" | "UNTESTED" | "TEST_FAILED" | "CONNECTED";

export const STATE_LABEL: Record<IntegrationState, string> = {
  NOT_IMPLEMENTED: "Not implemented — adapter needs development",
  MISSING_CREDENTIALS: "Credentials missing",
  DISABLED: "Disabled",
  MODE_MISMATCH: "Mode does not match server environment",
  UNTESTED: "Configured — not tested",
  TEST_FAILED: "Last connection test failed",
  CONNECTED: "Connected (test succeeded)",
};
const TEST_FRESH_MS = 24 * 60 * 60 * 1000;
const MODES: Mode[] = ["sandbox", "production"];
const toDbMode = (m: Mode) => (m === "production" ? "PRODUCTION" : "SANDBOX") as "PRODUCTION" | "SANDBOX";
const fromDbMode = (m: string): Mode => (m === "PRODUCTION" ? "production" : "sandbox");

async function ensureConfig(code: string) {
  return prisma.integrationConfig.upsert({ where: { code }, update: {}, create: { code } });
}

interface ConfigRow {
  enabled: boolean;
  mode: string;
  lastTestOk: boolean | null;
  lastTestAt: Date | null;
}

export function computeState(implemented: boolean, configured: boolean, cfg: ConfigRow, serverEnv: Mode, now = Date.now()): IntegrationState {
  if (!implemented) return "NOT_IMPLEMENTED";
  if (!configured) return "MISSING_CREDENTIALS";
  if (!cfg.enabled) return "DISABLED";
  if (fromDbMode(cfg.mode) !== serverEnv) return "MODE_MISMATCH";
  if (cfg.lastTestOk === true && cfg.lastTestAt && now - cfg.lastTestAt.getTime() < TEST_FRESH_MS) return "CONNECTED";
  if (cfg.lastTestOk === false) return "TEST_FAILED";
  return "UNTESTED";
}

/**
 * Whether the deposit verifier may call this provider's API. Deliberately a little looser than CONNECTED
 * (a day-old successful test still counts), but never true for an unimplemented or failing integration.
 */
export async function integrationUsableForVerification(code: string): Promise<boolean> {
  const adapter = getAdapter(code);
  if (!adapter || !adapter.meta.implemented) return false;
  const cfg = await prisma.integrationConfig.findUnique({ where: { code } });
  if (!cfg || !cfg.enabled || fromDbMode(cfg.mode) !== config.paymentEnv || cfg.lastTestOk === false) return false;
  return adapter.isConfigured();
}

export async function listIntegrations() {
  const out = [];
  for (const a of listAdapters()) out.push(await viewOf(a.code));
  return out;
}

export async function viewOf(code: string) {
  const adapter = getAdapter(code);
  if (!adapter) throw new UserError("Unknown integration", 404);
  const cfg = await ensureConfig(code);
  const mode = fromDbMode(cfg.mode);
  const configured = await adapter.isConfigured();
  const state = computeState(adapter.meta.implemented, configured, cfg, config.paymentEnv);

  const secrets: Record<Mode, SecretStatus[]> = { sandbox: [], production: [] };
  for (const m of MODES) for (const f of adapter.meta.secrets) secrets[m].push(await secretStatus(code, f.key, m));

  const stored = (cfg.settings ?? {}) as Record<string, unknown>;
  const settings = adapter.meta.settings.map((f) => ({
    ...f,
    value: typeof stored[f.key] === "string" ? (stored[f.key] as string) : "",
    fromEnv: !stored[f.key] && !!process.env[`${code.toUpperCase()}_${f.key}`],
  }));

  const logs = await prisma.integrationLog.findMany({ where: { code }, orderBy: { createdAt: "desc" }, take: 20 });

  return {
    code,
    name: adapter.meta.name,
    kind: adapter.meta.kind,
    summary: adapter.meta.summary,
    implemented: adapter.meta.implemented,
    requiresApproval: adapter.meta.requiresApproval,
    instructions: adapter.meta.instructions,
    enabled: cfg.enabled,
    mode,
    serverEnvironment: config.paymentEnv,
    encryptionKey: secretsKeyState(),
    secrets,
    secretFields: adapter.meta.secrets,
    settings,
    status: { state, label: STATE_LABEL[state] },
    lastTest: cfg.lastTestAt ? { at: cfg.lastTestAt, ok: cfg.lastTestOk, message: cfg.lastTestMessage } : null,
    logs,
  };
}

async function log(code: string, level: "info" | "warn" | "error", message: string, secrets: string[] = []) {
  await prisma.integrationLog.create({ data: { code, level, message: sanitizeError(message, secrets) } });
}

async function secretValues(code: string): Promise<string[]> {
  const adapter = getAdapter(code);
  if (!adapter) return [];
  const vals: string[] = [];
  for (const m of MODES) for (const f of adapter.meta.secrets) {
    const v = await getSecret(code, f.key, m);
    if (v) vals.push(v);
  }
  return vals;
}

export async function updateIntegration(
  code: string,
  patch: { enabled?: boolean; mode?: Mode; settings?: Record<string, string> },
  adminId: string
) {
  const adapter = getAdapter(code);
  if (!adapter) throw new UserError("Unknown integration", 404);
  const cur = await ensureConfig(code);

  const nextMode = patch.mode ?? fromDbMode(cur.mode);
  const nextEnabled = patch.enabled ?? cur.enabled;

  if (nextEnabled) {
    if (!adapter.meta.implemented) {
      throw new UserError(`${adapter.meta.name} has no implemented adapter yet, so it cannot be enabled. See the setup instructions on this page.`);
    }
    if (nextMode !== config.paymentEnv) {
      throw new UserError(`This server runs PAYMENT_ENV=${config.paymentEnv}. Switch the deployment environment before enabling ${nextMode} mode.`);
    }
  }

  let settings = (cur.settings ?? {}) as Record<string, string>;
  if (patch.settings) {
    const allowed = new Set(adapter.meta.settings.map((s) => s.key));
    const next: Record<string, string> = { ...settings };
    for (const [k, v] of Object.entries(patch.settings)) {
      if (!allowed.has(k)) throw new UserError(`Unknown setting ${k}`);
      if (typeof v !== "string" || v.length > 4000) throw new UserError(`Invalid value for ${k}`);
      const t = v.trim();
      if (k.endsWith("URL") && !k.includes("PUBLIC") && t) {
        const chk = validateHttpsUrl(t);
        if (!chk.ok) throw new UserError(`${k}: ${chk.reason}`);
      }
      if (t) next[k] = t;
      else delete next[k];
    }
    settings = next;
  }

  await prisma.integrationConfig.update({
    where: { code },
    data: { enabled: nextEnabled, mode: toDbMode(nextMode), settings: settings as any, updatedBy: adminId },
  });
  await log(code, "info", `Configuration updated (enabled=${nextEnabled}, mode=${nextMode})`);
  return viewOf(code);
}

export async function replaceSecret(code: string, name: string, mode: Mode, value: string, adminId: string) {
  const adapter = getAdapter(code);
  if (!adapter) throw new UserError("Unknown integration", 404);
  if (!adapter.meta.secrets.some((s) => s.key === name)) throw new UserError("Unknown credential field");
  if (secretsKeyState() !== "ok") {
    throw new UserError(
      "SECRETS_ENCRYPTION_KEY is missing or invalid on the server, so credentials cannot be stored from the panel. Set it (openssl rand -base64 32) or provide the credential as an environment variable.",
      503
    );
  }
  await setSecret(code, name, mode, value.trim(), adminId);
  // A new credential invalidates any earlier "connected" result.
  await prisma.integrationConfig.update({ where: { code }, data: { lastTestOk: null, lastTestAt: null, lastTestMessage: null } }).catch(() => undefined);
  await log(code, "info", `Credential ${name} (${mode}) replaced`);
}

export async function clearSecret(code: string, name: string, mode: Mode) {
  const adapter = getAdapter(code);
  if (!adapter || !adapter.meta.secrets.some((s) => s.key === name)) throw new UserError("Unknown credential field");
  await deleteSecret(code, name, mode);
  await prisma.integrationConfig.update({ where: { code }, data: { lastTestOk: null, lastTestAt: null, lastTestMessage: null } }).catch(() => undefined);
  await log(code, "info", `Credential ${name} (${mode}) removed`);
}

/** Runs the adapter's own read-only connectivity test. Results are sanitised before being stored or shown. */
export async function testIntegration(code: string) {
  const adapter = getAdapter(code);
  if (!adapter) throw new UserError("Unknown integration", 404);
  await ensureConfig(code);
  const secrets = await secretValues(code);
  let ok = false;
  let message: string;
  if (!adapter.meta.implemented) {
    message = "Adapter not implemented — there is no real connection to test.";
  } else if (!(await adapter.isConfigured())) {
    message = "Credentials are missing for the active environment.";
  } else {
    try {
      const r = await adapter.testConnection();
      ok = r.ok === true;
      message = sanitizeError(r.message, secrets);
    } catch (e: any) {
      message = sanitizeError(e?.message ?? "Connection test failed", secrets);
    }
  }
  await prisma.integrationConfig.update({
    where: { code },
    data: { lastTestAt: new Date(), lastTestOk: ok, lastTestMessage: message },
  });
  await log(code, ok ? "info" : "warn", `Connection test ${ok ? "succeeded" : "failed"}: ${message}`, secrets);
  return viewOf(code);
}
