import crypto from "crypto";
import { Prisma } from "@prisma/client";
import { prisma } from "../db";
import { config } from "../config";
import { postEntry } from "./ledger";
import { notifyUser, notifyAdmins } from "./notify";
import { getAdapter } from "../payments/providers";
import { integrationUsableForVerification } from "./integrations";

import { UserError } from "../lib/errors";
export { UserError };

const TRX_RE = /^[A-Z0-9]{6,24}$/;

export function normalizeTrxId(raw: string): string {
  const t = raw.trim().toUpperCase();
  if (!TRX_RE.test(t)) throw new UserError("Invalid transaction ID format");
  return t;
}

function newInvoiceNo() {
  return "DP" + Date.now().toString(36).toUpperCase() + crypto.randomBytes(3).toString("hex").toUpperCase();
}

export async function createDeposit(userId: string, providerCode: string, amountRaw: number | string) {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (user.status !== "ACTIVE") throw new UserError("Your account cannot make deposits", 403);

  const provider = await prisma.paymentProvider.findUnique({ where: { code: providerCode } });
  if (!provider || !provider.enabled || provider.isFuture || provider.verificationMode === "DISABLED") {
    throw new UserError("This payment method is unavailable");
  }

  const amount = new Prisma.Decimal(amountRaw);
  if (!amount.isFinite() || amount.decimalPlaces() > 2) throw new UserError("Invalid amount");
  const min = provider.minAmount ?? new Prisma.Decimal(config.deposit.min);
  const max = provider.maxAmount ?? new Prisma.Decimal(config.deposit.max);
  if (amount.lt(min) || amount.gt(max)) throw new UserError(`Amount must be between ${min} and ${max}`);

  const open = await prisma.deposit.count({ where: { userId, status: "PENDING" } });
  if (open >= 3) throw new UserError("Too many pending deposits. Complete or wait for expiry.");

  return prisma.deposit.create({
    data: {
      invoiceNo: newInvoiceNo(),
      userId,
      providerId: provider.id,
      amount,
      expiresAt: new Date(Date.now() + config.deposit.expiryMinutes * 60_000),
    },
    include: { provider: true },
  });
}

export async function submitTransaction(userId: string, depositId: string, trxRaw: string, sender?: string) {
  const trxId = normalizeTrxId(trxRaw);
  const deposit = await prisma.deposit.findFirst({ where: { id: depositId, userId } });
  if (!deposit) throw new UserError("Deposit not found", 404);
  if (deposit.status !== "PENDING") throw new UserError("This deposit is no longer pending");
  if (deposit.expiresAt < new Date()) throw new UserError("This invoice has expired");
  if (deposit.providerTrxId) throw new UserError("A transaction ID was already submitted for this invoice");

  try {
    await prisma.deposit.update({
      where: { id: deposit.id },
      data: { providerTrxId: trxId, senderNumber: sender?.slice(0, 20), submittedAt: new Date() },
    });
  } catch (e: any) {
    if (e?.code === "P2002") throw new UserError("This transaction ID has already been used");
    throw e;
  }
  await prisma.paymentEvent.create({
    data: { depositId, source: "verify", kind: "trx_submitted", payload: { trxId } },
  });
  await attemptVerification(deposit.id);
  return prisma.deposit.findUniqueOrThrow({ where: { id: deposit.id }, include: { provider: true } });
}

interface VerifiedTrx {
  providerTrxId: string;
  amount: string;
  senderNumber?: string;
  receiverNumber?: string;
  raw?: unknown;
  source: "api" | "webhook" | "admin";
}

/** Tries to confirm a deposit from trusted sources only. Never trusts the user-submitted ID alone. */
export async function attemptVerification(depositId: string) {
  const deposit = await prisma.deposit.findUnique({ where: { id: depositId }, include: { provider: true } });
  if (!deposit || deposit.status !== "PENDING" || !deposit.providerTrxId) return;
  const { provider } = deposit;

  // 1) Already reported by a signed webhook / earlier verification?
  const known = await prisma.transaction.findUnique({
    where: { providerCode_providerTrxId: { providerCode: provider.code, providerTrxId: deposit.providerTrxId } },
  });
  if (known) {
    await finalizeDeposit(deposit.id, {
      providerTrxId: known.providerTrxId,
      amount: known.amount.toString(),
      senderNumber: known.senderNumber ?? undefined,
      receiverNumber: known.receiverNumber ?? undefined,
      raw: known.rawPayload,
      source: "webhook",
    });
    return;
  }

  // 2) Approved provider API (only if implemented + configured + enabled for API mode).
  if (provider.verificationMode === "API") {
    const adapter = getAdapter(provider.code);
    // API verification runs only when the adapter is really implemented, credentials exist, the integration is enabled
    // for this server's environment and its last connection test did not fail. Otherwise a human reviews the deposit.
    if (adapter && adapter.meta.implemented && adapter.capabilities().apiVerification && (await integrationUsableForVerification(provider.code))) {
      const r = await adapter.verifyTransaction({
        trxId: deposit.providerTrxId,
        expectedAmount: deposit.amount.toString(),
        receiverNumber: provider.receiverNumber,
        senderNumber: deposit.senderNumber,
      });
      await prisma.paymentEvent.create({
        data: { depositId, source: "verify", kind: `api_${r.status}`, payload: r as any },
      });
      if (r.status === "verified") {
        await finalizeDeposit(deposit.id, {
          providerTrxId: r.trxId,
          amount: r.amount,
          senderNumber: r.senderNumber,
          receiverNumber: r.receiverNumber,
          raw: r.raw,
          source: "api",
        });
        return;
      }
      if (r.status === "not_found" || r.status === "error") {
        await notifyPending(deposit.id);
        return; // worker retries until expiry
      }
    }
    // API mode selected but adapter unavailable -> escalate to a human instead of faking anything.
    await markNeedsReview(deposit.id, "API verification unavailable for this provider");
    return;
  }

  // 3) Manual review mode: a human confirms in the admin panel.
  await markNeedsReview(deposit.id, "Manual review required");
}

async function markNeedsReview(depositId: string, reason: string) {
  const d = await prisma.deposit.update({
    where: { id: depositId },
    data: { needsReview: true },
    include: { provider: true },
  });
  await prisma.paymentEvent.create({ data: { depositId, source: "system", kind: "needs_review", payload: { reason } } });
  await notifyPending(depositId);
  await notifyAdmins(
    `Deposit needs review: ${d.invoiceNo} • ${d.provider.displayName} • ${d.amount} • trx ${d.providerTrxId}`,
    "/admin/deposits"
  );
}

async function notifyPending(depositId: string) {
  const d = await prisma.deposit.findUnique({ where: { id: depositId } });
  if (!d) return;
  // Avoid spamming: one "pending" notification per deposit.
  const exists = await prisma.notification.findFirst({
    where: { userId: d.userId, type: "PAYMENT", deepLink: `/wallet/deposits/${d.id}`, title: "Deposit pending" },
  });
  if (exists) return;
  await notifyUser(
    d.userId,
    "PAYMENT",
    "Deposit pending",
    `We received your transaction ID for invoice ${d.invoiceNo}. Your balance is updated only after verification.`,
    `/wallet/deposits/${d.id}`
  );
}

/**
 * The ONLY place a deposit becomes SUCCESSFUL and the wallet is credited.
 * Atomic + idempotent: deposit row is locked, ledger entry is unique per deposit.
 */
export async function finalizeDeposit(depositId: string, trx: VerifiedTrx, adminId?: string) {
  const outcome = await prisma.$transaction(async (tx) => {
    const rows = await tx.$queryRaw<{ id: string }[]>`SELECT id FROM "Deposit" WHERE id = ${depositId} FOR UPDATE`;
    if (rows.length === 0) return { result: "missing" as const };
    const dep = await tx.deposit.findUniqueOrThrow({ where: { id: depositId }, include: { provider: true } });
    if (dep.status === "SUCCESSFUL") return { result: "already" as const };
    if (dep.status !== "PENDING") return { result: "not_pending" as const };

    const paid = new Prisma.Decimal(trx.amount);
    if (!paid.equals(dep.amount)) {
      await tx.deposit.update({ where: { id: dep.id }, data: { needsReview: true } });
      await tx.paymentEvent.create({
        data: {
          depositId: dep.id,
          source: trx.source,
          kind: "amount_mismatch",
          payload: { expected: dep.amount.toString(), got: trx.amount },
        },
      });
      return { result: "mismatch" as const, dep };
    }
    if (dep.providerTrxId && dep.providerTrxId !== trx.providerTrxId) {
      return { result: "trx_mismatch" as const };
    }
    if (trx.receiverNumber && dep.provider.receiverNumber && trx.receiverNumber !== dep.provider.receiverNumber) {
      await tx.deposit.update({ where: { id: dep.id }, data: { needsReview: true } });
      return { result: "receiver_mismatch" as const, dep };
    }

    const existing = await tx.transaction.findUnique({
      where: { providerCode_providerTrxId: { providerCode: dep.provider.code, providerTrxId: trx.providerTrxId } },
    });
    if (existing && existing.depositId && existing.depositId !== dep.id) {
      return { result: "duplicate" as const };
    }
    if (existing) {
      await tx.transaction.update({ where: { id: existing.id }, data: { depositId: dep.id } });
    } else {
      await tx.transaction.create({
        data: {
          depositId: dep.id,
          providerCode: dep.provider.code,
          providerTrxId: trx.providerTrxId,
          amount: paid,
          senderNumber: trx.senderNumber,
          receiverNumber: trx.receiverNumber,
          rawPayload: (trx.raw ?? undefined) as any,
          environment: config.paymentEnv,
        },
      });
    }

    await postEntry(tx, {
      userId: dep.userId,
      type: "DEPOSIT",
      direction: "CREDIT",
      amount: dep.amount,
      refType: "deposit",
      refId: dep.id,
      note: `${dep.provider.displayName} ${trx.providerTrxId}`,
    });
    await tx.deposit.update({
      where: { id: dep.id },
      data: { status: "SUCCESSFUL", verifiedAt: new Date(), needsReview: false, reviewedBy: adminId },
    });
    await tx.paymentEvent.create({
      data: { depositId: dep.id, source: trx.source, kind: "credited", payload: { trxId: trx.providerTrxId, adminId } },
    });
    return { result: "credited" as const, dep };
  });

  if (outcome.result === "credited") {
    await notifyUser(
      outcome.dep.userId,
      "PAYMENT",
      "Deposit verified",
      `${outcome.dep.amount} has been added to your wallet (invoice ${outcome.dep.invoiceNo}).`,
      `/wallet/deposits/${outcome.dep.id}`
    );
  } else if (outcome.result === "mismatch" || outcome.result === "receiver_mismatch") {
    await notifyAdmins(
      `Suspicious deposit ${outcome.dep.invoiceNo}: provider data does not match invoice. Review required.`,
      "/admin/deposits"
    );
  } else if (outcome.result === "duplicate") {
    await notifyAdmins(`Duplicate transaction reference blocked for deposit ${depositId}.`, "/admin/deposits");
  }
  return outcome.result;
}

export async function rejectDeposit(depositId: string, adminId: string, reason: string) {
  const dep = await prisma.deposit.findUnique({ where: { id: depositId } });
  if (!dep || dep.status !== "PENDING") throw new UserError("Deposit is not pending");
  await prisma.deposit.update({
    where: { id: depositId },
    data: { status: "REJECTED", failureReason: reason, reviewedBy: adminId, needsReview: false },
  });
  await prisma.paymentEvent.create({ data: { depositId, source: "admin", kind: "rejected", payload: { reason, adminId } } });
  await notifyUser(
    dep.userId,
    "PAYMENT",
    "Deposit rejected",
    `Invoice ${dep.invoiceNo} could not be verified: ${reason}`,
    `/wallet/deposits/${dep.id}`
  );
}

/** Expires stale invoices and retries API verification. Run from the worker on an interval. */
export async function runDepositMaintenance() {
  const stale = await prisma.deposit.findMany({
    where: { status: "PENDING", expiresAt: { lt: new Date() }, needsReview: false },
    take: 200,
  });
  for (const d of stale) {
    const upd = await prisma.deposit.updateMany({ where: { id: d.id, status: "PENDING" }, data: { status: "EXPIRED" } });
    if (upd.count) {
      await notifyUser(d.userId, "PAYMENT", "Deposit expired", `Invoice ${d.invoiceNo} expired without a verified payment.`, `/wallet/deposits/${d.id}`);
    }
  }
  const retry = await prisma.deposit.findMany({
    where: { status: "PENDING", providerTrxId: { not: null }, needsReview: false, provider: { verificationMode: "API" } },
    take: 100,
  });
  for (const d of retry) await attemptVerification(d.id).catch((e) => console.error("retry verify failed", e));
}
