import { prisma } from "../db";
import { config } from "../config";
import { loadKey, seal, open, maskSecret } from "../lib/secretbox";

/**
 * Credential resolver for integrations.
 *  - Secrets: AES-256-GCM sealed in the database (needs SECRETS_ENCRYPTION_KEY) OR plain server env vars.
 *  - Non-secret settings: IntegrationConfig.settings OR env vars.
 * Sandbox and production credentials are stored under separate names ("<mode>.<NAME>") and never mixed.
 * Environment variables are treated as belonging to the server's active PAYMENT_ENV only.
 * Secret values are NEVER returned to API clients: only a masked status is.
 */
export type Mode = "sandbox" | "production";

export type KeyState = "ok" | "missing" | "invalid";

export function secretsKeyState(): KeyState {
  const raw = process.env.SECRETS_ENCRYPTION_KEY;
  if (!raw) return "missing";
  try {
    loadKey(raw);
    return "ok";
  } catch {
    return "invalid";
  }
}

function masterKey(): Buffer | null {
  return secretsKeyState() === "ok" ? loadKey(process.env.SECRETS_ENCRYPTION_KEY) : null;
}

const envName = (code: string, name: string) => `${code.toUpperCase()}_${name}`;
const slot = (mode: Mode, name: string) => `${mode}.${name}`;
const aad = (code: string, mode: Mode, name: string) => `${code}:${slot(mode, name)}`;

export async function getSecret(code: string, name: string, mode: Mode = config.paymentEnv): Promise<string | undefined> {
  const key = masterKey();
  if (key) {
    const row = await prisma.integrationSecret.findUnique({ where: { code_name: { code, name: slot(mode, name) } } });
    if (row) {
      try {
        return open({ ciphertext: row.ciphertext, iv: row.iv, tag: row.tag }, key, aad(code, mode, name));
      } catch {
        return undefined; // wrong master key or tampered row: treat as missing, never crash verification
      }
    }
  }
  if (mode === config.paymentEnv) return process.env[envName(code, name)] || undefined;
  return undefined;
}

export async function setSecret(code: string, name: string, mode: Mode, value: string, adminId?: string) {
  const key = masterKey();
  if (!key) {
    throw new Error(
      "SECRETS_ENCRYPTION_KEY is missing or invalid on the server, so credentials cannot be stored from the admin panel. " +
        "Generate one with `openssl rand -base64 32`, or provide the credential as an environment variable instead."
    );
  }
  if (!value || value.length > 8000) throw new Error("Invalid secret value");
  const sealed = seal(value, key, aad(code, mode, name));
  await prisma.integrationSecret.upsert({
    where: { code_name: { code, name: slot(mode, name) } },
    update: { ...sealed, updatedBy: adminId },
    create: { code, name: slot(mode, name), ...sealed, updatedBy: adminId },
  });
}

export async function deleteSecret(code: string, name: string, mode: Mode) {
  await prisma.integrationSecret.deleteMany({ where: { code, name: slot(mode, name) } });
}

export interface SecretStatus {
  name: string;
  set: boolean;
  source: "database" | "environment" | null;
  masked: string;
}

export async function secretStatus(code: string, name: string, mode: Mode): Promise<SecretStatus> {
  if (masterKey()) {
    const row = await prisma.integrationSecret.findUnique({ where: { code_name: { code, name: slot(mode, name) } } });
    if (row) return { name, set: true, source: "database", masked: maskSecret("x") };
  }
  if (mode === config.paymentEnv && process.env[envName(code, name)]) {
    return { name, set: true, source: "environment", masked: maskSecret("x") };
  }
  return { name, set: false, source: null, masked: "" };
}

/** Non-secret setting: IntegrationConfig.settings first, then env var. */
export async function getSetting(code: string, name: string): Promise<string | undefined> {
  const cfg = await prisma.integrationConfig.findUnique({ where: { code } });
  const v = (cfg?.settings as Record<string, unknown> | null)?.[name];
  if (typeof v === "string" && v) return v;
  return process.env[envName(code, name)] || undefined;
}
