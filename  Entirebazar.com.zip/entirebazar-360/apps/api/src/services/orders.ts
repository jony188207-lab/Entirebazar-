import crypto from "crypto";
import { Prisma } from "@prisma/client";
import { prisma } from "../db";
import { postEntry, InsufficientFunds } from "./ledger";
import { notifyUser, notifyAdmins } from "./notify";
import { UserError } from "../lib/errors";
import { canPurchaseProduct, loadIndex, priceOf } from "./catalog";
import { fromMinor, lineTotalMinor } from "../lib/pricing";
import { hasMarkup } from "../lib/validate";

function newOrderNo() {
  return "OD" + Date.now().toString(36).toUpperCase() + crypto.randomBytes(2).toString("hex").toUpperCase();
}

export interface CheckoutItem {
  productId: string;
  variantId?: string;
  quantity: number;
  /** Buyer-supplied data when the product has an inputLabel (e.g. a player ID). */
  input?: string;
}

/**
 * Prices, availability and stock are all decided here, inside one DB transaction, from the database.
 * Nothing the client sends (price, discount, status) is trusted; configured buttons can only navigate
 * to the product page and never reach this function directly.
 */
export async function checkout(userId: string, items: CheckoutItem[], clientRef?: string) {
  const user = await prisma.user.findUniqueOrThrow({ where: { id: userId } });
  if (user.status !== "ACTIVE") throw new UserError("Your account cannot place orders", 403);
  if (items.length === 0 || items.length > 20) throw new UserError("Invalid cart");

  if (clientRef) {
    const existing = await prisma.order.findUnique({
      where: { userId_clientRef: { userId, clientRef } },
      include: { items: { include: { product: true } } },
    });
    if (existing) return existing; // idempotent retry
  }

  const idx = await loadIndex();

  let order;
  try {
    order = await prisma.$transaction(async (tx) => {
      let totalMinor = 0;
      type Line = {
        productId: string; productName: string; variantId: string | null; variantName: string | null; quantity: number;
        unit: string; deliveryType: string; fileUrl: string | null; input: string | null;
      };
      const lines: Line[] = [];

      for (const it of items) {
        if (!Number.isInteger(it.quantity) || it.quantity < 1 || it.quantity > 10) throw new UserError("Invalid quantity");
        const p = await tx.product.findUnique({
          where: { id: it.productId },
          include: { categories: true, variants: { where: { status: "PUBLISHED" }, orderBy: { sortOrder: "asc" } } },
        });
        if (!p || !canPurchaseProduct(p, idx)) throw new UserError("A product is unavailable");

        let variant = null as (typeof p.variants)[number] | null;
        if (p.variants.length > 0) {
          if (!it.variantId) throw new UserError(`Please choose an option for ${p.name}`);
          variant = p.variants.find((v) => v.id === it.variantId) ?? null;
          if (!variant) throw new UserError("The selected option is unavailable");
        } else if (it.variantId) {
          throw new UserError("The selected option is unavailable");
        }

        let input: string | null = null;
        if (p.inputLabel) {
          input = (it.input ?? "").trim();
          if (input.length < 1) throw new UserError(`${p.inputLabel} is required`);
          if (input.length > 200 || hasMarkup(input)) throw new UserError(`${p.inputLabel} is invalid`);
        } else if (it.input) {
          throw new UserError("This product does not accept extra input");
        }

        const eff = priceOf(p, variant, idx);
        totalMinor += lineTotalMinor(eff.final, it.quantity);
        lines.push({
          productId: p.id, productName: p.name, variantId: variant?.id ?? null, variantName: variant?.name ?? null,
          quantity: it.quantity, unit: eff.final, deliveryType: p.deliveryType, fileUrl: p.deliveryFileUrl, input,
        });
      }

      const total = new Prisma.Decimal(fromMinor(totalMinor));
      const created = await tx.order.create({
        data: { orderNo: newOrderNo(), userId, total, status: "PAID", clientRef: clientRef ?? null },
      });

      // Debit first: fails atomically (and rolls everything back) if the balance is insufficient.
      await postEntry(tx, {
        userId, type: "PURCHASE", direction: "DEBIT", amount: total, refType: "order", refId: created.id, note: `Order ${created.orderNo}`,
      });

      let allDelivered = true;
      for (const ln of lines) {
        let delivered: string | null = null;
        let keyIds: string[] = [];

        if (ln.deliveryType === "TEXT_KEYS") {
          const keys = ln.variantId
            ? await tx.$queryRaw<{ id: string; secret: string }[]>`
                SELECT id, secret FROM "ProductKey"
                WHERE "productId" = ${ln.productId} AND "variantId" = ${ln.variantId} AND "usedAt" IS NULL
                ORDER BY "createdAt" LIMIT ${ln.quantity} FOR UPDATE SKIP LOCKED`
            : await tx.$queryRaw<{ id: string; secret: string }[]>`
                SELECT id, secret FROM "ProductKey"
                WHERE "productId" = ${ln.productId} AND "variantId" IS NULL AND "usedAt" IS NULL
                ORDER BY "createdAt" LIMIT ${ln.quantity} FOR UPDATE SKIP LOCKED`;
          if (keys.length < ln.quantity) throw new UserError(`${ln.productName} is out of stock`);
          delivered = keys.map((k) => k.secret).join("\n");
          keyIds = keys.map((k) => k.id);
          await tx.productKey.updateMany({ where: { id: { in: keyIds } }, data: { usedAt: new Date() } });
        } else {
          // Non-key products: atomic, guarded stock decrement (null stock = unlimited).
          const ok = ln.variantId
            ? await tx.productVariant.updateMany({
                where: { id: ln.variantId, OR: [{ stock: null }, { stock: { gte: ln.quantity } }] },
                data: { stock: { decrement: ln.quantity } },
              })
            : await tx.product.updateMany({
                where: { id: ln.productId, OR: [{ stock: null }, { stock: { gte: ln.quantity } }] },
                data: { stock: { decrement: ln.quantity } },
              });
          if (ok.count === 0) throw new UserError(`${ln.productName} is out of stock`);
          if (ln.deliveryType === "FILE_URL") delivered = ln.fileUrl;
          else allDelivered = false; // MANUAL: an admin fulfils it (see Orders → Fulfil)
        }

        const item = await tx.orderItem.create({
          data: {
            orderId: created.id, productId: ln.productId, productName: ln.productName, variantId: ln.variantId, variantName: ln.variantName,
            customerInput: ln.input, quantity: ln.quantity, unitPrice: new Prisma.Decimal(ln.unit),
            deliveredData: delivered, deliveredAt: delivered ? new Date() : null,
          },
        });
        if (keyIds.length) await tx.productKey.updateMany({ where: { id: { in: keyIds } }, data: { orderItemId: item.id } });
        await tx.product.update({ where: { id: ln.productId }, data: { salesCount: { increment: ln.quantity } } });
      }

      return tx.order.update({
        where: { id: created.id },
        data: { status: allDelivered ? "DELIVERED" : "PROCESSING" },
        include: { items: { include: { product: true } } },
      });
    });
  } catch (e: any) {
    if (e instanceof InsufficientFunds) throw new UserError("Insufficient wallet balance");
    // Two concurrent submits with the same clientRef: the loser returns the winner's order.
    if (e?.code === "P2002" && clientRef) {
      const existing = await prisma.order.findUnique({ where: { userId_clientRef: { userId, clientRef } }, include: { items: { include: { product: true } } } });
      if (existing) return existing;
    }
    throw e;
  }

  await notifyUser(userId, "ORDER", "Order confirmed", `Order ${order.orderNo} for ${order.total} was placed.`, `/orders/${order.id}`);
  if (order.status === "DELIVERED") {
    await notifyUser(userId, "DELIVERY", "Product delivered", `Your items for order ${order.orderNo} are ready.`, `/orders/${order.id}`);
  } else {
    await notifyUser(userId, "ORDER", "Order is being prepared", `Order ${order.orderNo} needs manual fulfilment. We'll notify you when it's delivered.`, `/orders/${order.id}`);
  }
  await notifyAdmins(`New order ${order.orderNo} • ${order.total} • ${order.status}`, `/admin/orders`);
  return order;
}

/** Refund the full order total to the wallet exactly once (ledger-idempotent). */
export async function refundOrder(orderId: string, adminId: string) {
  const result = await prisma.$transaction(async (tx) => {
    await tx.$queryRaw`SELECT id FROM "Order" WHERE id = ${orderId} FOR UPDATE`;
    const order = await tx.order.findUnique({ where: { id: orderId } });
    if (!order) throw new UserError("Order not found", 404);
    if (order.status === "REFUNDED") throw new UserError("Already refunded");
    if (!["PAID", "PROCESSING", "DELIVERED"].includes(order.status)) throw new UserError("This order cannot be refunded");
    await postEntry(tx, {
      userId: order.userId, type: "REFUND", direction: "CREDIT", amount: order.total,
      refType: "refund", refId: order.id, note: `Refund ${order.orderNo} (by admin ${adminId})`,
    });
    return tx.order.update({ where: { id: orderId }, data: { status: "REFUNDED", refundStatus: "COMPLETED" } });
  });
  await notifyUser(result.userId, "REFUND", "Refund completed", `${result.total} was returned to your wallet for order ${result.orderNo}.`, `/orders/${result.id}`);
  return result;
}
