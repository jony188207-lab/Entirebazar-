import { Category, Prisma } from "@prisma/client";
import { prisma } from "../db";
import { DiscountInput, effectivePrice } from "../lib/pricing";
import { LIMITS } from "../lib/limits";

/* ============================================================
 * Category tree
 * A category is "live" only if it AND every ancestor are PUBLISHED and inside their schedule.
 * ============================================================ */
export interface CategoryIndex {
  all: Map<string, Category>;
  live: Map<string, Category>;
  children: Map<string | null, Category[]>;
  now: Date;
}

export async function loadIndex(now = new Date()): Promise<CategoryIndex> {
  const rows = await prisma.category.findMany({ orderBy: [{ sortOrder: "asc" }, { name: "asc" }] });
  return buildIndex(rows, now);
}

export function buildIndex(rows: Category[], now = new Date()): CategoryIndex {
  const all = new Map(rows.map((r) => [r.id, r]));
  const children = new Map<string | null, Category[]>();
  for (const r of rows) {
    const k = r.parentId ?? null;
    if (!children.has(k)) children.set(k, []);
    children.get(k)!.push(r);
  }
  const memo = new Map<string, boolean>();
  const isLive = (c: Category, depth = 0): boolean => {
    const hit = memo.get(c.id);
    if (hit !== undefined) return hit;
    let ok = c.status === "PUBLISHED" && (!c.publishAt || c.publishAt <= now) && (!c.unpublishAt || c.unpublishAt > now);
    if (ok && c.parentId) {
      const p = all.get(c.parentId);
      ok = !!p && depth < 12 && isLive(p, depth + 1);
    }
    memo.set(c.id, ok);
    return ok;
  };
  const live = new Map<string, Category>();
  for (const r of rows) if (isLive(r)) live.set(r.id, r);
  return { all, live, children, now };
}

export function depthOf(idx: CategoryIndex, id: string): number {
  let d = 0;
  let cur = idx.all.get(id);
  while (cur && d < 20) {
    d++;
    cur = cur.parentId ? idx.all.get(cur.parentId) : undefined;
  }
  return d;
}

export function ancestorsOf(idx: CategoryIndex, c: Category): Category[] {
  const out: Category[] = [];
  let cur = c.parentId ? idx.all.get(c.parentId) : undefined;
  while (cur && out.length < 20) {
    out.unshift(cur);
    cur = cur.parentId ? idx.all.get(cur.parentId) : undefined;
  }
  return out;
}

/** The category plus all descendants (optionally only the live ones). */
export function subtreeIds(idx: CategoryIndex, rootId: string, onlyLive = true): string[] {
  const out: string[] = [];
  const stack = [rootId];
  while (stack.length && out.length < LIMITS.maxCategories) {
    const id = stack.pop()!;
    const c = idx.all.get(id);
    if (!c || (onlyLive && !idx.live.has(id))) continue;
    out.push(id);
    for (const ch of idx.children.get(id) ?? []) stack.push(ch.id);
  }
  return out;
}

export function isDescendant(idx: CategoryIndex, maybeChildId: string, ancestorId: string): boolean {
  return subtreeIds(idx, ancestorId, false).includes(maybeChildId);
}

/* ============================================================
 * Products: visibility, stock and price
 * ============================================================ */
export const productInclude = {
  categories: {
    include: {
      category: { select: { id: true, name: true, slug: true } },
    },
  },
  variants: { where: { status: "PUBLISHED" as const }, orderBy: { sortOrder: "asc" as const } },
} satisfies Prisma.ProductInclude;
export type ProductFull = Prisma.ProductGetPayload<{ include: typeof productInclude }>;

/**
 * A product is shown if it is PUBLISHED and either has no category assignment or belongs to at least one live category.
 * Unpublishing/archiving a category therefore hides products that live only there.
 */
export function visibleProductWhere(idx: CategoryIndex): Prisma.ProductWhereInput {
  return {
    status: "PUBLISHED",
    OR: [{ categories: { none: {} } }, { categories: { some: { categoryId: { in: [...idx.live.keys()] } } } }],
  };
}

/** Stricter than visible: at least one live category must also be purchasable (or no categories at all). */
export function canPurchaseProduct(p: { status: string; categories: { categoryId: string }[] }, idx: CategoryIndex): boolean {
  if (p.status !== "PUBLISHED") return false;
  if (p.categories.length === 0) return true;
  return p.categories.some((c) => {
    const cat = idx.live.get(c.categoryId);
    return !!cat && cat.purchasable;
  });
}

export async function loadKeyStock(productIds: string[]): Promise<Map<string, number>> {
  if (productIds.length === 0) return new Map();
  const rows = await prisma.productKey.groupBy({
    by: ["productId", "variantId"],
    where: { productId: { in: productIds }, usedAt: null },
    _count: { _all: true },
  });
  return new Map(rows.map((r) => [`${r.productId}:${r.variantId ?? ""}`, r._count._all]));
}

export function stockOf(
  p: { id: string; deliveryType: string; stock: number | null },
  variant: { id: string; stock: number | null } | null,
  keyStock: Map<string, number>
): number | null {
  if (p.deliveryType === "TEXT_KEYS") return keyStock.get(`${p.id}:${variant?.id ?? ""}`) ?? 0;
  return variant ? variant.stock : p.stock;
}

type Discountable = {
  discountType: "NONE" | "PERCENT" | "FIXED";
  discountValue: Prisma.Decimal | null;
  discountStartsAt: Date | null;
  discountEndsAt: Date | null;
  categories: { categoryId: string }[];
};

export function productDiscounts(p: Discountable, idx: CategoryIndex): DiscountInput[] {
  const list: DiscountInput[] = [
    { type: p.discountType, value: p.discountValue ? p.discountValue.toString() : null, startsAt: p.discountStartsAt, endsAt: p.discountEndsAt, source: "PRODUCT" },
  ];
  for (const pc of p.categories) {
    const c = idx.live.get(pc.categoryId);
    if (c?.discountPercent) {
      list.push({ type: "PERCENT", value: c.discountPercent.toString(), startsAt: c.discountStartsAt, endsAt: c.discountEndsAt, source: "CATEGORY" });
    }
  }
  return list;
}

export function priceOf(
  p: Discountable & { price: Prisma.Decimal },
  variant: { price: Prisma.Decimal | null } | null,
  idx: CategoryIndex
) {
  const base = variant?.price ?? p.price;
  return effectivePrice(base.toString(), productDiscounts(p, idx), idx.now);
}

export function presentProduct(p: ProductFull, idx: CategoryIndex, keyStock: Map<string, number>, rating?: { avg: number; count: number }) {
  const variants = p.variants.map((v) => {
    const eff = priceOf(p, v, idx);
    const stock = stockOf(p, v, keyStock);
    return { id: v.id, name: v.name, price: eff.final, originalPrice: eff.base, discounted: eff.discounted, stock, inStock: stock === null || stock > 0 };
  });
  const eff = priceOf(p, null, idx);
  let stock: number | null;
  let inStock: boolean;
  if (variants.length) {
    stock = variants.some((v) => v.stock === null) ? null : variants.reduce((a, v) => a + (v.stock ?? 0), 0);
    inStock = variants.some((v) => v.inStock);
  } else {
    stock = stockOf(p, null, keyStock);
    inStock = stock === null || stock > 0;
  }
  const minVariant = variants.length ? variants.reduce((m, v) => (Number(v.price) < Number(m.price) ? v : m)) : null;
  return {
    id: p.id,
    name: p.name,
    description: p.description,
    features: p.features,
    imageUrl: p.imageUrl,
    productType: p.productType,
    cardLayout: p.cardLayout,
    featured: p.featured,
    price: minVariant ? minVariant.price : eff.final,
    originalPrice: minVariant ? minVariant.originalPrice : eff.base,
    hasVariants: variants.length > 0,
    discounted: minVariant ? minVariant.discounted : eff.discounted,
    percentOff: eff.percentOff,
    discountEndsAt: eff.discounted ? (p.discountEndsAt ?? null) : null,
    stock,
    inStock,
    inputLabel: p.inputLabel,
    deliveryInstructions: p.deliveryInstructions,
    categories: p.categories.filter((c) => idx.live.has(c.categoryId)).map((c) => c.category),
    variants,
    rating: rating?.avg ?? 0,
    reviewCount: rating?.count ?? 0,
  };
}
export type PublicProduct = ReturnType<typeof presentProduct>;

export async function ratingsFor(ids: string[]) {
  if (ids.length === 0) return new Map<string, { avg: number; count: number }>();
  const rows = await prisma.review.groupBy({ by: ["productId"], where: { productId: { in: ids } }, _avg: { rating: true }, _count: true });
  return new Map(rows.map((r) => [r.productId, { avg: r._avg.rating ?? 0, count: r._count }]));
}

/** Load + present a list of products with prices, stock and ratings. */
export async function presentMany(where: Prisma.ProductWhereInput, idx: CategoryIndex, opts: { orderBy?: Prisma.ProductOrderByWithRelationInput | Prisma.ProductOrderByWithRelationInput[]; take?: number; skip?: number; ids?: string[] } = {}) {
  const rows = await prisma.product.findMany({ where, include: productInclude, orderBy: opts.orderBy, take: opts.take, skip: opts.skip });
  const [keyStock, rt] = await Promise.all([loadKeyStock(rows.map((r) => r.id)), ratingsFor(rows.map((r) => r.id))]);
  let out = rows.map((r) => presentProduct(r, idx, keyStock, rt.get(r.id)));
  if (opts.ids) {
    const order = new Map(opts.ids.map((id, i) => [id, i]));
    out = out.sort((a, b) => (order.get(a.id) ?? 1e9) - (order.get(b.id) ?? 1e9));
  }
  return out;
}

export function sortToOrderBy(sort: string | undefined): Prisma.ProductOrderByWithRelationInput {
  switch (sort) {
    case "POPULAR": case "popular": return { salesCount: "desc" };
    case "PRICE_ASC": case "price_asc": return { price: "asc" };
    case "PRICE_DESC": case "price_desc": return { price: "desc" };
    case "NAME": return { name: "asc" };
    default: return { createdAt: "desc" };
  }
}
