import { prisma } from "../db";
import { DEFAULT_GENERAL_SETTINGS, GeneralSettings, generalSettingsSchema } from "../lib/layoutSchema";

let cache: { at: number; value: GeneralSettings } | null = null;
const TTL_MS = 5_000;

/** General settings live in AppSetting("general") as JSON; the legacy "maintenance" key is honoured as a fallback. */
export async function getGeneralSettings(force = false): Promise<GeneralSettings> {
  if (!force && cache && Date.now() - cache.at < TTL_MS) return cache.value;
  const [row, legacy] = await Promise.all([
    prisma.appSetting.findUnique({ where: { key: "general" } }),
    prisma.appSetting.findUnique({ where: { key: "maintenance" } }),
  ]);
  let value = DEFAULT_GENERAL_SETTINGS;
  if (row) {
    try {
      const parsed = generalSettingsSchema.safeParse(JSON.parse(row.value));
      if (parsed.success) value = parsed.data;
    } catch {
      /* fall through to defaults */
    }
  } else if (legacy?.value === "true") {
    value = { ...DEFAULT_GENERAL_SETTINGS, maintenance: true };
  }
  cache = { at: Date.now(), value };
  return value;
}

export async function saveGeneralSettings(s: GeneralSettings) {
  await prisma.$transaction([
    prisma.appSetting.upsert({ where: { key: "general" }, update: { value: JSON.stringify(s) }, create: { key: "general", value: JSON.stringify(s) } }),
    prisma.appSetting.upsert({ where: { key: "maintenance" }, update: { value: String(s.maintenance) }, create: { key: "maintenance", value: String(s.maintenance) } }),
  ]);
  cache = null;
}

/** Only fields that are safe to show every visitor. */
export function publicSettings(s: GeneralSettings) {
  return {
    maintenance: s.maintenance,
    maintenanceMessage: s.maintenanceMessage,
    contact: s.contact,
    homeLayout: s.homeLayout,
  };
}
