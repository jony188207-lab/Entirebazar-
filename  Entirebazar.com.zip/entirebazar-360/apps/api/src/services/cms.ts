import { prisma } from "../db";
import { UserError } from "../lib/errors";
import { LIMITS } from "../lib/limits";
import { slugify, validateExternalUrl, telegramBotLink } from "../lib/validate";
import { ButtonAction, buttonInput } from "../lib/layoutSchema";
import { z } from "zod";

type ButtonData = z.output<typeof buttonInput>;

/** Slug that is unique among categories ("name", "name-2", ...). */
export async function uniqueCategorySlug(base: string, ignoreId?: string): Promise<string> {
  const root = slugify(base) || "category";
  for (let i = 1; i < 200; i++) {
    const cand = i === 1 ? root : `${root}-${i}`.slice(0, 60);
    const hit = await prisma.category.findUnique({ where: { slug: cand }, select: { id: true } });
    if (!hit || hit.id === ignoreId) return cand;
  }
  throw new UserError("Could not generate a unique slug; choose one manually");
}

/**
 * Semantic validation of a button's destination, run on every save (and again when rendered).
 * Shape validation already happened in buttonInput; this checks the destination exists and is permitted.
 * Returns the (possibly canonicalised) target to store. Buttons only ever NAVIGATE: purchases, wallet and
 * order pages are authenticated server routes that enforce their own checks.
 */
export async function validateButtonTarget(action: ButtonAction, target: Record<string, any>, allowedHosts: string[]): Promise<Record<string, unknown>> {
  switch (action) {
    case "OPEN_CATEGORY": {
      const c = await prisma.category.findUnique({ where: { id: target.categoryId }, select: { status: true } });
      if (!c) throw new UserError("The selected category no longer exists");
      if (c.status === "ARCHIVED") throw new UserError("The selected category is archived");
      return target;
    }
    case "OPEN_PRODUCT": {
      const p = await prisma.product.findUnique({ where: { id: target.productId }, select: { status: true } });
      if (!p) throw new UserError("The selected product no longer exists");
      if (p.status === "ARCHIVED") throw new UserError("The selected product is archived");
      return target;
    }
    case "START_PURCHASE": {
      const p = await prisma.product.findUnique({ where: { id: target.productId }, select: { status: true, variants: { select: { id: true } } } });
      if (!p) throw new UserError("The selected product no longer exists");
      if (p.status === "ARCHIVED") throw new UserError("The selected product is archived");
      if (target.variantId && !p.variants.some((v) => v.id === target.variantId)) throw new UserError("The selected variant does not belong to this product");
      return target;
    }
    case "OPEN_PRODUCT_LIST":
    case "OPEN_FAQ": {
      if (target.categoryId) {
        const c = await prisma.category.findUnique({ where: { id: target.categoryId }, select: { id: true } });
        if (!c) throw new UserError("The selected category no longer exists");
      }
      return target;
    }
    case "OPEN_EXTERNAL": {
      const r = validateExternalUrl(String(target.url ?? ""), allowedHosts);
      if (!r.ok) throw new UserError(r.reason);
      return { url: r.url };
    }
    case "OPEN_TELEGRAM_BOT": {
      const r = telegramBotLink(String(target.username), target.startParam ? String(target.startParam) : undefined);
      if (!r.ok) throw new UserError(r.reason);
      return target;
    }
    default:
      return target;
  }
}

/** Confirms the owner row exists and the owner has room for another button. */
export async function assertButtonOwner(b: Pick<ButtonData, "categoryId" | "sectionId" | "productId" | "noticeId">, ignoreButtonId?: string) {
  const [key, value] = (Object.entries({ categoryId: b.categoryId, sectionId: b.sectionId, productId: b.productId, noticeId: b.noticeId }).find(([, v]) => !!v) ?? []) as [string, string];
  const exists =
    key === "categoryId" ? await prisma.category.findUnique({ where: { id: value }, select: { id: true } })
    : key === "sectionId" ? await prisma.categorySection.findUnique({ where: { id: value }, select: { id: true } })
    : key === "productId" ? await prisma.product.findUnique({ where: { id: value }, select: { id: true } })
    : await prisma.announcement.findUnique({ where: { id: value }, select: { id: true } });
  if (!exists) throw new UserError("The owner of this button no longer exists", 404);
  const n = await prisma.actionButton.count({ where: { [key]: value, ...(ignoreButtonId ? { id: { not: ignoreButtonId } } : {}) } as any });
  if (n >= LIMITS.maxButtonsPerOwner) throw new UserError(`At most ${LIMITS.maxButtonsPerOwner} buttons are allowed here`);
  return { key, value };
}

/** Manual product / category references inside a section config must point at real rows. */
export async function assertSectionRefs(config: Record<string, any>) {
  const pids: string[] = Array.isArray(config.productIds) ? config.productIds : [];
  if (pids.length) {
    const n = await prisma.product.count({ where: { id: { in: pids } } });
    if (n !== new Set(pids).size) throw new UserError("One or more selected products no longer exist");
  }
  const cids: string[] = Array.isArray(config.categoryIds) ? config.categoryIds : [];
  if (cids.length) {
    const n = await prisma.category.count({ where: { id: { in: cids } } });
    if (n !== new Set(cids).size) throw new UserError("One or more selected categories no longer exist");
  }
}
