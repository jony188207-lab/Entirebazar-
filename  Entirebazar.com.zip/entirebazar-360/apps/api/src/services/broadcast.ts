import { prisma } from "../db";
import { notifyUser } from "./notify";

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/**
 * Sends one broadcast job. Claims the job atomically (startedAt) so it only runs once,
 * throttles to stay under Telegram's ~30 msg/s limit, and records per-user outcomes.
 */
export async function runBroadcast(jobId: string) {
  const claimed = await prisma.broadcastJob.updateMany({
    where: { id: jobId, startedAt: null },
    data: { startedAt: new Date() },
  });
  if (claimed.count === 0) return;
  const job = await prisma.broadcastJob.findUniqueOrThrow({ where: { id: jobId } });

  const users =
    job.audience === "all"
      ? await prisma.user.findMany({ where: { status: { not: "BANNED" } }, select: { id: true } })
      : await prisma.user.findMany({ where: { id: { in: job.userIds }, status: { not: "BANNED" } }, select: { id: true } });

  await prisma.broadcastJob.update({ where: { id: jobId }, data: { total: users.length } });
  let sent = 0, failed = 0, blocked = 0;
  for (const u of users) {
    try {
      // "all" respects the promo opt-out for Telegram push; direct messages always push.
      const n = await notifyUser(u.id, job.audience === "all" ? "ANNOUNCEMENT" : "SYSTEM", job.title, job.body, "/notifications");
      if (n) {
        const fresh = await prisma.notification.findUnique({ where: { id: n.id } });
        if (fresh?.telegram === "SENT") sent++;
        else if (fresh?.telegram === "BLOCKED") blocked++;
        else if (fresh?.telegram === "FAILED") failed++;
      }
    } catch (e) {
      failed++;
      console.error("[broadcast] user failed", e);
    }
    await sleep(40);
  }
  await prisma.broadcastJob.update({ where: { id: jobId }, data: { sent, failed, blocked, finishedAt: new Date() } });
}

export async function runDueBroadcasts() {
  const due = await prisma.broadcastJob.findMany({
    where: { startedAt: null, OR: [{ scheduledAt: null }, { scheduledAt: { lte: new Date() } }] },
    take: 5,
  });
  for (const j of due) await runBroadcast(j.id).catch((e) => console.error("[broadcast] job failed", e));
}
