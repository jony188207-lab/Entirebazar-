import { Prisma, LedgerType, LedgerDirection } from "@prisma/client";

type Tx = Prisma.TransactionClient;

export class InsufficientFunds extends Error {
  constructor() {
    super("Insufficient wallet balance");
  }
}

export interface PostEntryInput {
  userId: string;
  type: LedgerType;
  direction: LedgerDirection;
  amount: Prisma.Decimal | number | string;
  /** (refType, refId, direction) is unique => each business event can affect the wallet once. */
  refType: string;
  refId: string;
  note?: string;
}

/**
 * Posts one ledger entry and updates the cached wallet balance.
 * MUST be called inside prisma.$transaction. Locks the wallet row so concurrent
 * debits/credits are serialised, and is idempotent on (refType, refId, direction).
 */
export async function postEntry(tx: Tx, p: PostEntryInput) {
  const amount = new Prisma.Decimal(p.amount);
  if (!amount.isFinite() || amount.lte(0)) throw new Error("Ledger amount must be positive");

  const rows = await tx.$queryRaw<{ id: string; balance: string }[]>`
    SELECT id, balance::text AS balance FROM "Wallet" WHERE "userId" = ${p.userId} FOR UPDATE`;
  if (rows.length === 0) throw new Error("Wallet not found");
  const wallet = rows[0];

  const existing = await tx.ledgerEntry.findUnique({
    where: { refType_refId_direction: { refType: p.refType, refId: p.refId, direction: p.direction } },
  });
  if (existing) return { entry: existing, duplicate: true };

  const balance = new Prisma.Decimal(wallet.balance);
  const next = p.direction === "CREDIT" ? balance.plus(amount) : balance.minus(amount);
  if (next.lt(0)) throw new InsufficientFunds();

  const entry = await tx.ledgerEntry.create({
    data: {
      walletId: wallet.id,
      type: p.type,
      direction: p.direction,
      amount,
      balanceAfter: next,
      refType: p.refType,
      refId: p.refId,
      note: p.note,
    },
  });
  await tx.wallet.update({ where: { id: wallet.id }, data: { balance: next, version: { increment: 1 } } });
  return { entry, duplicate: false };
}
