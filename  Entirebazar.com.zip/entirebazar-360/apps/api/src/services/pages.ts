import { ActionButton, Announcement, Category, CategorySection, Prisma } from "@prisma/client";
import { prisma } from "../db";
import {
  CategoryIndex, ancestorsOf, loadIndex, presentMany, sortToOrderBy, subtreeIds, visibleProductWhere, PublicProduct,
} from "./catalog";
import { DEFAULT_CATEGORY_SETTINGS, categorySettingsSchema, faqItems, parseButtonTarget, parseSectionConfig, SectionType, visibilityRule } from "../lib/layoutSchema";
import { telegramBotLink, validateExternalUrl } from "../lib/validate";
import { GeneralSettings } from "../lib/layoutSchema";

/* ============================================================
 * Viewer context (who is looking at the page)
 * ============================================================ */
export interface Viewer {
  userId?: string;
  /** lazily computed, memoised per request */
  stats(): Promise<{ orders: number; balance: number }>;
}

export function makeViewer(userId?: string): Viewer {
  let memo: Promise<{ orders: number; balance: number }> | null = null;
  return {
    userId,
    stats() {
      if (!userId) return Promise.resolve({ orders: 0, balance: 0 });
      memo ??= Promise.all([
        prisma.order.count({ where: { userId, status: { in: ["PAID", "PROCESSING", "DELIVERED"] } } }),
        prisma.wallet.findUnique({ where: { userId }, select: { balance: true } }),
      ]).then(([orders, w]) => ({ orders, balance: Number(w?.balance ?? 0) }));
      return memo;
    },
  };
}

/* ============================================================
 * Buttons: validated at save time AND re-validated here on every read
 * ============================================================ */
export type Nav = { kind: "route"; path: string } | { kind: "external"; url: string } | { kind: "telegram"; url: string };

export interface ResolvedButton {
  id: string;
  label: string;
  icon: string | null;
  style: string;
  size: string;
  placement: string;
  nav: Nav;
  confirm: { title: string; message: string } | null;
}

interface ButtonCtx {
  idx: CategoryIndex;
  viewer: Viewer;
  allowedHosts: string[];
}

async function passesVisibility(raw: unknown, viewer: Viewer): Promise<boolean> {
  const r = visibilityRule.safeParse(raw ?? {});
  const rule = r.success ? r.data : { audience: "ALL" as const };
  if (rule.audience === "ALL") return true;
  if (!viewer.userId) return false;
  const s = await viewer.stats();
  switch (rule.audience) {
    case "NEW_USERS": return s.orders === 0;
    case "RETURNING": return s.orders > 0;
    case "LOW_BALANCE": return s.balance < (rule.threshold ?? 100);
    case "HAS_BALANCE": return s.balance >= (rule.threshold ?? 1);
    default: return true;
  }
}

export async function resolveButtons(buttons: ActionButton[], ctx: ButtonCtx): Promise<Map<string, ResolvedButton>> {
  const out = new Map<string, ResolvedButton>();
  const active = buttons.filter((b) => b.enabled);
  if (active.length === 0) return out;

  // Batch-check referenced products once. Only products the shopper may actually see are linkable.
  const productIds = new Set<string>();
  for (const b of active) {
    const t = parseButtonTarget(b.action, b.target) as any;
    if (t && typeof t.productId === "string" && (b.action === "OPEN_PRODUCT" || b.action === "START_PURCHASE")) productIds.add(t.productId);
  }
  const visible = new Map<string, { variantIds: Set<string> }>();
  if (productIds.size) {
    const rows = await prisma.product.findMany({
      where: { AND: [{ id: { in: [...productIds] } }, visibleProductWhere(ctx.idx)] },
      select: { id: true, variants: { where: { status: "PUBLISHED" }, select: { id: true } } },
    });
    for (const r of rows) visible.set(r.id, { variantIds: new Set(r.variants.map((v) => v.id)) });
  }

  for (const b of active.sort((a, c) => a.sortOrder - c.sortOrder)) {
    if (!(await passesVisibility(b.visibility, ctx.viewer))) continue;
    const t = parseButtonTarget(b.action, b.target) as any;
    if (!t) continue; // stored data no longer valid: drop silently
    let nav: Nav | null = null;
    let confirm: ResolvedButton["confirm"] = null;

    switch (b.action) {
      case "OPEN_CATEGORY": {
        const c = ctx.idx.live.get(t.categoryId);
        if (c) nav = { kind: "route", path: `/category/${c.slug}` };
        break;
      }
      case "OPEN_PRODUCT": {
        if (visible.has(t.productId)) nav = { kind: "route", path: `/product/${t.productId}` };
        break;
      }
      case "OPEN_PRODUCT_LIST": {
        const qs = new URLSearchParams();
        if (t.categoryId) {
          const c = ctx.idx.live.get(t.categoryId);
          if (!c) break;
          qs.set("category", c.slug);
        }
        if (t.sort) qs.set("sort", String(t.sort).toLowerCase());
        if (t.featured) qs.set("featured", "true");
        if (t.q) qs.set("q", t.q);
        nav = { kind: "route", path: `/shop${qs.toString() ? `?${qs}` : ""}` };
        break;
      }
      case "OPEN_WALLET": nav = { kind: "route", path: "/wallet" }; break;
      case "OPEN_ORDERS": nav = { kind: "route", path: "/orders" }; break;
      case "OPEN_SUPPORT": nav = { kind: "route", path: "/support" }; break;
      case "OPEN_FAQ": {
        if (t.categoryId) {
          const c = ctx.idx.live.get(t.categoryId);
          if (c) nav = { kind: "route", path: `/category/${c.slug}#faq` };
        } else nav = { kind: "route", path: "/support#faq" };
        break;
      }
      case "START_PURCHASE": {
        // Only navigates to the product page; the purchase itself still requires the user's own
        // confirmation and is authorised, priced and paid server-side.
        const v = visible.get(t.productId);
        if (!v) break;
        if (t.variantId && !v.variantIds.has(t.variantId)) break;
        nav = { kind: "route", path: `/product/${t.productId}?buy=1${t.variantId ? `&variant=${t.variantId}` : ""}` };
        break;
      }
      case "OPEN_EXTERNAL": {
        const c = validateExternalUrl(t.url, ctx.allowedHosts);
        if (!c.ok) break;
        nav = { kind: "external", url: c.url };
        confirm = { title: "Open external link?", message: `You are about to leave the app and open ${new URL(c.url).hostname}.` };
        break;
      }
      case "OPEN_TELEGRAM_BOT": {
        const c = telegramBotLink(t.username, t.startParam);
        if (c.ok) nav = { kind: "telegram", url: c.url };
        break;
      }
    }
    if (!nav) continue;
    if (b.confirmMessage) confirm = { title: b.confirmTitle ?? "Please confirm", message: b.confirmMessage };
    out.set(b.id, { id: b.id, label: b.label, icon: b.icon, style: b.style, size: b.size, placement: b.placement, nav, confirm });
  }
  return out;
}

/* ============================================================
 * Notices
 * ============================================================ */
export interface PublicNotice {
  id: string; title: string; body: string; imageUrl: string | null; icon: string | null;
  type: string; dismissible: boolean; pinned: boolean; buttons: ResolvedButton[];
}

export async function noticesFor(
  location: string,
  ctx: ButtonCtx & { categoryIds?: string[]; productIds?: string[]; limit?: number }
): Promise<PublicNotice[]> {
  const now = ctx.idx.now;
  const rows = await prisma.announcement.findMany({
    where: {
      enabled: true,
      locations: { has: location },
      publishAt: { lte: now },
      OR: [{ expiresAt: null }, { expiresAt: { gt: now } }],
      ...(ctx.viewer.userId ? { dismissals: { none: { userId: ctx.viewer.userId } } } : {}),
    },
    include: { buttons: { where: { enabled: true }, orderBy: { sortOrder: "asc" } } },
    orderBy: [{ pinned: "desc" }, { priority: "desc" }, { publishAt: "desc" }],
    take: 40,
  });
  const cats = new Set(ctx.categoryIds ?? []);
  const prods = new Set(ctx.productIds ?? []);
  const picked = rows
    .filter((n) => n.audience === "ALL" || (n.audience === "CATEGORIES" && n.categoryIds.some((c) => cats.has(c))) || (n.audience === "PRODUCTS" && n.productIds.some((p) => prods.has(p))))
    .slice(0, ctx.limit ?? 10);
  const resolved = await resolveButtons(picked.flatMap((n) => n.buttons), ctx);
  return picked.map((n) => ({
    id: n.id, title: n.title, body: n.body, imageUrl: n.imageUrl, icon: n.icon, type: n.type,
    // Notices that must stay visible are never dismissible, whatever a client claims.
    dismissible: n.dismissible, pinned: n.pinned,
    buttons: n.buttons.map((b) => resolved.get(b.id)).filter((b): b is ResolvedButton => !!b),
  }));
}

/* ============================================================
 * Category cards and pages
 * ============================================================ */
export function categoryCard(c: Category, count?: number) {
  return { id: c.id, name: c.name, slug: c.slug, icon: c.icon, imageUrl: c.imageUrl, description: c.description, productCount: count };
}

async function productCounts(categoryIds: string[]) {
  if (categoryIds.length === 0) return new Map<string, number>();
  const rows = await prisma.productCategory.groupBy({
    by: ["categoryId"],
    where: { categoryId: { in: categoryIds }, product: { status: "PUBLISHED" } },
    _count: { _all: true },
  });
  return new Map(rows.map((r) => [r.categoryId, r._count._all]));
}

/** For previews: treat this category and its descendants as live so their products and children render. */
export function withPreviewLive(idx: CategoryIndex, category: Category): CategoryIndex {
  const live = new Map(idx.live);
  for (const id of subtreeIds(idx, category.id, false)) {
    const c = idx.all.get(id);
    if (c && c.status !== "ARCHIVED") live.set(id, c);
  }
  // ancestors must also be treated as live for breadcrumbs / visibility in the preview only
  for (const a of ancestorsOf(idx, category)) live.set(a.id, a);
  return { ...idx, live };
}

export function readSettings(raw: unknown) {
  const r = categorySettingsSchema.safeParse(raw ?? {});
  return r.success ? r.data : DEFAULT_CATEGORY_SETTINGS;
}

const PAGE_SIZE = 24;
const LIST_CAP = 500;

export interface CategoryQuery {
  q?: string; sort?: string; inStock?: boolean; min?: number; max?: number; type?: string; page?: number;
}

export async function buildCategoryPage(
  category: Category,
  a: { idx: CategoryIndex; viewer: Viewer; general: GeneralSettings; query?: CategoryQuery; preview?: boolean }
) {
  const idx = a.preview ? withPreviewLive(a.idx, category) : a.idx;
  const ctx: ButtonCtx = { idx, viewer: a.viewer, allowedHosts: a.general.allowedExternalHosts };
  const settings = readSettings(category.settings);
  const now = idx.now;
  const treeIds = subtreeIds(idx, category.id, true);
  const q = a.query ?? {};

  /* ----- filterable default product list ----- */
  const allowedSorts: readonly string[] = settings.sorting.options;
  const sort = q.sort && allowedSorts.includes(q.sort.toUpperCase()) ? q.sort.toUpperCase() : settings.sorting.default;
  const and: Prisma.ProductWhereInput[] = [visibleProductWhere(idx), { categories: { some: { categoryId: { in: treeIds } } } }];
  if (q.q && settings.filters.search) and.push({ OR: [{ name: { contains: q.q.slice(0, 60), mode: "insensitive" } }, { description: { contains: q.q.slice(0, 60), mode: "insensitive" } }] });
  if ((q.min !== undefined || q.max !== undefined) && settings.filters.priceRange) and.push({ price: { gte: q.min, lte: q.max } });
  if (q.type && settings.filters.productTypes) and.push({ productType: q.type as any });
  const candidates = settings.layout.showDefaultProductList
    ? await presentMany({ AND: and }, idx, { orderBy: sortToOrderBy(sort), take: LIST_CAP })
    : [];
  let filtered: PublicProduct[] = candidates;
  if (q.inStock && settings.filters.inStock) filtered = filtered.filter((p) => p.inStock);
  if (settings.sorting.pinnedFirst && sort === settings.sorting.default) {
    const pinned = await prisma.productCategory.findMany({ where: { categoryId: category.id, pinned: true }, orderBy: { sortOrder: "asc" }, select: { productId: true } });
    const rank = new Map(pinned.map((p, i) => [p.productId, i]));
    filtered = [...filtered.filter((p) => rank.has(p.id)).sort((x, y) => rank.get(x.id)! - rank.get(y.id)!), ...filtered.filter((p) => !rank.has(p.id))];
  }
  const page = Math.max(1, Math.floor(q.page ?? 1));
  const list = {
    items: filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE),
    total: filtered.length,
    page,
    pages: Math.max(1, Math.ceil(filtered.length / PAGE_SIZE)),
    capped: candidates.length >= LIST_CAP,
  };

  /* ----- children, breadcrumbs ----- */
  const kids = (idx.children.get(category.id) ?? []).filter((c) => idx.live.has(c.id) && c.visibility === "PUBLIC");
  const counts = settings.layout.showProductCount ? await productCounts(kids.map((k) => k.id)) : new Map<string, number>();
  const breadcrumbs = ancestorsOf(idx, category).map((c) => ({ name: c.name, slug: c.slug }));

  /* ----- sections ----- */
  const sectionRows = await prisma.categorySection.findMany({
    where: { categoryId: category.id, enabled: true },
    orderBy: { sortOrder: "asc" },
    include: { buttons: { where: { enabled: true }, orderBy: { sortOrder: "asc" } } },
  });
  const inSchedule = (s: CategorySection) => (!s.startsAt || s.startsAt <= now) && (!s.endsAt || s.endsAt > now);
  const shown = sectionRows.filter((s) => a.preview || inSchedule(s));

  const topButtons = await prisma.actionButton.findMany({ where: { categoryId: category.id, sectionId: null, enabled: true }, orderBy: { sortOrder: "asc" } });
  const resolved = await resolveButtons([...topButtons, ...shown.flatMap((s) => s.buttons)], ctx);
  const pick = (bs: ActionButton[]) => bs.map((b) => resolved.get(b.id)).filter((b): b is ResolvedButton => !!b);

  const sections: unknown[] = [];
  for (const s of shown) {
    const parsed = parseSectionConfig(s.type as SectionType, s.config);
    if (!parsed.success) continue; // corrupt/legacy config never reaches the client
    const cfg: any = parsed.data;
    let data: unknown = null;

    switch (s.type as SectionType) {
      case "PRODUCT_GRID": {
        const scope = cfg.source === "MANUAL" ? { id: { in: cfg.productIds } } : { categories: { some: { categoryId: { in: cfg.source === "SUBTREE" ? treeIds : [category.id] } } } };
        let ids: string[] | undefined;
        if (cfg.source === "MANUAL") ids = cfg.productIds;
        else if (cfg.sort === "MANUAL") {
          const pcs = await prisma.productCategory.findMany({ where: { categoryId: category.id }, orderBy: [{ pinned: "desc" }, { sortOrder: "asc" }], select: { productId: true } });
          ids = pcs.map((p) => p.productId);
        }
        data = await presentMany({ AND: [visibleProductWhere(idx), scope] }, idx, { orderBy: sortToOrderBy(cfg.sort === "MANUAL" ? undefined : cfg.sort), take: cfg.limit, ids });
        break;
      }
      case "FEATURED_PRODUCTS": {
        const scope = cfg.source === "MANUAL" ? { id: { in: cfg.productIds } } : { featured: true, categories: { some: { categoryId: { in: treeIds } } } };
        data = await presentMany({ AND: [visibleProductWhere(idx), scope] }, idx, { take: cfg.limit, ids: cfg.source === "MANUAL" ? cfg.productIds : undefined });
        break;
      }
      case "CATEGORY_GRID": {
        let cats: Category[] = [];
        if (cfg.source === "CHILDREN") cats = kids;
        else if (cfg.source === "MANUAL") cats = (cfg.categoryIds as string[]).map((id) => idx.live.get(id)).filter((c): c is Category => !!c && c.visibility === "PUBLIC");
        else cats = [...idx.live.values()].filter((c) => c.featured && c.visibility === "PUBLIC").sort((x, y) => x.featuredOrder - y.featuredOrder).slice(0, 12);
        const cnt = await productCounts(cats.map((c) => c.id));
        data = cats.map((c) => categoryCard(c, cnt.get(c.id)));
        break;
      }
      case "FAQ": {
        const own = cfg.items as { q: string; a: string }[];
        data = cfg.useCategoryFaq ? [...own, ...parseFaq(category.faq)] : own;
        break;
      }
      case "SUPPORT_INFO":
        data = cfg.useGlobalContact ? a.general.contact : null;
        break;
      case "COUNTDOWN":
        data = { serverNow: now.toISOString() };
        break;
      default:
        break;
    }
    sections.push({
      id: s.id, type: s.type, title: s.title, config: cfg, data,
      buttons: pick(s.buttons),
      ...(a.preview ? { scheduledOut: !inSchedule(s) } : {}),
    });
  }

  const notices = await noticesFor("CATEGORY_PAGE", { ...ctx, categoryIds: [category.id, ...ancestorsOf(idx, category).map((c) => c.id)] });

  let support: { url: string } | null = null;
  if (category.supportLink) {
    const c = validateExternalUrl(category.supportLink, a.general.allowedExternalHosts);
    if (c.ok) support = { url: c.url };
  }

  const discountActive = !!category.discountPercent && (!category.discountStartsAt || category.discountStartsAt <= now) && (!category.discountEndsAt || category.discountEndsAt > now);

  return {
    category: {
      id: category.id, name: category.name, slug: category.slug, description: category.description, icon: category.icon,
      imageUrl: category.imageUrl, coverUrl: category.coverUrl, purchasable: category.purchasable,
      unavailableMessage: category.purchasable ? null : category.unavailableMessage ?? "Purchases are temporarily unavailable in this category.",
      discountPercent: discountActive ? Number(category.discountPercent) : null,
      discountEndsAt: discountActive ? category.discountEndsAt : null,
      seo: settings.seo,
    },
    settings,
    breadcrumbs: settings.layout.showBreadcrumbs ? breadcrumbs : [],
    children: settings.layout.showSubcategories ? kids.map((k) => categoryCard(k, counts.get(k.id))) : [],
    buttons: pick(topButtons),
    sections,
    list,
    notices,
    faq: parseFaq(category.faq),
    support,
    contact: a.general.contact,
    serverNow: now.toISOString(),
    preview: !!a.preview,
  };
}

function parseFaq(raw: unknown) {
  const r = faqItems.safeParse(raw ?? []);
  return r.success ? r.data : [];
}

/* ============================================================
 * Home
 * ============================================================ */
export async function buildHome(a: { idx: CategoryIndex; viewer: Viewer; general: GeneralSettings }) {
  const { idx, viewer, general } = a;
  const ctx: ButtonCtx = { idx, viewer, allowedHosts: general.allowedExternalHosts };
  const topLevel = [...idx.live.values()].filter((c) => c.parentId === null && c.visibility === "PUBLIC").sort((x, y) => x.sortOrder - y.sortOrder);
  const featuredCats = [...idx.live.values()].filter((c) => c.featured && c.visibility === "PUBLIC").sort((x, y) => x.featuredOrder - y.featuredOrder).slice(0, 12);
  const counts = await productCounts([...new Set([...topLevel, ...featuredCats].map((c) => c.id))]);

  const pinnedIds = general.homeFeaturedProductIds;
  const [banners, announcements, featured, bestSelling] = await Promise.all([
    noticesFor("HOME_BANNER", ctx),
    noticesFor("HOME_SECTION", ctx),
    pinnedIds.length
      ? presentMany({ AND: [visibleProductWhere(idx), { id: { in: pinnedIds } }] }, idx, { ids: pinnedIds })
      : presentMany({ AND: [visibleProductWhere(idx), { featured: true }] }, idx, { orderBy: { createdAt: "desc" }, take: 10 }),
    presentMany(visibleProductWhere(idx), idx, { orderBy: { salesCount: "desc" }, take: 10 }),
  ]);
  return {
    layout: general.homeLayout,
    banners, announcements, featured, bestSelling,
    featuredCategories: featuredCats.map((c) => categoryCard(c, counts.get(c.id))),
    categories: topLevel.map((c) => categoryCard(c, counts.get(c.id))),
    contact: general.contact,
  };
}

export { loadIndex };
export type { Announcement };
