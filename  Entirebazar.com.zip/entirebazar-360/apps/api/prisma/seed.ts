import { PrismaClient, Prisma } from "@prisma/client";
import { SYSTEM_ROLES } from "../src/lib/permissions";
import { DEFAULT_GENERAL_SETTINGS, buttonInput, categoryInput, noticeInput, productInput, sectionInput } from "../src/lib/layoutSchema";

const prisma = new PrismaClient();

async function main() {
  // Payment methods start DISABLED. Enable one in Admin → Payments only after setting the receiving number
  // and choosing manual review (or API verification once its adapter is implemented and tested).
  const providers = [
    { code: "bkash", displayName: "bKash", sortOrder: 1 },
    { code: "nagad", displayName: "Nagad", sortOrder: 2 },
    { code: "rocket", displayName: "Rocket", sortOrder: 3 },
    { code: "upay", displayName: "Upay", sortOrder: 4 },
    { code: "bitcoin", displayName: "Bitcoin (coming soon)", sortOrder: 99, isFuture: true },
  ];
  for (const p of providers) {
    await prisma.paymentProvider.upsert({ where: { code: p.code }, update: {}, create: { ...p, enabled: false, verificationMode: "DISABLED" } });
    await prisma.integrationConfig.upsert({ where: { code: p.code }, update: {}, create: { code: p.code } });
  }

  // Ready-made roles (editable permission sets; never deletable).
  for (const r of SYSTEM_ROLES) {
    await prisma.role.upsert({ where: { name: r.name }, update: { description: r.description }, create: { name: r.name, description: r.description, permissions: r.permissions, system: true } });
  }

  // Default site settings (only if none saved yet).
  if (!(await prisma.appSetting.findUnique({ where: { key: "general" } }))) {
    await prisma.appSetting.create({ data: { key: "general", value: JSON.stringify(DEFAULT_GENERAL_SETTINGS) } });
  }

  // Demo catalogue: created once, only on an empty database. Everything goes through the same validators as the admin panel.
  if ((await prisma.category.count()) > 0) {
    console.log("Seed complete (catalogue already exists, demo content skipped)");
    return;
  }

  const rootIn = categoryInput.parse({
    name: "Software", slug: "software", description: "Licences, tools and subscriptions.", icon: "💻", featured: true,
    faq: [{ q: "How fast is delivery?", a: "Keys are delivered instantly after payment." }],
  });
  const root = await prisma.category.create({ data: { ...rootIn, status: "PUBLISHED", settings: rootIn.settings as any, faq: rootIn.faq as any } });
  const subIn = categoryInput.parse({ name: "Licence keys", slug: "licence-keys", parentId: root.id, description: "Instant-delivery keys.", icon: "🔑" });
  const sub = await prisma.category.create({ data: { ...subIn, status: "PUBLISHED", settings: subIn.settings as any, faq: subIn.faq as any } });

  const pIn = productInput.parse({
    name: "Demo License Key", description: "Sample product for testing the delivery flow.", features: ["Instant delivery", "Lifetime key"],
    price: 100, featured: true, categoryIds: [sub.id], primaryCategoryId: sub.id,
  });
  const product = await prisma.product.create({
    data: {
      name: pIn.name, description: pIn.description, features: pIn.features, price: new Prisma.Decimal(pIn.price), featured: true,
      productType: "LICENSE_KEY", deliveryType: "TEXT_KEYS", status: "PUBLISHED", categoryId: sub.id, faq: [] as any,
      categories: { create: [{ categoryId: sub.id }, { categoryId: root.id }] },
    },
  });
  await prisma.productKey.createMany({ data: ["DEMO-AAAA-0001", "DEMO-AAAA-0002", "DEMO-AAAA-0003"].map((secret) => ({ productId: product.id, secret })) });

  const manualIn = productInput.parse({
    name: "Game Top-up (manual)", description: "Fulfilled by our team after payment.", price: 250, productType: "MANUAL", deliveryType: "MANUAL",
    inputLabel: "Player ID", deliveryInstructions: "We usually complete top-ups within 30 minutes.", categoryIds: [root.id],
  });
  const manual = await prisma.product.create({
    data: {
      name: manualIn.name, description: manualIn.description, features: [], price: new Prisma.Decimal(manualIn.price), productType: "MANUAL", deliveryType: "MANUAL",
      inputLabel: manualIn.inputLabel, deliveryInstructions: manualIn.deliveryInstructions, status: "PUBLISHED", categoryId: root.id, faq: [] as any,
      categories: { create: [{ categoryId: root.id }] },
    },
  });
  await prisma.productVariant.createMany({ data: [{ productId: manual.id, name: "100 diamonds", price: new Prisma.Decimal(250), sortOrder: 0 }, { productId: manual.id, name: "500 diamonds", price: new Prisma.Decimal(1150), sortOrder: 1 }] });

  const sections = [
    sectionInput.parse({ type: "HOW_IT_WORKS", title: "How it works", config: { steps: [{ title: "Add money to your wallet", text: "Pay with bKash, Nagad, Rocket or Upay." }, { title: "Pick a product", text: "" }, { title: "Receive it instantly or from our team", text: "" }] } }),
    sectionInput.parse({ type: "PRODUCT_GRID", title: "Products", config: { source: "SUBTREE", limit: 12 } }),
    sectionInput.parse({ type: "FAQ", title: "FAQ", config: { useCategoryFaq: true, items: [] } }),
  ];
  const created = [];
  for (const [i, s] of sections.entries()) created.push(await prisma.categorySection.create({ data: { ...s, config: s.config as any, categoryId: root.id, sortOrder: i } }));
  void created;

  const btn = buttonInput.parse({ categoryId: root.id, label: "Add money", icon: "💳", style: "PRIMARY", placement: "TOP", action: "OPEN_WALLET", target: {}, visibility: { audience: "LOW_BALANCE", threshold: 100 } });
  await prisma.actionButton.create({ data: { ...btn, categoryId: root.id, sectionId: null, productId: null, noticeId: null, target: btn.target as any, visibility: btn.visibility as any } });

  const notice = noticeInput.parse({ title: "Welcome to EntireBazar 360", body: "Add money to your wallet, then pick anything from the shop.", type: "INFO", locations: ["HOME_BANNER"], dismissible: true });
  await prisma.announcement.create({ data: { ...notice, publishAt: new Date() } });

  console.log("Seed complete (demo catalogue created)");
}

main().finally(() => prisma.$disconnect());
