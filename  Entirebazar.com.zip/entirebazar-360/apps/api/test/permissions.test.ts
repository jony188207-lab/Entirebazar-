import test from "node:test";
import assert from "node:assert/strict";
import { hasPermission, permissionsOf, PERMISSIONS } from "../src/lib/permissions";

test("owner has everything", () => {
  for (const p of PERMISSIONS) assert.ok(hasPermission({ role: "OWNER" }, p));
});
test("admin cannot adjust wallets, manage roles or replace secrets by default", () => {
  const a = { role: "ADMIN" as const };
  for (const p of ["wallet.adjust", "roles.manage", "integrations.secrets"] as const) assert.equal(hasPermission(a, p), false, p);
  assert.ok(hasPermission(a, "catalog.edit"));
  assert.ok(hasPermission(a, "deposits.review"));
});
test("support is read-mostly", () => {
  const s = { role: "SUPPORT" as const };
  assert.ok(hasPermission(s, "tickets.manage"));
  for (const p of ["catalog.edit", "deposits.review", "orders.refund", "wallet.adjust", "settings.manage"] as const) assert.equal(hasPermission(s, p), false, p);
});
test("custom role overrides the enum and ignores unknown permissions", () => {
  const a = { role: "ADMIN" as const, customRole: { permissions: ["catalog.view", "bogus.perm"] } };
  assert.deepEqual(permissionsOf(a), ["catalog.view"]);
  assert.equal(hasPermission(a, "catalog.edit"), false);
});
test("disabled admins have nothing, even owners", () => {
  assert.deepEqual(permissionsOf({ role: "OWNER", disabled: true }), []);
});
