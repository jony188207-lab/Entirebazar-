import test from "node:test";
import assert from "node:assert/strict";
import { maskSecret } from "../src/lib/secretbox";
import { validateHttpsUrl } from "../src/lib/validate";
import { SYSTEM_ROLES, PERMISSION_GROUPS, PERMISSIONS } from "../src/lib/permissions";

test("maskSecret never reveals the value", () => {
  assert.equal(maskSecret("abc123"), "••••••••");
  assert.equal(maskSecret(""), "");
});
test("validateHttpsUrl", () => {
  assert.equal(validateHttpsUrl("https://example.com/x").ok, true);
  assert.equal(validateHttpsUrl("http://example.com").ok, false);
  assert.equal(validateHttpsUrl("javascript:alert(1)").ok, false);
  assert.equal(validateHttpsUrl("https://localhost/x").ok, false);
});
test("system roles only use known permissions and none grant roles.manage", () => {
  for (const r of SYSTEM_ROLES) {
    for (const p of r.permissions) assert.ok(PERMISSIONS.includes(p), `${r.name}:${p}`);
    assert.ok(!r.permissions.includes("roles.manage"));
  }
});
test("permission groups cover every permission exactly once", () => {
  const flat = PERMISSION_GROUPS.flatMap((g) => g.permissions);
  assert.equal(new Set(flat).size, flat.length);
  assert.deepEqual([...flat].sort(), [...PERMISSIONS].sort());
});

import { sniffImage } from "../src/lib/upload";
test("sniffImage accepts real images only", () => {
  const png = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
  const jpg = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0, 0, 0, 0, 0]);
  const webp = Buffer.concat([Buffer.from("RIFF"), Buffer.from([0, 0, 0, 0]), Buffer.from("WEBP")]);
  assert.equal(sniffImage(png)?.ext, ".png");
  assert.equal(sniffImage(jpg)?.ext, ".jpg");
  assert.equal(sniffImage(webp)?.ext, ".webp");
  assert.equal(sniffImage(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>')), null);
  assert.equal(sniffImage(Buffer.from("<script>alert(1)</script>")), null);
  assert.equal(sniffImage(Buffer.alloc(3)), null);
});
