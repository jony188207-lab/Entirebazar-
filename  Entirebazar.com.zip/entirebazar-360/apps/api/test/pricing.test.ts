import test from "node:test";
import assert from "node:assert/strict";
import { toMinor, fromMinor, effectivePrice } from "../src/lib/pricing";

test("minor units", () => {
  assert.equal(toMinor("10"), 1000);
  assert.equal(toMinor("10.5"), 1050);
  assert.equal(toMinor(0.1 + 0.2), 30); // float noise is neutralised by toFixed(2)
  assert.equal(fromMinor(1050), "10.50");
  assert.throws(() => toMinor("1.234"));
  assert.throws(() => toMinor("-1"));
  assert.throws(() => toMinor("abc"));
});

const now = new Date("2026-06-01T00:00:00Z");
test("no discount", () => {
  const p = effectivePrice("100", [], now);
  assert.deepEqual(p, { base: "100.00", final: "100.00", discounted: false, percentOff: 0, source: "NONE" });
});
test("percent and fixed", () => {
  assert.equal(effectivePrice("100", [{ type: "PERCENT", value: 15, source: "PRODUCT" }], now).final, "85.00");
  assert.equal(effectivePrice("99.99", [{ type: "PERCENT", value: 10, source: "PRODUCT" }], now).final, "89.99"); // 89.991 -> 89.99
  assert.equal(effectivePrice("10.05", [{ type: "PERCENT", value: 10, source: "PRODUCT" }], now).final, "9.05"); // 9.045 rounds half up
  assert.equal(effectivePrice("100", [{ type: "FIXED", value: 30, source: "PRODUCT" }], now).final, "70.00");
});
test("best single discount wins, never stacked", () => {
  const r = effectivePrice("100", [{ type: "PERCENT", value: 10, source: "PRODUCT" }, { type: "PERCENT", value: 25, source: "CATEGORY" }], now);
  assert.equal(r.final, "75.00");
  assert.equal(r.source, "CATEGORY");
});
test("schedule respected", () => {
  const d = { type: "PERCENT" as const, value: 50, source: "PRODUCT" as const, startsAt: new Date("2026-06-02T00:00:00Z"), endsAt: new Date("2026-06-03T00:00:00Z") };
  assert.equal(effectivePrice("100", [d], now).discounted, false); // not started
  assert.equal(effectivePrice("100", [d], new Date("2026-06-02T12:00:00Z")).final, "50.00");
  assert.equal(effectivePrice("100", [d], new Date("2026-06-03T00:00:00Z")).discounted, false); // ended (end exclusive)
});
test("price floor and 90% cap", () => {
  assert.equal(effectivePrice("1", [{ type: "FIXED", value: 5, source: "PRODUCT" }], now).final, "0.01");
  assert.equal(effectivePrice("100", [{ type: "PERCENT", value: 100, source: "PRODUCT" }], now).final, "10.00");
});
