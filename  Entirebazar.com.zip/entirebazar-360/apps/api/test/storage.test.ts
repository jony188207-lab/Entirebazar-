import { test } from "node:test";
import assert from "node:assert/strict";

process.env.BOT_TOKEN ??= "x";
process.env.JWT_SECRET ??= "j".repeat(32);
process.env.ADMIN_JWT_SECRET ??= "a".repeat(32);

import { presign, encodeKeyPath } from "../src/lib/s3sign";

// AWS documentation example "Authenticating Requests: Using Query Parameters (AWS Signature Version 4)".
test("SigV4 presign matches the AWS published test vector", () => {
  const url = presign({
    method: "GET", host: "examplebucket.s3.amazonaws.com", path: "/test.txt", region: "us-east-1",
    accessKeyId: "AKIAIOSFODNN7EXAMPLE", secretAccessKey: "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
    expiresSeconds: 86400, now: new Date("2013-05-24T00:00:00Z"),
  });
  assert.match(url, /X-Amz-Signature=aeeed9bbccd4d02ee5c0109b86d86835f995330da4c265957d157751f604d404$/);
});

test("presign rejects out-of-range expiry and encodes key paths", () => {
  assert.throws(() => presign({ method: "GET", host: "h", path: "/p", region: "r", accessKeyId: "a", secretAccessKey: "s", expiresSeconds: 0 }));
  assert.equal(encodeKeyPath("files/ab cd/x y.pdf"), "files/ab%20cd/x%20y.pdf");
});

test("private file refs: strict shape, no traversal", async () => {
  const { PRIVATE_REF } = await import("../src/lib/storage");
  assert.ok(PRIVATE_REF.test("b2://files/" + "a".repeat(32) + "/guide.pdf"));
  assert.ok(!PRIVATE_REF.test("b2://files/../../etc/passwd"));
  assert.ok(!PRIVATE_REF.test("b2://files/" + "a".repeat(32) + "/a/b.pdf"));
  assert.ok(!PRIVATE_REF.test("https://evil.example/x.pdf"));
});

test("storeImage rejects non-images and SVG before touching any storage", async () => {
  const { storeImage } = await import("../src/lib/storage");
  await assert.rejects(storeImage(Buffer.from("<svg xmlns='http://www.w3.org/2000/svg'></svg>")), /Unsupported image/);
  await assert.rejects(storeImage(Buffer.alloc(100, 1)), /Unsupported image/);
});

test("storePrivateFile rejects executables and needs B2 driver", async () => {
  const { storePrivateFile } = await import("../src/lib/storage");
  await assert.rejects(storePrivateFile(Buffer.from("MZ" + "x".repeat(50)), "a.exe"), /B2|PDF/);
});
