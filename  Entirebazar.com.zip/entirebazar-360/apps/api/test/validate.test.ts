import test from "node:test";
import assert from "node:assert/strict";
import { slugify, hasMarkup, isSafeImageRef, validateExternalUrl, telegramBotLink, isSafeEmoji } from "../src/lib/validate";

test("slugify", () => {
  assert.equal(slugify("Game Top-Ups & Cards!"), "game-top-ups-cards");
  assert.equal(slugify("  ÀÉÎ  "), "aei");
  assert.equal(slugify("!!!"), "item");
});

test("markup is rejected", () => {
  for (const bad of ["<script>alert(1)</script>", "hi <b>x</b>", "<!-- c -->", "<img src=x onerror=1>", "javascript:alert(1)"]) assert.ok(hasMarkup(bad), bad);
  for (const ok of ["Plain text", "5 < 6 and 7 > 3", "a<3 love", "Save 20% today!"]) assert.ok(!hasMarkup(ok), ok);
});

test("image refs", () => {
  assert.ok(isSafeImageRef("/uploads/" + "a".repeat(32) + ".png"));
  assert.ok(isSafeImageRef("https://cdn.example.com/a/b.webp"));
  for (const bad of ["http://x.com/a.png", "https://u:p@x.com/a.png", "javascript:alert(1)", "/uploads/../etc/passwd", "https://x.com/a.svg", "data:image/png;base64,AAAA", "/uploads/short.png"]) assert.ok(!isSafeImageRef(bad), bad);
});

test("emoji/icon", () => {
  assert.ok(isSafeEmoji("🎮"));
  assert.ok(!isSafeEmoji("<img>"));
  assert.ok(!isSafeEmoji(""));
  assert.ok(!isSafeEmoji("x".repeat(9)));
});

test("external URL allow-list", () => {
  const allow = ["t.me", "*.example.com"];
  assert.equal(validateExternalUrl("https://t.me/foo", allow).ok, true);
  assert.equal(validateExternalUrl("https://shop.example.com/x", allow).ok, true);
  const bad = ["http://t.me/foo", "https://evil.com", "https://example.com.evil.com", "https://u:p@t.me/x", "https://127.0.0.1/", "https://localhost/", "https://t.me:8443/", "javascript:alert(1)", "https://[::1]/", "not a url", "https://notexample.com"];
  for (const b of bad) assert.equal(validateExternalUrl(b, allow).ok, false, b);
  assert.equal(validateExternalUrl("https://t.me/foo", []).ok, false, "empty allow-list blocks everything");
});

test("telegram bot link", () => {
  assert.deepEqual(telegramBotLink("MyShopBot", "ref_1"), { ok: true, url: "https://t.me/MyShopBot?start=ref_1" });
  assert.equal(telegramBotLink("ab").ok, false);
  assert.equal(telegramBotLink("MyShopBot", "a b").ok, false);
  assert.equal(telegramBotLink("MyShopBot/../x").ok, false);
});
