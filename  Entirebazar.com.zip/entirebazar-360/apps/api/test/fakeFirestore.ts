import { TxLike, RunTx, AlreadyExists, Doc } from "../src/firestore/txn";

/** In-memory Firestore-like store with the semantics the money code depends on (NOT the real SDK). */
export class FakeStore {
  docs = new Map<string, { v: number; data: Doc }>();
  private n = 0;
  seed(path: string, data: Doc) { this.docs.set(path, { v: 1, data: structuredClone(data) }); }
  read(path: string) { return this.docs.get(path)?.data; }
  yieldBetween: () => Promise<void> = async () => {};
  attempts = 0;

  run: RunTx = async (fn) => {
    for (let attempt = 0; attempt < 10; attempt++) {
      this.attempts++;
      const reads = new Map<string, number>();
      const cache = new Map<string, Doc | undefined>();
      const writes: { op: "create" | "set" | "update"; path: string; data: Doc }[] = [];
      let wrote = false;
      const tx: TxLike = {
        get: async (path) => {
          if (wrote) throw new Error("Firestore rule violated: read after write");
          if (cache.has(path)) return cache.get(path);
          const d = this.docs.get(path);
          reads.set(path, d?.v ?? 0);
          const v = d ? structuredClone(d.data) : undefined;
          cache.set(path, v);
          return v;
        },
        create: (path, data) => { wrote = true; writes.push({ op: "create", path, data: structuredClone(data) }); },
        set: (path, data) => { wrote = true; writes.push({ op: "set", path, data: structuredClone(data) }); },
        update: (path, data) => { wrote = true; writes.push({ op: "update", path, data: structuredClone(data) }); },
        newId: () => `id${++this.n}`,
      };
      const result = await fn(tx);
      await this.yieldBetween(); // lets a competing transaction commit first
      // commit: optimistic check, then apply atomically
      let conflict = false;
      for (const [p, v] of reads) if ((this.docs.get(p)?.v ?? 0) !== v) conflict = true;
      if (conflict) continue;
      for (const w of writes) {
        const cur = this.docs.get(w.path);
        if (w.op === "create" && cur) throw new AlreadyExists(w.path);
        if (w.op === "update" && !cur) throw new Error(`NOT_FOUND ${w.path}`);
      }
      for (const w of writes) {
        const cur = this.docs.get(w.path);
        const data = w.op === "update" ? { ...cur!.data, ...w.data } : w.data;
        this.docs.set(w.path, { v: (cur?.v ?? 0) + 1, data });
      }
      return result;
    }
    throw new Error("Transaction retries exhausted");
  };
}
