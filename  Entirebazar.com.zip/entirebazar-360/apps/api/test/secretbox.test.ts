import test from "node:test";
import assert from "node:assert/strict";
import crypto from "crypto";
import { loadKey, seal, open, sanitizeError } from "../src/lib/secretbox";

const key = loadKey(crypto.randomBytes(32).toString("hex"));
test("round trip and unique IVs", () => {
  const a = seal("s3cret-value", key, "bkash:appSecret");
  const b = seal("s3cret-value", key, "bkash:appSecret");
  assert.notEqual(a.ciphertext, b.ciphertext);
  assert.equal(open(a, key, "bkash:appSecret"), "s3cret-value");
  assert.ok(!a.ciphertext.includes("s3cret"));
});
test("bound to its row (AAD) and tamper-evident", () => {
  const a = seal("x".repeat(20), key, "bkash:appSecret");
  assert.throws(() => open(a, key, "nagad:appSecret"));
  assert.throws(() => open({ ...a, ciphertext: Buffer.from("AAAA").toString("base64") }, key, "bkash:appSecret"));
  assert.throws(() => open(a, loadKey(crypto.randomBytes(32).toString("hex")), "bkash:appSecret"));
});
test("key validation", () => {
  assert.throws(() => loadKey(undefined));
  assert.throws(() => loadKey("short"));
  assert.equal(loadKey(crypto.randomBytes(32).toString("base64")).length, 32);
});
test("error sanitising removes credentials", () => {
  const out = sanitizeError("HTTP 401 Authorization: Bearer abcdefghijklmnopqrstuvwxyz0123456789ABCD for key=SUPERSECRETVALUE", ["SUPERSECRETVALUE"]);
  assert.ok(!out.includes("SUPERSECRETVALUE"));
  assert.ok(!out.includes("abcdefghijklmnopqrstuvwxyz"));
});
