import test from "node:test";
import assert from "node:assert/strict";
import {
  sectionInput, buttonInput, categoryInput, productInput, noticeInput, generalSettingsSchema,
  SECTION_TYPES, DEFAULT_CATEGORY_SETTINGS, parseButtonTarget, sectionConfigSchemas,
} from "../src/lib/layoutSchema";

test("every section type has a schema and an empty-ish config is handled deterministically", () => {
  for (const t of SECTION_TYPES) assert.ok(sectionConfigSchemas[t], t);
  // Types whose config has no required fields accept {} and fill defaults
  for (const t of ["PRODUCT_GRID", "FEATURED_PRODUCTS", "BUTTON_GROUP", "CATEGORY_GRID", "FAQ", "SUPPORT_INFO"] as const) {
    assert.ok(sectionInput.safeParse({ type: t, config: {} }).success, t);
  }
  // Types with required content reject {}
  for (const t of ["PROMO_BANNER", "NOTICE", "RICH_TEXT", "IMAGE", "HOW_IT_WORKS", "TERMS", "COUNTDOWN", "EMPTY_STATE"] as const) {
    assert.ok(!sectionInput.safeParse({ type: t, config: {} }).success, t);
  }
});

test("unknown section types are rejected", () => {
  assert.ok(!sectionInput.safeParse({ type: "CUSTOM_HTML", config: { html: "<script>1</script>" } }).success);
});

test("script/markup in section text is rejected", () => {
  const r = sectionInput.safeParse({ type: "RICH_TEXT", config: { text: "Hello <script>alert(1)</script>" } });
  assert.equal(r.success, false);
  const ok = sectionInput.safeParse({ type: "RICH_TEXT", config: { text: "**Hello**\n\n- one\n- two" } });
  assert.equal(ok.success, true);
});

test("unknown config keys are stripped, not stored", () => {
  const r = sectionInput.parse({ type: "RICH_TEXT", config: { text: "hi", onload: "alert(1)", html: "<b>x</b>" } });
  assert.deepEqual(Object.keys(r.config).sort(), ["align", "text"]);
});

test("section images must be safe refs", () => {
  assert.ok(!sectionInput.safeParse({ type: "IMAGE", config: { imageUrl: "javascript:alert(1)" } }).success);
  assert.ok(!sectionInput.safeParse({ type: "IMAGE", config: { imageUrl: "http://insecure.example.com/a.png" } }).success);
  assert.ok(sectionInput.safeParse({ type: "IMAGE", config: { imageUrl: "https://cdn.example.com/a.png", alt: "A" } }).success);
});

test("section schedule must be ordered", () => {
  const r = sectionInput.safeParse({ type: "FAQ", config: {}, startsAt: "2026-02-02T00:00:00Z", endsAt: "2026-02-01T00:00:00Z" });
  assert.equal(r.success, false);
});

test("countdown parses a date", () => {
  const r = sectionInput.parse({ type: "COUNTDOWN", config: { endsAt: "2030-01-01T00:00:00Z", label: "Sale ends" } });
  assert.equal(typeof r.config.endsAt, "string");
});

const base = { label: "Buy now", action: "START_PURCHASE", target: { productId: "p1" }, categoryId: "c1" };
test("buttons need exactly one owner", () => {
  assert.ok(buttonInput.safeParse(base).success);
  assert.ok(!buttonInput.safeParse({ ...base, categoryId: undefined }).success, "no owner");
  assert.ok(!buttonInput.safeParse({ ...base, productId: "p1" }).success, "two owners");
});

test("button targets are validated per action", () => {
  assert.ok(!buttonInput.safeParse({ ...base, action: "OPEN_PRODUCT", target: {} }).success);
  assert.ok(!buttonInput.safeParse({ ...base, action: "OPEN_TELEGRAM_BOT", target: { username: "x" } }).success);
  assert.ok(buttonInput.safeParse({ ...base, action: "OPEN_TELEGRAM_BOT", target: { username: "MyShopBot", startParam: "promo" } }).success);
  assert.ok(buttonInput.safeParse({ ...base, action: "OPEN_WALLET", target: {} }).success);
  assert.ok(!buttonInput.safeParse({ ...base, action: "RUN_SCRIPT", target: {} }).success, "unknown action");
  assert.ok(!buttonInput.safeParse({ ...base, label: "<b>x</b>" }).success);
});

test("button targets: extra keys are stripped", () => {
  const r = buttonInput.parse({ ...base, action: "OPEN_WALLET", target: { url: "https://evil.com" } });
  assert.deepEqual(r.target, {});
  assert.equal(parseButtonTarget("OPEN_PRODUCT", { productId: "p" })?.productId, "p");
  assert.equal(parseButtonTarget("NOPE", {}), null);
});

test("category defaults and validation", () => {
  const c = categoryInput.parse({ name: "Gift Cards" });
  assert.deepEqual(c.settings, DEFAULT_CATEGORY_SETTINGS);
  assert.equal(c.visibility, "PUBLIC");
  assert.ok(!categoryInput.safeParse({ name: "" }).success);
  assert.ok(!categoryInput.safeParse({ name: "<script>" }).success);
  assert.ok(!categoryInput.safeParse({ name: "X", slug: "Bad Slug" }).success);
  assert.ok(!categoryInput.safeParse({ name: "X", publishAt: "2026-02-02", unpublishAt: "2026-02-01" }).success);
  assert.ok(!categoryInput.safeParse({ name: "X", discountPercent: 95 }).success);
  assert.ok(!categoryInput.safeParse({ name: "X", settings: { display: { accentColor: "red" } } }).success);
});

const prod = { name: "Netflix 1 month", description: "d", price: "10.50", categoryIds: ["c1"] };
test("product validation", () => {
  assert.ok(productInput.safeParse(prod).success);
  assert.ok(!productInput.safeParse({ ...prod, price: "0" }).success);
  assert.ok(!productInput.safeParse({ ...prod, price: "1.234" }).success);
  assert.ok(!productInput.safeParse({ ...prod, discountType: "PERCENT" }).success, "needs value");
  assert.ok(!productInput.safeParse({ ...prod, discountType: "PERCENT", discountValue: 95 }).success);
  assert.ok(!productInput.safeParse({ ...prod, discountType: "FIXED", discountValue: 11 }).success);
  assert.ok(productInput.safeParse({ ...prod, discountType: "FIXED", discountValue: 2 }).success);
  assert.ok(!productInput.safeParse({ ...prod, deliveryType: "FILE_URL" }).success, "needs link");
  assert.ok(!productInput.safeParse({ ...prod, primaryCategoryId: "other" }).success);
});

test("notice validation", () => {
  const n = { title: "Sale", body: "Big sale", locations: ["HOME_BANNER"] };
  assert.ok(noticeInput.safeParse(n).success);
  assert.ok(!noticeInput.safeParse({ ...n, locations: [] }).success);
  assert.ok(!noticeInput.safeParse({ ...n, locations: ["NOWHERE"] }).success);
  assert.ok(!noticeInput.safeParse({ ...n, audience: "CATEGORIES" }).success, "needs categories");
  assert.ok(noticeInput.safeParse({ ...n, audience: "CATEGORIES", categoryIds: ["c1"] }).success);
  assert.ok(!noticeInput.safeParse({ ...n, body: "<iframe src=x>" }).success);
});

test("general settings", () => {
  const d = generalSettingsSchema.parse({});
  assert.deepEqual(d.allowedExternalHosts, ["t.me", "telegram.org"]);
  assert.equal(d.homeLayout.length, 6);
  assert.ok(!generalSettingsSchema.safeParse({ allowedExternalHosts: ["http://evil.com"] }).success);
  assert.ok(!generalSettingsSchema.safeParse({ allowedExternalHosts: ["127.0.0.1"] }).success);
  assert.ok(generalSettingsSchema.safeParse({ allowedExternalHosts: ["*.example.com", "docs.example.org"] }).success);
});
