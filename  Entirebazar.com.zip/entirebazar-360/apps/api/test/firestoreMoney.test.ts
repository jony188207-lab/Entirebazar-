import test from "node:test";
import assert from "node:assert/strict";
import { FakeStore } from "./fakeFirestore";
import { P } from "../src/firestore/paths";
import { postEntry, InsufficientFunds } from "../src/firestore/ledger";
import { finalizeDepositTx } from "../src/firestore/deposits";
import { claimKeys, OutOfStock } from "../src/firestore/keys";
import { toMinor, fromMinor } from "../src/firestore/money";

const now = new Date("2026-11-01T00:00:00Z");
function setup() {
  const s = new FakeStore();
  s.seed(P.wallet("u1"), { balanceMinor: 0, version: 0 });
  s.seed(P.provider("bkash"), { receiverNumber: "01700000000" });
  s.seed(P.deposit("d1"), { id: "d1", userId: "u1", providerCode: "bkash", amountMinor: 50000, status: "PENDING", providerTrxId: "TRX1" });
  s.seed(P.deposit("d2"), { id: "d2", userId: "u1", providerCode: "bkash", amountMinor: 50000, status: "PENDING", providerTrxId: "TRX1" });
  return s;
}
const trx = { providerTrxId: "TRX1", amountMinor: 50000, receiverNumber: "01700000000", source: "api" };

test("money helpers use integers and reject floats/garbage", () => {
  assert.equal(toMinor("12.34"), 1234);
  assert.equal(toMinor("0.1"), 10);
  assert.equal(fromMinor(1205), "12.05");
  assert.throws(() => toMinor("1.234"));
  assert.throws(() => toMinor("abc"));
});

test("finalizeDeposit credits once and is idempotent", async () => {
  const s = setup();
  assert.equal(await s.run((tx) => finalizeDepositTx(tx, "d1", trx, now)), "credited");
  assert.equal(await s.run((tx) => finalizeDepositTx(tx, "d1", trx, now)), "already");
  assert.equal(s.read(P.wallet("u1"))!.balanceMinor, 50000);
  assert.equal(s.read(P.deposit("d1"))!.status, "SUCCESSFUL");
});

test("two concurrent finalizations credit exactly once", async () => {
  const s = setup();
  s.yieldBetween = () => new Promise((r) => setTimeout(r, 5));
  const r = await Promise.all([s.run((tx) => finalizeDepositTx(tx, "d1", trx, now)), s.run((tx) => finalizeDepositTx(tx, "d1", trx, now))]);
  assert.deepEqual(r.sort(), ["already", "credited"]);
  assert.equal(s.read(P.wallet("u1"))!.balanceMinor, 50000);
  assert.ok(s.attempts > 2, "a conflict must have forced a retry");
});

test("wrong amount / receiver never credits and flags review", async () => {
  const s = setup();
  assert.equal(await s.run((tx) => finalizeDepositTx(tx, "d1", { ...trx, amountMinor: 49999 }, now)), "mismatch");
  assert.equal(await s.run((tx) => finalizeDepositTx(tx, "d1", { ...trx, receiverNumber: "019" }, now)), "receiver_mismatch");
  assert.equal(s.read(P.wallet("u1"))!.balanceMinor, 0);
  assert.equal(s.read(P.deposit("d1"))!.needsReview, true);
});

test("same provider TrxID cannot fund a second deposit", async () => {
  const s = setup();
  await s.run((tx) => finalizeDepositTx(tx, "d1", trx, now));
  assert.equal(await s.run((tx) => finalizeDepositTx(tx, "d2", trx, now)), "duplicate");
  assert.equal(s.read(P.wallet("u1"))!.balanceMinor, 50000);
});

test("ledger: duplicate event does not double-post; debit cannot overdraw", async () => {
  const s = setup();
  const credit = { userId: "u1", type: "ADJUSTMENT" as const, direction: "CREDIT" as const, amountMinor: 1000, refType: "adj", refId: "a1", now };
  assert.equal((await s.run((tx) => postEntry(tx, credit))).duplicate, false);
  assert.equal((await s.run((tx) => postEntry(tx, credit))).duplicate, true);
  assert.equal(s.read(P.wallet("u1"))!.balanceMinor, 1000);
  await assert.rejects(s.run((tx) => postEntry(tx, { ...credit, direction: "DEBIT", amountMinor: 1001, refId: "o1", type: "PURCHASE" })), InsufficientFunds);
  assert.equal(s.read(P.wallet("u1"))!.balanceMinor, 1000);
});

test("concurrent debits cannot overdraw the wallet", async () => {
  const s = setup();
  s.seed(P.wallet("u1"), { balanceMinor: 1000, version: 1 });
  s.yieldBetween = () => new Promise((r) => setTimeout(r, 5));
  const debit = (id: string) => s.run((tx) => postEntry(tx, { userId: "u1", type: "PURCHASE", direction: "DEBIT", amountMinor: 800, refType: "order", refId: id, now }));
  const res = await Promise.allSettled([debit("o1"), debit("o2")]);
  assert.equal(res.filter((r) => r.status === "fulfilled").length, 1);
  assert.equal(s.read(P.wallet("u1"))!.balanceMinor, 200);
});

test("licence keys are never delivered twice", async () => {
  const s = new FakeStore();
  s.seed("products/p/keys/k1", { secret: "AAA" });
  s.seed("products/p/keys/k2", { secret: "BBB" });
  const cands = [{ path: "products/p/keys/k1" }, { path: "products/p/keys/k2" }];
  assert.deepEqual(await s.run((tx) => claimKeys(tx, cands, 1, "i1", now)), ["AAA"]);
  await assert.rejects(s.run((tx) => claimKeys(tx, cands.slice(0, 1), 1, "i2", now)), OutOfStock);
  await assert.rejects(s.run((tx) => claimKeys(tx, cands, 3, "i3", now)), OutOfStock);
});
