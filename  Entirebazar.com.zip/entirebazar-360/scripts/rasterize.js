// Renders brand SVGs to PNG with Playwright/Chromium.  node scripts/rasterize.js
const { chromium } = require("playwright");
const fs = require("fs"), path = require("path");
const pub = path.join(__dirname, "..", "apps", "web", "public");
const jobs = [
  ["icons/icon-source.svg", "icons/icon-192.png", 192, 192],
  ["icons/icon-source.svg", "icons/icon-512.png", 512, 512],
  ["icons/icon-source.svg", "apple-touch-icon.png", 180, 180],
  ["icons/maskable-source.svg", "icons/icon-maskable-512.png", 512, 512],
  ["logo.svg", "logo.png", 1368, 312],
];
(async () => {
  const b = await chromium.launch();
  for (const [src, out, w, h] of jobs) {
    const svg = fs.readFileSync(path.join(pub, src), "utf8");
    const p = await b.newPage({ viewport: { width: w, height: h } });
    await p.setContent(`<body style="margin:0;background:transparent">${svg.replace("<svg ", `<svg width="${w}" height="${h}" `)}</body>`);
    await p.screenshot({ path: path.join(pub, out), omitBackground: true });
    await p.close();
  }
  await b.close();
})();
