#!/usr/bin/env node
// Sandbox helper: sends a correctly signed payment webhook to your local API.
// Usage: PAYMENT_WEBHOOK_SECRET=... node scripts/sign-webhook.mjs <provider> <trxId> <amount> [receiver] [sender]
import crypto from "node:crypto";

const [provider, trxId, amount, receiver, sender] = process.argv.slice(2);
const secret = process.env.PAYMENT_WEBHOOK_SECRET;
const url = process.env.API_URL ?? "http://localhost:4000";
if (!provider || !trxId || !amount || !secret) {
  console.error("Usage: PAYMENT_WEBHOOK_SECRET=... node scripts/sign-webhook.mjs <provider> <trxId> <amount> [receiver] [sender]");
  process.exit(1);
}
const body = JSON.stringify({
  provider, trxId, amount, receiver, sender,
  environment: process.env.PAYMENT_ENV ?? "sandbox",
});
const ts = Math.floor(Date.now() / 1000).toString();
const sig = crypto.createHmac("sha256", secret).update(`${ts}.`).update(body).digest("hex");
const res = await fetch(`${url}/webhooks/payments`, {
  method: "POST",
  headers: { "content-type": "application/json", "x-timestamp": ts, "x-signature": sig },
  body,
});
console.log(res.status, await res.text());
