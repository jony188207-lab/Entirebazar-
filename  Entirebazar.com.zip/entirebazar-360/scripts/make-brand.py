#!/usr/bin/env python3
"""Generates EntireBazar 360 brand assets (SVG paths are outlined, so no font is needed at runtime).
Requires: fontTools and the Inter font (SIL OFL). Re-run to regenerate:
  python3 scripts/make-brand.py
Outputs: apps/web/components/logoPaths.ts, apps/web/app/icon.svg, apps/web/public/logo*.svg
"""
import math, os, json
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

ROOT = os.path.join(os.path.dirname(__file__), "..")
WEB = os.path.join(ROOT, "apps", "web")
FONT = "/usr/share/fonts/opentype/inter/Inter-ExtraBold.otf"
font = TTFont(FONT)
gs, cmap, hmtx = font.getGlyphSet(), font.getBestCmap(), font["hmtx"]
UPM = font["head"].unitsPerEm

def text_path(text, size, x=0.0, y=0.0, tracking=0.0):
    """Outline `text` as one SVG path. y is the baseline. Returns (d, advance_width)."""
    s = size / UPM
    pen = SVGPathPen(gs, ntos=lambda v: f"{v:.2f}".rstrip("0").rstrip("."))
    cx = x
    for ch in text:
        g = cmap[ord(ch)]
        tp = TransformPen(pen, (s, 0, 0, -s, cx, y))
        gs[g].draw(tp)
        cx += hmtx[g][0] * s + tracking * size
    return pen.getCommands(), cx - x

C1, C2, AMBER, NAVY = "#4F46E5", "#06B6D4", "#F59E0B", "#0B1B3A"

def f(v): return f"{v:.2f}".rstrip("0").rstrip(".")

def pol(a_deg, r, cx=60, cy=60):
    a = math.radians(a_deg)
    return cx + r * math.cos(a), cy + r * math.sin(a)

def mark_parts(num_fill):
    """Returns dict of path strings for the 360 ring mark in a 120x120 box."""
    R = 47
    a0, sweep = -62, 305  # clockwise arc with a gap at the top-right
    x0, y0 = pol(a0, R)
    x1, y1 = pol(a0 + sweep, R)
    ring = f"M{f(x0)} {f(y0)} A{R} {R} 0 1 1 {f(x1)} {f(y1)}"
    # arrowhead at the arc end, pointing along the direction of travel
    ae = math.radians(a0 + sweep)
    tx, ty = -math.sin(ae), math.cos(ae)      # tangent (clockwise)
    nx, ny = math.cos(ae), math.sin(ae)       # radial
    tip = (x1 + tx * 13, y1 + ty * 13)
    b1 = (x1 + nx * 8.5, y1 + ny * 8.5)
    b2 = (x1 - nx * 8.5, y1 - ny * 8.5)
    arrow = f"M{f(b1[0])} {f(b1[1])} L{f(tip[0])} {f(tip[1])} L{f(b2[0])} {f(b2[1])} Z"
    dot = pol(-34, 57)  # satellite on the thin outer orbit
    d360, w = text_path("360", 37, 0, 0, tracking=-0.02)
    # centre the digits (cap height of Inter ~ 0.727em)
    cap = 0.727 * 37
    d360, w = text_path("360", 37, 60 - w / 2, 60 + cap / 2, tracking=-0.02)
    return dict(ring=ring, arrow=arrow, dot=dot, d360=d360, R=R)

def mark_svg_inner(uid, num_fill, ring_stroke=7):
    p = mark_parts(num_fill)
    return f"""<defs><linearGradient id="g{uid}" x1="8" y1="8" x2="112" y2="112" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{C1}"/><stop offset="1" stop-color="{C2}"/></linearGradient></defs>
<circle cx="60" cy="60" r="57" fill="none" stroke="url(#g{uid})" stroke-width="1.6" opacity=".45"/>
<path d="{p['ring']}" fill="none" stroke="url(#g{uid})" stroke-width="{ring_stroke}" stroke-linecap="round"/>
<path d="{p['arrow']}" fill="{C2}"/>
<circle cx="{f(p['dot'][0])}" cy="{f(p['dot'][1])}" r="5.2" fill="{AMBER}"/>
<path d="{p['d360']}" fill="{num_fill}"/>"""

# ---- Horizontal lockup: "Entire" + "Bazar" + ring-360 badge -------------------------------
FS = 46
d_entire, w_entire = text_path("Entire", FS, 0, 0, tracking=-0.015)
d_bazar, w_bazar = text_path("Bazar", FS, w_entire, 0, tracking=-0.015)
text_w = w_entire + w_bazar
MARK = 78                       # rendered mark size inside the lockup
gap = 6
LW, LH = text_w + gap + MARK, MARK
base = LH / 2 + 0.727 * FS / 2  # vertically centre the lowercase/cap text on the mark
d_entire, _ = text_path("Entire", FS, 0, base, tracking=-0.015)
d_bazar, _ = text_path("Bazar", FS, w_entire, base, tracking=-0.015)
scale = MARK / 120

def lockup_svg(text_fill, uid="L"):
    return f"""<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {f(LW)} {f(LH)}" role="img" aria-label="EntireBazar 360">
<defs><linearGradient id="t{uid}" x1="0" y1="0" x2="{f(text_w)}" y2="0" gradientUnits="userSpaceOnUse"><stop offset="0" stop-color="{C1}"/><stop offset="1" stop-color="{C2}"/></linearGradient></defs>
<path d="{d_entire}" fill="{text_fill}"/>
<path d="{d_bazar}" fill="url(#t{uid})"/>
<g transform="translate({f(text_w + gap)} 0) scale({f(scale)})">{mark_svg_inner(uid, text_fill)}</g>
</svg>"""

def write(path, s):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, "w").write(s)

write(os.path.join(WEB, "public/logo.svg"), lockup_svg(NAVY, "a"))
write(os.path.join(WEB, "public/logo-light.svg"), lockup_svg("#FFFFFF", "b"))
write(os.path.join(WEB, "public/logo-mark.svg"),
      f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 120 120" role="img" aria-label="EntireBazar 360">{mark_svg_inner("m", NAVY)}</svg>')

def app_icon(size_box=120, inset=0, rx=28):
    k = (size_box - 2 * inset) / 120
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {size_box} {size_box}">'
            f'<defs><linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#0B1B3A"/><stop offset="1" stop-color="#16295A"/></linearGradient></defs>'
            f'<rect width="{size_box}" height="{size_box}" rx="{rx}" fill="url(#bg)"/>'
            f'<g transform="translate({inset} {inset}) scale({f(k)})">{mark_svg_inner("i", "#FFFFFF", 7.5)}</g></svg>')

write(os.path.join(WEB, "app/icon.svg"), app_icon(120, 6, 28))
write(os.path.join(WEB, "public/icons/icon-source.svg"), app_icon(120, 6, 28))
write(os.path.join(WEB, "public/icons/maskable-source.svg"), app_icon(120, 22, 0))  # full-bleed, safe-zone padded

ts = "// GENERATED by scripts/make-brand.py — do not edit by hand.\n"
ts += f"export const LOCKUP = {json.dumps(dict(w=round(LW,2), h=round(LH,2), textW=round(text_w,2), gap=gap, scale=round(scale,4), entire=d_entire, bazar=d_bazar))} as const;\n"
p = mark_parts("#000")
ts += f"export const MARK = {json.dumps(dict(ring=p['ring'], arrow=p['arrow'], dot=[round(p['dot'][0],2), round(p['dot'][1],2)], d360=p['d360']))} as const;\n"
write(os.path.join(WEB, "components/logoPaths.ts"), ts)
print("lockup", round(LW, 1), "x", round(LH, 1))
